const os = require('os');
const fs = require('fs');
const path = require('path');
const { components } = require('./components.js');

const componentsTpl = components.map(comp => {
  return `import ${comp} from './components/${comp}';`;
}).join(os.EOL);

const template = `/* 此文件由 gen-entry.js 自动生成，请勿随意改动 */
import './styles/base.scss';
${componentsTpl}
import './styles/theme.scss';
import theme from './theme';
import * as Colors from './theme/colors';
import * as locale from "./locale";

const version = '__VERSION__';
const components = {
${components.map(comp => `  ${comp}`).join(',' + os.EOL)}
};

function install (Vue, opts = {}) {
  locale.use(opts.locale);
  locale.i18n(opts.i18n);
  Object.keys(components).forEach((key) => {
    Vue.use(components[key]);
  });
}

if (typeof window !== 'undefined' && window.Vue) install(window.Vue);

export {
  version,
  Colors,
  locale,
${components.map(comp => `  ${comp}`).join(',' + os.EOL)},
  theme,
  install,
};

export default {
  version,
  install,
  theme,
  Colors,
  locale,
  ...components
};
`;

console.log('>>> generating');
fs.writeFileSync(path.join(__dirname, './index.js'), template);
console.log('>>> done');
