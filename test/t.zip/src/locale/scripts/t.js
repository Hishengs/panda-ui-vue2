const fs = require('fs');
const path = require('path');

const targetDir = path.join(__dirname, '../lang');

const lans = fs.readdirSync(targetDir).map(l => l.split('.')[0]);
const elLans = fs.readdirSync(path.join(__dirname, '../lang-el')).map(l => l.split('.')[0]);

// for (const lan of lans) {
//   const lanPath = path.join(targetDir, lan);
//   let lanContent = fs.readFileSync(lanPath, { encoding: 'utf-8' });
//   lanContent = JSON.parse(lanContent);
//   lanContent.messagebox = {
//     title: 'Message',
//     confirm: 'OK',
//     cancel: 'Cancel',
//     error: 'Illegal input'
//   };
//   fs.writeFileSync(lanPath, JSON.stringify(lanContent, null, 2));
// }

// 复制 element-ui 的多语翻译
console.log('>>> 复制 element-ui 的多语翻译');

// for (const elLan of elLans) {
//   if (lans.includes(elLan)) {
//     const lanPath = path.join(targetDir, `${elLan}.json`);
//     let lanContent = fs.readFileSync(lanPath, { encoding: 'utf-8' });
//     lanContent = JSON.parse(lanContent);
//     const elLanContent = require(`../lang-el/${elLan}.js`);
//     if (elLanContent) {
//       lanContent.messagebox = elLanContent.el.messagebox;
//       fs.writeFileSync(lanPath, JSON.stringify(lanContent, null, 2));
//     }
//   }
// }

for (const lan of lans) {
  const lanPath = path.join(targetDir, `${lan}.json`);
  let lanContent = fs.readFileSync(lanPath, { encoding: 'utf-8' });
  lanContent = JSON.parse(lanContent);
  lanContent.datePicker.weeks = lanContent.datePicker.weeks.slice(0, 7);
  lanContent.datePicker.weeksShort = lanContent.datePicker.weeksShort.slice(0, 7);
  lanContent.datePicker.weeksMin = lanContent.datePicker.weeksMin.slice(0, 7);
  fs.writeFileSync(lanPath, JSON.stringify(lanContent, null, 2));
}

console.log('>>> done');
