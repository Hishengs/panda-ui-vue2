// 此脚本用于从 new-web 项目提取 date-picker 的多语言信息
const fs = require('fs');
const path = require('path');

const targetDir = path.join(__dirname, 'lang');

const allLans = [
  'de',
  'en-AU',
  'en-CA',
  'en-GB',
  'en-HK',
  'en-IN',
  'en-MY',
  'en-NZ',
  'en-PH',
  'en-SG',
  'en-US',
  'en',
  'es',
  'fr',
  'id',
  'it',
  'ja',
  'ko',
  'ru',
  'th',
  'vi',
  'zh-CN',
  'zh-HK',
  'zh-TW'
];

let lans = fs.readdirSync('./');
lans = lans.filter(l => /^bootstrap-datepicker\.(?!min).+\.js$/.test(l))
  .map(l => l.split('.')[1]);

console.log('>>> lans', lans.length);
const r = /=\s?({(.|\n)+});/;

const keyMap = {
  days: 'weeks',
  daysShort: 'weeksShort',
  daysMin: 'weeksMin',
  months: 'months',
  monthsShort: 'monthsShort',
  today: 'today',
  format: 'format',
  weekStart: 'weekStart'
};

let enTpl;

function dealWithLan (lan) {
  console.log('>>> dealWithLan ', lan);
  const lanPath = path.join(__dirname, `./bootstrap-datepicker.${lan}.js`);
  const lanContent = fs.readFileSync(lanPath, {
    encoding: 'utf-8'
  });
  const res = lanContent.match(r);
  let trans = res && res[[1]];
  let tpl;

  if (trans) {
    tpl = {
      datePicker: {}
    };
    trans = trans.replace(/(\w+):/g, '"$1":');
    // console.log('>>> trans', trans);
    trans = JSON.parse(trans);
    for (const key in trans) {
      if (trans.hasOwnProperty(key) && keyMap[key]) {
        tpl.datePicker[keyMap[key]] = trans[key];
      }
    }
  }

  if (tpl) {
    if (lan === 'en') {
      enTpl = tpl;
    }
    console.log('>>> generating ', lan);
    fs.writeFileSync(path.join(targetDir, `${lan}.json`), JSON.stringify(tpl, null, 2));
  }
}

for (const lan of lans) {
  dealWithLan(lan);
}

const sameWithEn = [];

for (const lan of allLans) {
  if (!lans.includes(lan) && enTpl) {
    sameWithEn.push(lan);
    console.log('>>> generating ', lan);
    fs.writeFileSync(path.join(targetDir, `${lan}.json`), JSON.stringify(enTpl, null, 2));
  }
}

fs.writeFileSync(path.join(targetDir, `lan-info.json`), JSON.stringify({
  all: allLans,
  lans,
  sameWithEn,
}, null, 2));

console.log('\n>>> done.');
