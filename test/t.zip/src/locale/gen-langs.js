const fs = require("fs");
const path = require("path");
const deepmerge = require('deepmerge');

const supportLans = [
  'zh-CN',
  'zh-HK',
  'zh-TW',
  'en-AU',
  'en-CA',
  'en-GB',
  'en-HK',
  'en-IN',
  'en-MY',
  'en-NZ',
  'en-PH',
  'en-SG',
  'en-US',
  'en-BS',
  'es-ES',
  'de-DE',
  'fr-FR',
  'id-ID',
  'it-IT',
  'ja-JP',
  'ko-KR',
  'ru-RU',
  'th-TH',
  'vi-VN'
];

const targetDir = path.resolve(__dirname, './lang');

const template = {
  "DatePicker": {
    "weeks": {
      "sun": "Sun",
      "mon": "Mon",
      "tue": "Tue",
      "wed": "Wed",
      "thu": "Thu",
      "fri": "Fri",
      "sat": "Sat"
    },
    "months": {
      "jan": "Jan",
      "feb": "Feb",
      "mar": "Mar",
      "apr": "Apr",
      "may": "May",
      "jun": "Jun",
      "jul": "Jul",
      "aug": "Aug",
      "sep": "Sep",
      "oct": "Oct",
      "nov": "Nov",
      "dec": "Dec"
    }
  }
};

function genLansFiles (lans = []) {
  for (const lan of lans) {
    const lanPath = path.join(targetDir, `./${lan}.json`);
    if (fs.existsSync(lanPath)) {
      const lanJSON = require(lanPath);
      fs.writeFileSync(lanPath, JSON.stringify(deepmerge(template, lanJSON, ), null, 2));
    } else {
      fs.writeFileSync(lanPath, JSON.stringify(template, null, 2));
    }
  }
}

console.log('>>> generating...');
// specified language
const lan = process.argv[2]
  ? process.argv[2].startsWith('--lan=')
    ? process.argv[2].split('=')[1]
    : ''
  : '';
genLansFiles(lan ? [lan] : supportLans);
console.log('>>> done');
