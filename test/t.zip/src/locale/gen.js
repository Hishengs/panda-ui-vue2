const fs = require("fs");
const path = require("path");

const srcDir = path.join(__dirname, './lang--');
const targetDir = path.join(__dirname, './lang');

const lans = fs.readdirSync(srcDir).filter(l => l.endsWith('.json'));

const weeks = [
  'fnb.week.mon', 'fnb.week.tue', 'fnb.week.wed',
  'fnb.week.thu', 'fnb.week.fri', 'fnb.week.sat', 'fnb.week.sun'
];

for (const lan of lans) {
  const tpl = {
    datePicker: {
      week: {
        //
      },
      month: {},
    }
  };
  const lanJson = JSON.parse(fs.readFileSync(path.join(srcDir, lan)));
  for (const wk of weeks) {
    if (lanJson[wk]) {
      tpl.datePicker.week[wk.slice(9)] = lanJson[wk];
    }
  }
  fs.writeFileSync(path.join(targetDir, lan), JSON.stringify(tpl, null, 2));
}

console.log(lans.length, ', done');
