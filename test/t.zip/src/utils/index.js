import Vue from 'vue';
import * as colorsObj from '../theme/colors';

const colors = Object.keys(colorsObj);
export function getColor (color) {
  if (!color || ['primary', 'secondary', 'success', 'warning', 'info', 'error'].indexOf(color) !== -1) return '';
  return colors.indexOf(color) !== -1 ? colorsObj[color] : color;
};

export function isNotNull (val) {
  return val !== undefined && val !== null;
}

export function isNull (val) {
  return val === undefined || val === null;
}

export function getWidth (w) {
  let width = String(w);
  if (width && width.indexOf('%') === -1 && width.indexOf('px') === -1) width += 'px';
  return width;
}

export function parseWidth (width) {
  if (!['number', 'string'].includes(typeof width)) return width;
  width = String(width).trim();
  if (/^\d+$/.test(width)) {
    width += 'px';
  }
  return width;
}

export function isPc () {
  var uaInfo = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  var agents = ['Android', 'iPhone', 'Windows Phone', 'iPad', 'iPod'];
  var flag = true;
  for (var i = 0; i < agents.length; i++) {
    if (uaInfo.indexOf(agents[i]) > 0) {
      flag = false;
      break;
    }
  }
  return flag;
}

export function retina () {
  // 处理retina屏幕显示效果
  if (isPc()) return;
  var classNames = [];
  const pixelRatio = typeof window !== undefined && window.devicePixelRatio || 1;
  classNames.push('pixel-ratio-' + Math.floor(pixelRatio));
  if (pixelRatio >= 2) {
    classNames.push('retina');
  }

  const html = document.getElementsByTagName('html')[0];

  classNames.forEach((className) => html.classList.add(className));
}

/**
 * 将 String, Object, Array 转成 Array
 */
export function convertClass (classes) {
  let newClasses = [];
  if (!classes) return newClasses;
  if (classes instanceof Array) {
    newClasses = newClasses.concat(classes);
  } else if (classes instanceof Object) {
    for (const name in classes) {
      if (classes[name]) newClasses.push(name);
    }
  } else {
    newClasses = newClasses.concat(classes.split(' '));
  }
  return newClasses;
}

export function createSimpleFunctional (c, el = 'div', name) {
  return {
    name,
    functional: true,

    render: (h, { data, children }) => {
      data.staticClass = (`${c} ${data.staticClass || ''}`).trim();

      return h(el, data, children);
    }
  };
}

export function getFirstComponentChild (children) {
  return children && children.filter(c => c && c.tag)[0];
};

export function isPromise (val) {
  return val && typeof val.then === 'function';
}

export function isObject (val) {
  return val !== null && val && typeof val === 'object' && !Array.isArray(val);
}

export function getObjAttr (obj, attrs) {
  if (!obj || !attrs) return;
  let value = obj;
  attrs.split('.').forEach((key, index) => {
    if (!value) return;
    value = value[key];
  });
  return value;
}

export function setObjAttr (obj, attrs, value) {
  attrs.split('.').forEach((key, index) => {
    if (attrs.length - index <= 1) {
      obj[key] = value;
      return;
    }
    obj = obj[key];
  });
}

export const isServer = Vue.prototype.$isServer;

// Find components upward
export function findComponentsUpward (context, componentName) {
  let parents = [];
  const parent = context.$parent;
  if (parent) {
      if (parent.$options.name === componentName) parents.push(parent);
      return parents.concat(findComponentsUpward(parent, componentName));
  } else {
      return [];
  }
}

// Find components downward
export function findComponentsDownward (context, componentName) {
  return context.$children.reduce((components, child) => {
      if (child.$options.name === componentName) components.push(child);
      const foundChilds = findComponentsDownward(child, componentName);
      return components.concat(foundChilds);
  }, []);
}

// Find components upward
export function findComponentUpward (context, componentName, componentNames) {
  if (typeof componentName === 'string') {
      componentNames = [componentName];
  } else {
      componentNames = componentName;
  }

  let parent = context.$parent;
  let name = parent.$options.name;
  while (parent && (!name || componentNames.indexOf(name) < 0)) {
      parent = parent.$parent;
      if (parent) name = parent.$options.name;
  }
  return parent;
}

// Find component downward
export function findComponentDownward (context, componentName) {
  const childrens = context.$children;
  let children = null;

  if (childrens.length) {
      for (const child of childrens) {
          const name = child.$options.name;
          if (name === componentName) {
              children = child;
              break;
          } else {
              children = findComponentDownward(child, componentName);
              if (children) break;
          }
      }
  }
  return children;
}
