/* 此文件由 gen-entry.js 自动生成，请勿随意改动 */
import './styles/base.scss';
import Alert from './components/Alert';
import Badge from './components/Badge';
import BottomSheet from './components/BottomSheet';
import Breadcrumb from './components/Breadcrumb';
import Button from './components/Button';
import Carousel from './components/Carousel';
import Checkbox from './components/Checkbox';
import Modal from './components/Modal';
import Divider from './components/Divider';
import Drawer from './components/Drawer';
import Collapse from './components/Collapse';
import Grid from './components/Grid';
import LoadMore from './components/LoadMore';
import List from './components/List';
import Pagination from './components/Pagination';
import Picker from './components/Picker';
import DatePicker from './components/DatePicker';
import Progress from './components/Progress';
import Radio from './components/Radio';
import Select from './components/Select';
import Slider from './components/Slider';
import Counter from './components/Counter';
import Steps from './components/Steps';
import Switch from './components/Switch';
import Tabs from './components/Tabs';
import Input from './components/Input';
import Tooltip from './components/Tooltip';
import Loading from './components/Loading';
import Poptip from './components/Poptip';
import Toast from './components/Toast';
import Helpers from './components/Helpers';
import Icon from './components/Icon';
import CardSwiper from './components/CardSwiper';
import TreeSelect from './components/TreeSelect';
import Tag from './components/Tag';
import TagSelect from './components/TagSelect';
import Dropdown from './components/Dropdown';
import './styles/theme.scss';
import theme from './theme';
import * as Colors from './theme/colors';
import * as locale from "./locale";

const version = '__VERSION__';
const components = {
  Alert,
  Badge,
  BottomSheet,
  Breadcrumb,
  Button,
  Carousel,
  Checkbox,
  Modal,
  Divider,
  Drawer,
  Collapse,
  Grid,
  LoadMore,
  List,
  Pagination,
  Picker,
  DatePicker,
  Progress,
  Radio,
  Select,
  Slider,
  Counter,
  Steps,
  Switch,
  Tabs,
  Input,
  Tooltip,
  Loading,
  Poptip,
  Toast,
  Helpers,
  Icon,
  CardSwiper,
  TreeSelect,
  Tag,
  TagSelect,
  Dropdown
};

function install (Vue, opts = {}) {
  locale.use(opts.locale);
  locale.i18n(opts.i18n);
  Object.keys(components).forEach((key) => {
    Vue.use(components[key]);
  });
}

if (typeof window !== 'undefined' && window.Vue) install(window.Vue);

export {
  version,
  Colors,
  locale,
  Alert,
  Badge,
  BottomSheet,
  Breadcrumb,
  Button,
  Carousel,
  Checkbox,
  Modal,
  Divider,
  Drawer,
  Collapse,
  Grid,
  LoadMore,
  List,
  Pagination,
  Picker,
  DatePicker,
  Progress,
  Radio,
  Select,
  Slider,
  Counter,
  Steps,
  Switch,
  Tabs,
  Input,
  Tooltip,
  Loading,
  Poptip,
  Toast,
  Helpers,
  Icon,
  CardSwiper,
  TreeSelect,
  Tag,
  TagSelect,
  Dropdown,
  theme,
  install,
};

export default {
  version,
  install,
  theme,
  Colors,
  locale,
  ...components
};
