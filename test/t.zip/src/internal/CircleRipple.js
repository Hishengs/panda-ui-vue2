import '../styles/components/circle-ripple.scss';

export default {
  props: {
    mergeStyle: {
      type: Object,
      default () {
        return {};
      }
    },
    color: {
      type: String,
      default: ''
    },
    opacity: {
      type: Number
    }
  },
  computed: {
    styles () {
      return {
        color: this.color,
        opacity: this.opacity,
        ...this.mergeStyle
      };
    }
  },
  render (h) {
    return h('transition', {
      props: {
        name: 'klk-ripple',
        appear: true
      }
    }, [
      h('div', {
        class: 'klk-circle-ripple',
        style: this.styles
      })
    ]);
  }
};
