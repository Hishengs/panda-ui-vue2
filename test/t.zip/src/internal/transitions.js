import '../styles/transitions.scss';
export { default as ExpandTransition } from './ExpandTransition';

function createTransition (name, mode) {
  return {
    name,
    functional: true,
    render (h, context) {
      context.data = context.data || {};
      context.data.props = { name };
      context.data.on = context.data.on || {};
      if (!Object.isExtensible(context.data.on)) {
        context.data.on = { ...context.data.on };
      }

      if (mode) context.data.props.mode = mode;

      return h('transition', context.data, context.children);
    }
  };
}

export const FadeTransition = createTransition('klk-fade-transition');
export const SlideTopTransition = createTransition('klk-slide-top-transition');
export const SlideBottomTransition = createTransition('klk-slide-bottom-transition');
export const SlideLeftTransition = createTransition('klk-slide-left-transition');
export const SlideRightTransition = createTransition('klk-slide-right-transition');
export const PopoverTransiton = createTransition('klk-popover-transition');
export const BottomSheetTransition = createTransition('klk-bottom-sheet-transition');
export const ScaleTransition = createTransition('klk-scale-transition');
