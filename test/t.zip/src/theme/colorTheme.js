export default (theme) => {
  return `
  .klk-primary-color {
    background-color: ${theme.primary};
  }
  .klk-secondary-color {
    background-color: ${theme.secondary};
  }
  .klk-success-color {
    background-color: ${theme.success};
  }
  .klk-warning-color {
    background-color: ${theme.warning};
  }
  .klk-info-color {
    background-color: ${theme.info};
  }
  .klk-error-color {
    background-color: ${theme.error};
  }
  .klk-inverse {
    color: #fff;
  }
  .klk-primary-text-color {
    color: ${theme.primary};
  }
  .klk-secondary-text-color {
    color: ${theme.secondary};
  }
  .klk-success-text-color {
    color: ${theme.success};
  }
  .klk-warning-text-color {
    color: ${theme.warning};
  }
  .klk-info-text-color {
    color: ${theme.info};
  }
  .klk-error-text-color {
    color: ${theme.error};
  }
  `;
};
