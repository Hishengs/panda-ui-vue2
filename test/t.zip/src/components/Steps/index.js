import '../../styles/components/steps.scss';
import Steps from './steps.vue';
import Step from './step.vue';

Steps.install = function (Vue) {
  Vue.component(Steps.name, Steps);
  Vue.component(Step.name, Step);
};

export { Steps, Step };
export default Steps;
