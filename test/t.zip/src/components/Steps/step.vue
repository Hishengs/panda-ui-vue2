<template>
  <div :class="wrapClasses">
    <!-- Step 之间的连线 -->
    <div
      :class="{
        [prefixCls + '-line-track']: true,
        [prefixCls + '-line-track-half']: this.showTip,
      }"
      :style="styles.lineTrack"
    >
      <div :class="[prefixCls + '-line']" :style="styles.line"></div>
    </div>
    <!-- Step 头部 -->
    <div :class="[prefixCls + '-head']">
      <div :class="[prefixCls + '-head-inner']">
        <div
          :class="{
            [prefixCls + '-icon']: true,
            [prefixCls + '-icon-slot']: !!$slots.icon,
            [prefixCls + '-icon-dot']: !$slots.icon && isDot,
          }"
          :style="styles.icon"
        >
          <slot name="icon">
            <template v-if="!isDot">
              <Icon v-if="icon" :type="icon" :size="iconSize"></Icon>
              <template v-else>
                <svg v-if="currentStatus === 'process'" style="fill: currentColor;" t="1582600127399" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4619" :width="iconSize" :height="iconSize" xmlns:xlink="http://www.w3.org/1999/xlink">
                  <defs></defs>
                  <path d="M512 0c282.784 0 512 229.216 512 512s-229.216 512-512 512S0 794.784 0 512 229.216 0 512 0zM312 448a56 56 0 1 0 0 112 56 56 0 0 0 0-112z m186.656 0a56 56 0 1 0 0 112 56 56 0 0 0 0-112z m186.688 0a56 56 0 1 0 0 112 56 56 0 0 0 0-112z" p-id="4620"></path>
                </svg>
                <svg v-else-if="currentStatus === 'finish'" style="fill: currentColor;" t="1582600551616" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="4896" xmlns:xlink="http://www.w3.org/1999/xlink" :width="iconSize" :height="iconSize">
                  <defs></defs>
                  <path d="M512 0c282.784 0 512 229.216 512 512s-229.216 512-512 512S0 794.784 0 512 229.216 0 512 0z m218.368 335.488l-286.016 301.92-139.2-142.208-34.304 33.6 174.08 177.792 320.288-338.08-34.848-33.024z" p-id="4897"></path>
                </svg>
              </template>
            </template>
          </slot>
        </div>
      </div>
    </div>
    <!-- Step 主体 -->
    <div :class="[prefixCls + '-main']" :style="styles.main" ref="main">
      <div :class="[prefixCls + '-title']"><slot name="title">{{ title }}</slot></div>
      <div :class="[prefixCls + '-content']" v-if="content || $slots.content">
        <slot name="content">{{ content }}</slot>
      </div>
    </div>
    <!-- trigger -->
    <!-- 用于 Poptip 定位 -->
    <div
      v-if="showTip"
      ref="poptipTrigger"
      :class="[prefixCls + '-poptip-trigger']"
      :style="styles.poptipTrigger"
    ></div>
    <!-- poptip -->
    <div :class="[prefixCls + '-tip']" v-if="showTip" ref="tip">
      <div :class="[prefixCls + '-tip-arrow']"></div>
      <div :class="[prefixCls + '-tip-inner']" ref="tipInner">
        <slot name="tip">
          <div :class="[prefixCls + '-tip-icon']" v-if="tipIcon">
            <Icon :type="tipIcon" :size="24"></Icon>
          </div>
          <div :class="[prefixCls + '-tip-main']">
            <h4 :class="[prefixCls + '-tip-title']" v-if="tipTitle">
              {{ tipTitle }}
            </h4>
            <div :class="[prefixCls + '-tip-content']" v-if="tipContent">
              {{ tipContent }}
            </div>
          </div>
        </slot>
      </div>
    </div>
  </div>
</template>

<script>
  import Emitter from '../../mixins/emitter';
  import Icon from '../Icon';
  import { createPopper } from '@popperjs/core';

  const prefixCls = 'klk-step';
  const iconPrefixCls = 'klk-icon';

  let zIndex = 999;

  export default {
    name: 'klk-step',
    mixins: [ Emitter ],
    components: {
      Icon,
    },
    props: {
      status: {
        validator (value) {
          return ['wait', 'process', 'finish', 'error'].includes(value);
        }
      },
      title: {
        type: String,
        default: ''
      },
      content: {
        type: String
      },
      icon: {
        type: String
      },
      tipTitle: String,
      tipContent: String,
      tipIcon: String,
    },
    data () {
      return {
        prefixCls: prefixCls,
        stepNumber: '',
        nextError: false,
        total: 1,
        currentStatus: '',
        isDot: false,
        tipHeight: 0,
        tipWidth: 0,
        mainWidth: 0,
        mainHeight: 0,
        isVertical: false,
        poptip: null,
      };
    },
    computed: {
      showTip () {
        return !!(this.tipTitle || this.tipContent || this.tipIcon) || this.$slots.tip;
      },
      wrapClasses () {
        return [
          `${prefixCls}`,
          `${prefixCls}-status-${this.currentStatus}`,
          {
            [`${prefixCls}-next-error`]: this.nextError
          }
        ];
      },
      iconType () {
        let icon = '';
        if (this.icon) {
          icon = this.icon;
        } else {
          if (this.currentStatus === 'finish') {
            icon = 'correct-fill';
          } else if (this.currentStatus === 'process') {
            icon = 'processing-fill';
          } else if (this.currentStatus === 'error') {
            icon = 'error-fill';
          }
        }
        return icon;
      },
      statusColor () {
        return this.$parent[`${this.currentStatus}Color`];
      },
      styles () {
        return {
          dot: {
            backgroundColor: this.statusColor,
          },
          iconEmpty: {
            color: this.statusColor,
            backgroundColor: this.statusColor,
          },
          icon: {
            color: this.statusColor,
            backgroundColor: this.currentStatus === 'wait' ? this.statusColor : ''
          },
          lineTrack: {
            backgroundColor: this.$parent.waitColor,
          },
          line: {
            backgroundColor: this.currentStatus === 'finish' ? this.statusColor : this.$parent.waitColor,
          },
          main: {
            paddingBottom: this.isVertical && !!this.tipHeight ? `${this.tipHeight+16}px` : '',
            marginBottom: !this.isVertical && !!this.tipHeight ? `${this.tipHeight+13}px` : '',
          },
          tip: this.showTip ? {
            zIndex: zIndex++,
            transform: !this.isVertical ? `translateX(-${this.tipWidth/2}px)` : '',
          } : {},
          tipArrow: this.showTip ? {
            left: !this.isVertical ? `${this.tipWidth/2}px` : ''
          } : {},
          poptipTrigger: {
            transform: !this.isVertical
              ? `translateY(-${this.tipHeight}px)`
              : `translateY(-${this.tipHeight/2}px)`
          },
        };
      },
      lineStyle () {
        return {
          backgroundColor: this.$parent.finishColor,
        };
      },
      iconSize () {
        return this.isVertical ? 24 : 32;
      }
    },
    watch: {
      status (val) {
        this.currentStatus = val;
        if (this.currentStatus === 'error') {
          this.$parent.setNextError();
        }
      }
    },
    created () {
      this.currentStatus = this.status;
      this.isDot = this.$parent.type === 'dot';
    },
    mounted () {
      this.dispatch('Steps', 'append');
      this.isVertical = this.$parent.direction === 'vertical';
      if (this.showTip) {
        this.tipHeight = parseFloat(window.getComputedStyle(this.$refs.tip)['height']);
        this.tipWidth = parseFloat(window.getComputedStyle(this.$refs.tipInner)['width']);
        this.mainWidth = parseFloat(window.getComputedStyle(this.$refs.main)['width']);
        this.mainHeight = parseFloat(window.getComputedStyle(this.$refs.main)['height']);
      }
      if (this.showTip) {
        this.poptip = createPopper(this.$refs.poptipTrigger, this.$refs.tip, {
          placement: this.isVertical ? 'right' : 'bottom',
          modifiers: [
            {
              name: 'flip',
              enabled: false,
            },
            {
              name: 'preventOverflow',
              enabled: false,
            },
          ]
        });
        setTimeout(() => {
          this.poptip.update();
        }, 1000);
      }
    },
    beforeDestroy () {
      this.dispatch('Steps', 'remove');
    }
  };
</script>
