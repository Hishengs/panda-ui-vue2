export default (theme) => {
  return `
  .klk-slide-picker{
    background: ${theme.background.paper};
  }
  .klk-slide-picker-center-highlight {
    border-top-color: ${theme.divider};
    border-bottom-color: ${theme.divider};
  }
  .klk-slide-picker-slot.klk-slide-picker-slot-divider{
    color: ${theme.text.primary};
  }
  .klk-slide-picker-item{
    color: ${theme.text.secondary};
  }
  .klk-slide-picker-item.selected {
    color: ${theme.text.primary};
  }
  `;
};
