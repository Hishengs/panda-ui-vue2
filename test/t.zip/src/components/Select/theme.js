import { fade } from '../../utils/colorManipulator';

export default (theme) => {
  return `
  .klk-select-content {
    color: ${theme.text.primary};
  }
  .klk-select-input {
    color: ${theme.text.primary};
  }
  .klk-selection-text.is-active {
    color: ${theme.primary};
  }
  .klk-select-no-data {
    color: ${theme.text.disabled};
  }
  .klk-option.is-selected .klk-item {
    color: ${theme.secondary};
  }
  .klk-option.is-focused {
    color: ${theme.secondary};
    background-color: ${fade(theme.text.primary, 0.1)};
  }
  .klk-option.is-disabled .klk-item {
    color: ${theme.text.disabled};
  }
  `;
};
