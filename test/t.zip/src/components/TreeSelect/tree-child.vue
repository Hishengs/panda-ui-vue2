<template>
    <div>
        <div
            v-if="hideDisabled ? !tree.disable : true"
            class="checkbox-tree-item"
        >
            <klk-checkbox
                v-model="checked"
                :value="tree.value"
                :disabled="tree.disable ? true : false"
                :indeterminate="iconStatus === 0"
                @change="toggleChecked"
            >
              {{ tree.label }}
            </klk-checkbox>

            <div
                v-if="isParent"
                class="checkbox-tree-expand"
                @click="toggleExpand"
            >
                <klk-icon
                    size="24"
                    :type="isExpand ? 'icon_navigation_chevron_up' : 'icon_navigation_chevron_down'"
                >
                </klk-icon>
            </div>
        </div>

        <div v-if="isParent" v-show="isExpand" class="checkbox-tree">
            <klk-tree-child
                v-for="(childtree, index) in tree.children"
                :key="index"
                :tree="childtree"
                :parent-ids="[...parentIds, tree.value]"
                :parent-index="[...parentIndex, index]"
                :depth="depth + 1"
                @child-change="childChange"
            />
        </div>
    </div>
</template>

<script lang="ts">
import { Vue, Component, Prop, Watch, Inject } from 'vue-property-decorator';
import { TreeData, addTree, removeTree } from './util';
import KlkCheckbox from '../Checkbox/Checkbox';
import KlkIcon from '../Icon/index.js';

@Component({
    name: 'klk-tree-child',
    components: {
      KlkCheckbox,
      KlkIcon
    },
})
export default class KlkTreeChild extends Vue {
    private get isParent() {
        const { tree } = this;
        return tree.children ? tree.children.length > 0 : false;
    }

    private get values() {
        return this.getValues();
    }

    private get treelist() {
        return this.getTreelist();
    }

    @Inject() public readonly getValues!: () => any[];
    @Inject() public readonly getTreelist!: () => any[];
    @Prop({
        default: {},
    })
    private readonly tree!: TreeData;

    @Prop({
        default: 0,
    })
    private readonly depth!: number;

    @Prop({
        default: false,
    })
    private readonly hideDisabled!: boolean;

    @Prop({
        default: () => [],
    })
    private readonly parentIds!: number[];

    @Prop({
        default: () => [],
    })
    private readonly parentIndex!: number[];

    private isExpand = false;
    private checked = false;
    private iconStatus: number = -1; // 子树未选中： -1, 有子树选中且未全选：0, 子树全选中：1

    @Watch('values', { immediate: true })
    private onvalueschange() {
        const { tree, depth } = this;
        if (this.tree.disable) {
            this.iconStatus = -1;
            this.checked = false;
        } else {
            this.iconStatus = this.values[this.depth].includes(this.tree.value)
                ? 1
                : -1;
            this.checked = this.iconStatus !== -1;
        }
        if (tree.children) {
            if (this.everyChildren(tree, depth)) {
                this.iconStatus = 1;
                this.checked = true;
            } else if (this.someChildren(tree, depth)) {
                this.iconStatus = 0;
                this.checked = true;
            } else {
                this.iconStatus = -1;
                this.checked = false;
            }
        }
    }

    private someChildren(tree: TreeData, depth: number): boolean {
        const result = false;
        const that = this;
        if (tree.children) {
            const available = tree.children; // .filter(child => !child.disable);
            const values = available.map(child => child.value);
            const ids = this.values[depth + 1];
            const hadChildren = available.filter(child => child.children);
            if (hadChildren.length) {
                return hadChildren.some(child =>
                    that.someChildren(child, depth + 1),
                );
            } else {
                return (
                    !!ids.length && values.some(value => ids.includes(value))
                );
            }
        }
        return result;
    }
    private everyChildren(tree: TreeData, depth: number): boolean {
        const result = false;
        const that = this;
        if (tree.children) {
            const available = tree.children; // .filter(child => !child.disable);
            const values = available.map(child => child.value);
            const ids = this.values[depth + 1];
            const hadChildren = available.filter(child => child.children);
            if (hadChildren.length) {
                return hadChildren.every(child =>
                    that.everyChildren(child, depth + 1),
                );
            } else {
                return ids.length > 0 && values.length > 0
                    ? values.every(value => ids.includes(value))
                    : false;
            }
        }
        return result;
    }

    private childChange() {
        const { treelist, values, depth, tree, parentIds, parentIndex } = this;
        const isAllChildrenChecked = this.everyChildren(tree, depth);
        const depthValue = values[depth];
        const index = depthValue.indexOf(tree.value);

        // add value to values
        if (index === -1 && isAllChildrenChecked) {
            this.$set(this.values, depth, [...values[depth], tree.value]);
        }

        // remove value from values
        if (index !== -1 && !isAllChildrenChecked) {
            depthValue.splice(index, 1);
            this.$set(this.values, depth, depthValue);
        }

        this.$emit('child-change');
    }

    private toggleChecked() {
        const { depth, tree } = this;
        const checked = this.iconStatus !== -1;
        if (checked) {
            // iconStatus = 0 或 1 时，移除所有子选项
            removeTree(tree, this.values, depth);
        } else {
            // iconStatus = -1 时，添加所有子选项
            addTree(tree, this.values, depth);
        }
        this.$emit('child-change');
    }

    private toggleExpand() {
        this.isExpand = !this.isExpand;
    }
}
</script>

<style></style>
