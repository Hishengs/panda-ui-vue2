# vue-tree

## dependencies

依赖于 `klook-ui` 的 `klk-checkbox` 组件

>klook-ui 的 klk-checkbox 依赖[material-icons](https://material.io/icons/)。参见[文档](https://klook-ui.org/#/zh-CN/installation)

## usage

main.js

```js
import Vue from 'vue';
import KlookUI from 'klook-ui';
import 'klook-ui/dist/klook-ui.css';

Vue.use(KlookUI);
```

App.vue

```html
<template>
  <div id="app">
    <section class="wrapper">
      <div class="half">
        <vue-tree
          :treelist="data"
          v-model="values">
        </vue-tree>
      </div>
      <div class="half">
        <p>values: {{values}}</p>
        <hr>
        <p>labels:</p>
        <ul>
          <li v-for="(tree, index) of labels" :key="index">
            <span>{{ tree.label }}</span>
            <i class="material-icons" @click="removeItem(tree.depth, tree.value)">delete</i>
          </li>
        </ul>
      </div>
    </section>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import VueTree, { getInitalValues, getTreeByValuesWrapper } from '@/components/tree/Tree.vue';
import { data } from './mock';
import { TreeData } from '@/components/tree/util';

@Component({
  components: {
    VueTree,
  },
})
export default class App extends Vue {
  public data = data;
  public values = [[], [2], [28, 2, 3]];
  public values1 = getInitalValues(data);

  get labels() {
    const values = this.values;
    const wrapperFn = getTreeByValuesWrapper(data);
    const labels = wrapperFn(data, values);
    return labels.flat(); // array.flat not exist in nodejs
  }

  public removeItem(depth: number, value: any) {
    // change values
    const i = this.values[depth].indexOf(value);
    this.values[depth].splice(i, 1);
    // trigger change event
    (this.$el.querySelector(`#tree-${depth}-${value}`) as HTMLElement).click();
  }
}
</script>
```

## C 端功能点

+ [x] tree 渲染
+ [ ] checkbox 状态，未选中，选中，半选中（当前有选中，且选中个数小于总个数）
+ [ ] event
  + [ ] 当点击半选中的 checkbox 时，不选中，当前的值，只处理其子树
+ [ ] expand transition: 0.3s all ease-in-out
+ [ ] props
  + [x] treelist: 渲染列表
  + [x] v-model: values。渲染列表 checkbox 状态
+ [x] tags
  + [x] tag 展示：根据 values 展示 treelist 的 label
  + [x] tag 删除：点击 tag，更新 values
+ [ ] 联动
  + [ ] values 已有值时，如果 treelist 更新，则需要对 values 进行处理。
