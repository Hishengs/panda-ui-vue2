<template>
    <div class="checkbox-tree">
        <klk-tree-child
            v-for="(tree, index) in treelist"
            :key="index"
            :tree="tree"
            :parent-ids="parentIds"
            :parent-index="[index]"
            :depth="depth"
        />
    </div>
</template>

<script lang="ts">
import {
    Vue,
    Component,
    Watch,
    Prop,
    Model,
    Provide,
} from 'vue-property-decorator';
import KlkTreeChild from './tree-child.vue';
import {
    TreeData,
    getTreeDepth,
    getInitalValues,
    getTreeByValuesWrapper,
    removeTree,
    getListByDepth,
} from './util';

export {
    TreeData,
    getTreeDepth,
    getInitalValues,
    getTreeByValuesWrapper,
    removeTree,
    getListByDepth,
};

@Component({
    components: {
        KlkTreeChild,
    },
})
export default class KlkTreeSelect extends Vue {
    @Prop({
        default: () => [],
    })
    private readonly treelist!: TreeData[];
    @Model('change', { type: Array }) private readonly values!: any[];

    private parentIds: any = [];
    private depth = 0;

    @Provide() public getValues = () => this.values;
    @Provide() public getTreelist = () => this.treelist;
}
</script>

<style lang="css">
.checkbox-tree {
    position: relative;
    width: 100%;
    padding-left: 16px;

}
.checkbox-tree-item {
    position: relative;
    display: flex;
    width: 100%;
    height: 48px;
    align-items: center;
    text-align: left;
}

.checkbox-tree .klk-checkbox-wrapper {
    justify-content: start !important;
    height: 100% !important;
    align-items: center !important;

}
.checkbox-tree .klk-checkbox-label {
    flex: 1;
    border-bottom: 1px solid #e0e0e0;
    height: 100%;
    display: flex;
    align-items: center;
}

.checkbox-tree-expand {
    width: 48px;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    border-bottom: 1px solid #e0e0e0;
}
.disabled + .checkbox-tree-expand {
    color: rgba(0, 0, 0, 0.38);
}
.checkbox-tree .klk-checkbox {
    display: flex;
    flex: 1;
    width: 100%;
    height: 100% !important;
    align-items: center;
}
</style>
