import TreeSelect from './tree-select.vue';
import TreeChild from './tree-child.vue';
import {
  TreeData,
  getTreeDepth,
  getInitalValues,
  getTreeByValuesWrapper,
  removeTree,
  addTree,
  getListByDepth,
} from './util';

TreeSelect.install = function (Vue) {
  Vue.component('klk-tree-child', TreeChild);
  Vue.component('klk-tree-select', TreeSelect);
}

export { TreeSelect, TreeChild };
export default TreeSelect;

export {
  TreeData,
  getTreeDepth,
  getInitalValues,
  getTreeByValuesWrapper,
  removeTree,
  addTree,
  getListByDepth,
};
