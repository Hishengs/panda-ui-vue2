export class Expand {
    isExpand?: boolean;
    [key: string]: any;
}

export class TreeData extends Expand {
    label: string = '';
    value: any;
    disable?: boolean;
    children?: TreeData[];
}

/**
 * 根据数组获取数据层级数
 * @param list 节点数组
 * @param depth 当前节点的深度
 * @return 返回数据层级数
 */
export function getTreeDepth(list: TreeData[], depth = 1): number {
    const hasChildren = list.filter(item => item.children);
    if (!hasChildren.length) {
        return depth;
    }

    const children: TreeData[] = [];
    hasChildren.forEach(item => {
        children.push(...(item.children as TreeData[]));
    });
    return getTreeDepth(children, depth + 1);
}

/**
 * 获取长度为数组深度的空数组列表
 * @param list 节点数组，用来获取数组长度
 * @return 空数组列表
 */
export function getInitalValues(list: TreeData[]): any[] {
    const depth = getTreeDepth(list);
    return Array.from({ length: depth }, () => []);
}

/**
 * 根据组件返回的 values 值，获取最顶层 tree
 * @param treelist 节点数组
 * @param values 组件返回的 values 值
 * @return 返回最顶层 tree
 */
export function getTreeByValuesWrapper(list: TreeData[]) {
    const res = getInitalValues(list);
    return function walkTreeList(
        treelist: TreeData[],
        values: any[],
        depth = 0,
    ) {
        treelist.forEach((item: TreeData) => {
            const isItemChecked = values[depth].includes(item.value);
            if (!isItemChecked) {
                if (item.children) {
                    walkTreeList(item.children, values, depth + 1);
                }
            } else {
                item.depth = depth;
                (res[depth] as any[]).push(item);
            }
        });
        return res;
    };
}

/**
 * 删除索引为 depth 值为 value 的树，及其子树的值。返回新的 values 值
 * @param tree 指定树
 * @param values 原始 values
 * @param depth 树的层级
 * @return 返回新的 values 值
 */
export function removeTree(
    tree: TreeData,
    values: any[],
    depth: number,
): any[] {
    const index = values[depth].indexOf(tree.value);
    if (index !== -1) {
        values[depth].splice(index, 1);
    }

    if (tree.children) {
        tree.children
            .filter(child => !child.disable)
            .forEach(child => {
                removeTree(child, values, depth + 1);
            });
    }
    return values;
}

export function addTree(tree: TreeData, values: any[], depth: number): any[] {
    const index = values[depth].indexOf(tree.value);
    if (index === -1) {
        values[depth].push(tree.value);
    }

    if (tree.children) {
        const disabled = tree.children.filter(child => child.disable);
        if (disabled.length && index === -1) {
            values[depth].splice(index, 1);
        }

        tree.children
            .filter(child => !child.disable)
            .forEach(child => {
                addTree(child, values, depth + 1);
            });
    }
    return values;
}

/**
 * 根据 depth 获取当前 depth 的有效数组
 * @param   treelist 节点数组
 * @param   depth 当前节点的深度
 * @return  返回当前 depth 的有效数组
 */
export function getListByDepth(treelist: TreeData[], depth = 0): TreeData[] {
    let result: TreeData[] = [];
    if (depth > 0) {
        treelist
            .filter(child => !child.disable)
            .filter(child => child.children)
            .forEach(child => {
                result.push(
                    ...getListByDepth(child.children as TreeData[], depth - 1),
                );
            });
    } else {
        result = treelist.filter(child => !child.disable);
    }
    return result;
}
