import '../../styles/components/slider.scss';
import Slider from './Slider.vue';

Slider.install = function (Vue) {
  Vue.component(Slider.name, Slider);
};

export default Slider;
