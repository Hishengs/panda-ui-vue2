<template>
  <vue-slider
    class="klk-slider"
    v-model="val"
    :min='min'
    :max='max'
    :height="height"
    :interval="step"
    :disabled="disabled"
    @change="onChange"
  ></vue-slider>
</template>

<script>
  import _debounce from 'lodash/debounce';
  const VueSlider = require('vue-slider-component');

  export default {
    name: 'klk-slider',
    components: {
      VueSlider,
    },
    props: {
      min: {
        type: Number,
        default: 0,
      },
      max: {
        type: Number,
        default: 100,
      },
      step: Number,
      value: {
        type: [Number, Array],
        required: true,
        validator (val) {
          const type = Reflect.toString.call(val).slice(8, -1).toLowerCase();
          return ['number', 'array'].includes(type);
        }
      },
      disabled: Boolean,
    },
    data () {
      return {
        val: this.value,
        height: 4,
      };
    },
    watch: {
      val (newVal) {
        this.$emit('input', newVal);
      },
      value (newVal) {
        this.val = newVal;
      },
    },
    methods: {
      onChange (e) {
        this.$emit('change', this.val);
      }
    }
  };
</script>
