<template>
  <klk-fade-transition>
    <div :class="classes" v-if="fullscreenVisible" :style="cStyle">
      <!-- 背景容器 -->
      <div :class="bgClasses" :style="cBgStyle">
        <div class="klk-loading-icon">
          <slot name="icon">
            <svg class="klk-loading-spin-icon" width="24px" height="24px" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
              <g id="loading-24" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
              <circle id="椭圆形" stroke="#E0E0E0" stroke-width="3" opacity="0.290573847" cx="12" cy="12" r="10"></circle>
              <path d="M21.519964,15.069885 C21.8316477,14.1025914 22,13.0709561 22,12 C22,7.53784517 19.0774291,3.75829335 15.0420573,2.47111451" id="椭圆形" stroke="#FF5722" stroke-width="3" stroke-linecap="round"></path>
              </g>
            </svg>
          </slot>
        </div>
        <div class="klk-loading-title" v-if="title">{{ title }}</div>
        <div :class="textClasses" v-if="showText"><slot>{{ text }}</slot></div>
      </div>
    </div>
  </klk-fade-transition>
</template>

<script>
  import Vue from 'vue';
  import Helpers from '../Helpers';
  import ScrollbarMixins from './mixins-scrollbar';

  Vue.use(Helpers);

  const prefixCls = 'klk-loading';

  export default {
    name: 'klk-loading',
    mixins: [ ScrollbarMixins ],
    props: {
      fullscreen: {
        type: Boolean,
        default: false
      },
      title: String,
      text: String,
      showLoadingBg: {
        type: Boolean,
        default: false,
      },
      showOverlay: {
        type: Boolean,
        default: false,
      },
      overlayColor: {
        type: String,
        default: 'rgba(0,0,0,0.6)',
      }
    },
    data () {
      return {
        showText: false,
        visible: false,
        iconOnly: false,
      };
    },
    computed: {
      classes () {
        return [
          `${prefixCls}`,
          {
            [`${prefixCls}-show-text`]: this.showText,
            [`${prefixCls}-fullscreen`]: this.fullscreen,
            [`${prefixCls}-icon-only`]: this.iconOnly,
          }
        ];
      },
      cStyle () {
        return {
          backgroundColor: this.showOverlay ? this.overlayColor : 'transparent'
        };
      },
      cBgStyle () {
        return {
          backgroundColor: this.showLoadingBg ? '#fff' : 'transparent',
        };
      },
      bgClasses () {
        return `${prefixCls}-bg`;
      },
      textClasses () {
        return `${prefixCls}-text`;
      },
      fullscreenVisible () {
        if (this.fullscreen) {
          return this.visible;
        } else {
          return true;
        }
      }
    },
    watch: {
      visible (val) {
        if (val) {
          this.addScrollEffect();
        } else {
          this.removeScrollEffect();
        }
      }
    },
    mounted () {
      this.showText = !!this.text || this.$slots.default !== undefined;
      this.iconOnly = !this.title && !this.text && !this.$slots.default;
    }
  };
</script>
