import '../../styles/components/loading.scss';
import Loading from './loading';
import { directive } from './v-loading';
import { isServer } from '../../utils';

let curLoading;

let loadingConfig = {
  showOverlay: true,
};

function showLoading (config) {
  if (isServer) return;
  if (curLoading) return;
  config = Object.assign({}, loadingConfig, config);
  const render = ('render' in config) ? config.render : undefined;
  if (render) {
    delete config.render;
  }
  let instance = Loading.newInstance(config, render);
  instance.show();
  curLoading = {
    component: instance.component,
    close () {
      if (instance) {
        instance.remove(() => {
          instance = null;
        });
      }
    }
  };
}

function hideLoading () {
  if (curLoading) {
    curLoading.close();
    curLoading = null;
  }
}

Loading.install = function (Vue) {
  Vue.component(Loading.name, Loading);
  Vue.prototype.$showLoading = showLoading;
  Vue.prototype.$hideLoading = hideLoading;
  Vue.directive(directive.name, directive);
}

export default Loading;
