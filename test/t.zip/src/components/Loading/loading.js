import Vue from 'vue';
import Loading from './loading.vue';

// import { transferIndex, transferIncrease } from '../../utils/transfer-queue';

let transferIndex = 999;

function transferIncrease () {
  return transferIndex++;
}

function handleGetIndex() {
  transferIncrease();
  return transferIndex;
}

let tIndex = handleGetIndex();

Loading.newInstance = (props = {}, render) => {
  const Instance = new Vue({
    render (h) {
      let vnode = '';
      if (render) {
        vnode = h(Loading, {
          props: {
            fix: true,
            fullscreen: true,
            ...props,
          }
        }, [render(h)]);
      } else {
        vnode = h(Loading, {
          props: {
            size: 'large',
            fix: true,
            fullscreen: true,
            ...props
          }
        });
      }
      return h('div', {
        'class': 'klk-loading-fullscreen klk-loading-fullscreen-wrapper',
        'style': {
          'z-index': 2010 + tIndex
        }
      }, [vnode]);
    }
  });

  const component = Instance.$mount();
  document.body.appendChild(component.$el);
  const loading = Instance.$children[0];

  return {
    show () {
      loading.visible = true;
      tIndex = handleGetIndex();
    },
    remove (cb) {
      loading.visible = false;
      setTimeout(function() {
        loading.$parent.$destroy();
        if (document.getElementsByClassName('klk-loading-fullscreen')[0] !== undefined) {
          document.body.removeChild(document.getElementsByClassName('klk-loading-fullscreen')[0]);
        }
        cb();
      }, 500);
    },
    component: loading
  };
};

export default Loading;
