// support v-loading
import Vue from 'vue';
import Loading from './loading.vue';

const defaultProps = {
  showOverlay: true,
};

const camelizeRE = /-(\w)/g;
const camelize = str => {
  return str.replace(camelizeRE, (_, c) => c ? c.toUpperCase() : '');
}

function getAttrVal (el, attr, fn) {
  const name = `data-klk-loading-${attr}`;
  if (el.hasAttribute(name)) {
    return fn ? fn(el.getAttribute(name)) : el.getAttribute(name);
  }
}

function setProp (obj, prop, value) {
  if (value !== undefined) {
    obj[camelize(prop)] = value;
  }
}

function updateProps (el) {
  const props = el._loading ? el._loading.props : Object.assign({}, defaultProps);
  setProp(props, 'title', getAttrVal(el, 'title'));
  setProp(props, 'text', getAttrVal(el, 'text'));
  setProp(props, 'show-loading-bg', getAttrVal(el, 'show-loading-bg', val => val === 'true'));
  setProp(props, 'show-overlay', getAttrVal(el, 'show-overlay', val => val === 'true'));
  setProp(props, 'overlay-color', getAttrVal(el, 'overlay-color'));
  return props;
}

function initLoading (el, isLoading) {
  if (el._loading) return;
  const props = updateProps(el);
  const loading = new Vue({
    el: document.createElement('div'),
    render (h) {
      return this.show ? h('Loading', {
        props: {
          ...this.props,
        },
      }) : null;
    },
    components: {
      Loading,
    },
    data: {
      props,
      show: isLoading,
    },
  });
  el.appendChild(loading.$el);
  el._loading = loading;
}

function updateLoading (el, isLoading) {
  if (!el._loading) {
    initLoading(el, isLoading);
    return;
  }
  const loading = el._loading;
  loading.show = isLoading;
  updateProps(el);
}

function removeLoading (el) {
  if (!el._loading) return;
  let loading = el._loading;
  el._loading = null;
  loading.show = false;
  setTimeout(() => {
    loading.$el.parentNode && loading.$el.parentNode.removeChild(loading.$el);
    loading.$destroy();
    loading = null;
  }, 500);
}

export const directive = {
  name: 'loading',
  inserted (el, { value }) {
    initLoading(el, value);
  },
  update (el, { value }) {
    updateLoading(el, value);
  },
  unbind (el, binding) {
    removeLoading(el);
  }
};
