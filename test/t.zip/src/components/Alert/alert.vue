<template>
  <klk-fade-transition>
    <div class="klk-alert" :class="cClass" :style="cStyle" v-if="!closed">
      <div class="klk-alert-icon" v-if="showIcon">
        <Icon :type="icon ? icon : statusIcon" :size="!!title ? 24 : 20"></Icon>
      </div>
      <div class="klk-alert-main">
        <div class="klk-alert-title" v-if="title || $slots.title">
          <slot name="title">
            <h4>{{ title }}</h4>
          </slot>
        </div>
        <div class="klk-alert-content">
          <slot></slot>
        </div>
      </div>
      <Icon class="klk-alert-close-btn" :size="13" type="icon_navigation_close" v-if="closable" @click="onClose"></Icon>
    </div>
  </klk-fade-transition>
</template>

<script>
  import Vue from 'vue';
  import Icon from '../Icon';
  import { convertHexToRGB } from '../../utils/colorManipulator.js';
  import Helpers from '../Helpers';

  Vue.use(Helpers);

  export default {
    name: 'klk-alert',
    components: {
      Icon,
    },
    props: {
      type: {
        type: String,
        validator (val) {
          return ['success', 'info', 'warning', 'error'].includes(val);
        },
        default: 'success'
      },
      title: String,
      light: Boolean,
      align: {
        type: String,
        validator (val) {
          return ['left', 'center', 'right'].includes(val);
        }
      },
      closable: Boolean,
      icon: String,
      showIcon: Boolean,
    },
    data () {
      return {
        closed: false,
      };
    },
    computed: {
      statusColor () {
        return {
          success: '#24B985',
          info: '#4985e6',
          warning: '#FFA628',
          error: '#e64340',
        }[this.type];
      },
      statusIcon () {
        return {
          success: 'icon_feedback_success',
          info: 'icon_tips_tips',
          warning: 'icon_feedback_warning',
          error: 'icon_feedback_failure',
        }[this.type];
      },
      cClass () {
        return {
          [`klk-alert-closable`]: this.closable,
          [`klk-alert-light`]: this.light,
          [`klk-alert-align-${this.align}`]: !!this.align,
        };
      },
      cStyle () {
        return {
          backgroundColor: convertHexToRGB(this.statusColor, this.light ? 0.12 : 1),
          border: this.light ? `1px ${convertHexToRGB(this.statusColor, 0.2)} solid` : '',
          color: this.light ? this.statusColor : '',
        };
      }
    },
    methods: {
      onClose (e) {
        this.closed = true;
        this.$emit('close', e);
      }
    }
  };
</script>
