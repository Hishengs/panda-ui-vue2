export default {
  name: 'klk-carousel-item',
  inject: [
    'addCarouselItem',
    'removeCarouselItem',
    'isCarouselActive',
    'getCarouselTransition'
  ],
  data () {
    return {
      classes: []
    };
  },
  computed: {
    active () {
      return this.isCarouselActive(this);
    },
    transition () {
      return this.getCarouselTransition();
    }
  },
  created () {
    this.addCarouselItem(this);
  },
  beforeDestroy () {
    this.removeCarouselItem(this);
  },
  render (h) {
    return h('transition', {
      props: {
        name: 'klk-carousel-' + this.transition
      }
    }, [
      h('div', {
        staticClass: 'klk-carousel-item',
        class: [...this.classes],
        directives: [{
          name: 'show',
          value: this.active
        }]
      }, this.$slots.default)
    ]);
  }
};
