import * as colors from '../../theme/colors';
export default (theme, type) => {
  return `
  .klk-table {
    background-color: ${theme.text.alternate};
  }
  .klk-table tr {
    color: ${theme.text.primary};
  }
  .klk-table tr.is-stripe {
    background-color: ${type === 'dark' ? colors.grey800 : colors.grey50};
  }
  .klk-table tr.is-hover {
    background-color: ${type === 'dark' ? 'rgba(0, 0, 0, .14)' : colors.grey200};
  }
  .klk-table tr.is-selected {
    background-color: ${type === 'dark' ? colors.grey700 : colors.grey100};
  }
  .klk-table td {
    border-bottom-color: ${theme.divider};
  }
  .klk-table th {
    color: ${theme.text.secondary};
    border-bottom-color: ${theme.divider};
  }
  .klk-table th.is-sortable:hover {
    color: ${theme.text.primary};
  }
  .klk-table th.is-sorting {
    color: ${theme.text.primary};
  }
  .klk-table-border {
    border-color: ${theme.divider};
  }
  .klk-table-border th,
  .klk-table-border td {
    border-right-color: ${theme.divider};
  }
  .klk-table-empty {
    color: ${theme.text.secondary};
  }
  .klk-table-expand-row td.is-expand {
    border-bottom-color: ${theme.divider};
  }
  `;
};
