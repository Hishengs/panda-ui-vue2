export default {
  methods: {
    createFooter (h) {
      return this.$scopedSlots.footer ? h('div', {
        staticClass: 'klk-table-footer-wrapper',
        ref: 'footer'
      }, [
        h('table', {
          staticClass: 'klk-table-footer',
          style: {
            width: this.tableWidth
          }
        }, [
          this.createColGroup(h),
          h('tbody', {}, this.$scopedSlots.footer({
            columns: this.columns
          }))
        ])
      ]) : undefined;
    }
  }
};
