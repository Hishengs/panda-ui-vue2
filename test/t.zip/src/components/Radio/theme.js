export default (theme) => {
  return `
  .klk-radio.disabled  {
    color: ${theme.text.disabled};
  }
  .klk-radio-checked {
    color: ${theme.primary};
  }
  .klk-radio-label {
    color: ${theme.text.primary};
  }
  .klk-radio.disabled .klk-radio-label {
    color: ${theme.text.disabled};
  }
  `;
};
