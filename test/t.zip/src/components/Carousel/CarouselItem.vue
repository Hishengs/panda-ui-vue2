<template>
  <div :class="cClass" :style="cStyle" @click="onClick">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'klk-carousel-item',
  data () {
    return {
      translateX: 0,
      isVisible: true,
      isPrev: false,
      isCurrent: false,
      isNext: false,
      isAnimating: false,
    }
  },
  computed:{
    cClass () {
      return {
        'klk-carousel-item': true,
        'klk-carousel-item-unvisible': !this.isVisible,
        'klk-carousel-item-prev': this.isPrev,
        'klk-carousel-item-current': this.isCurrent,
        'klk-carousel-item-next': this.isNext,
        'klk-carousel-item-animating': this.isAnimating,
      };
    },
    cStyle () {
      return {
        transform: `translate(${this.translateX}px, 0)`
      };
    }
  },
  mounted () {
    this.$parent && this.$parent.addItem(this);
  },
  beforeDestroy () {
    this.$parent && this.$parent.removeItem(this);
  },
  methods: {
    onClick (e) {
      this.$emit('click', e);
    },
  }
}
</script>

