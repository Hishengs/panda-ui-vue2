export default (theme) => {
  return `
  .klk-checkbox {
    color: ${theme.text.secondary};
  }
  .klk-checkbox.disabled {
    color: ${theme.text.disabled};
  }
  .klk-checkbox-checked {
    color: ${theme.primary};
  }
  .klk-checkbox.disabled .klk-checkbox-label {
    color: ${theme.text.disabled};
  }
  .klk-checkbox-label {
    color: ${theme.text.primary};
  }
  `;
};
