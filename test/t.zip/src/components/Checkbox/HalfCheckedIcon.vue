<template>
  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16">
    <path fill="currentColor" fill-rule="evenodd" d="M14 8c0 .552-.448 1-1 1H3c-.552 0-1-.448-1-1s.448-1 1-1h10c.552 0 1 .448 1 1z"/>
  </svg>
</template>
