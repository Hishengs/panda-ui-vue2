import { fade } from '../../utils/colorManipulator';
export default (theme) => {
  return `
  .klk-tabs{
    background-color: ${theme.primary};
    color: ${fade(theme.text.alternate, 0.7)};
  }

  .klk-tabs-inverse {
    background-color: ${theme.background.default};
    color: ${theme.text.secondary};
  }

  .klk-tab-link-highlight{
    background-color: ${theme.secondary};
  }
  .klk-tab-active {
    color: ${theme.text.alternate};
  }
  .klk-tab-active.is-inverse {
    color: ${theme.text.primary};
  }
  `;
};
