/* import '../../styles/components/picker.scss';
import theme from '../../theme';
import PickerTheme from './theme';
import DatePicker from './DatePicker';
import TimePicker from './TimePicker';
import DateTimePicker from './DateTimePicker';

theme.addCreateTheme(PickerTheme);
export { DatePicker, TimePicker, DateTimePicker };
export default {
  install (Vue) {
    Vue.component(DatePicker.name, DatePicker);
    Vue.component(TimePicker.name, TimePicker);
    Vue.component(DateTimePicker.name, DateTimePicker);
  }
}; */
import DatePicker from '../DatePicker';

export {
  DatePicker,
};
export default {
  install (Vue) {
    console.error('Picker will be decepreated and removed at next version, please replace with Vue.use(DatePicker).');
    Vue.component(DatePicker.name, DatePicker);
  }
};
