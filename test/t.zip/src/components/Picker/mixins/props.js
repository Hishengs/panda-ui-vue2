export default {
  props: {
    landscape: Boolean,
    noDisplay: Boolean,
    displayColor: String
  }
};
