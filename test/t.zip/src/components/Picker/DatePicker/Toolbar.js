import Icon from '../../Icon';

export default {
  inject: [
    'viewSwitchable'
  ],
  props: {
    dateTimeFormat: Object,
    viewDate: Date,
    type: {
      type: String,
      default: 'month',
      validator (type) {
        return ['month', 'year', 'year-range'].includes(type);
      },
    }, // month, year
    nextMonth: {
      type: Boolean,
      default: true
    },
    prevMonth: {
      type: Boolean,
      default: true
    },
    slideType: String
  },
  methods: {
    onSwitch (type) {
      if (this.viewSwitchable) {
        this.$emit('click', type);
      }
    },
    createTitleSlide (h) {
      let title = '';
      let year = '', month = '', date = '', yearRange = '';
      if (this.type === 'month') {
        // const format = this.dateTimeFormat.formatMonth(this.viewDate).split(' ');
        // year = format[0];
        // month = format[1];
        month = this.dateTimeFormat.formatMonth(this.viewDate);
        // title = this.dateTimeFormat.formatMonth(this.viewDate);
      } else if (this.type === 'year') {
        year = this.viewDate.getFullYear();
        // title = this.viewDate.getFullYear();
      } else if (this.type === 'year-range') {
        const startYear = this.viewDate.getFullYear() - 1;
        const endYear = startYear + 11;
        yearRange = `${startYear}-${endYear}`;
        // title = `${startYear}-${endYear}`;
      }
      return h('transition', {
        props: {
          name: `klk-datepicker-slide-${this.slideType}`
        },
      }, [
        h('div', {
          staticClass: 'klk-datepicker-toolbar-title',
          class: {
            clickable: this.viewSwitchable
          },
          key: title,
          // on: {
          //   click: (e) => this.$emit('click', e)
          // }
        }, /* title */[
          year ? h('span', {
            staticClass: 'klk-datepicker-toolbar-title__year',
            on: {
              click: (e) => this.onSwitch('year')
            }
          }, year) : null,
          month ? h('span', {
            staticClass: 'klk-datepicker-toolbar-title__month',
            on: {
              click: (e) => this.onSwitch('month')
            }
          }, month) : null,
          yearRange ? h('span', {
            staticClass: 'klk-datepicker-toolbar-title__year-range',
            // on: {
            //   click: (e) => this.onSwitch('year-range')
            // }
          }, yearRange) : null,
        ])
      ]);
    },
    createPrevIcon (h) {
      return h('svg', {
        staticClass: 'klk-datepicker-svg-icon',
        attrs: {
          viewBox: '0 0 24 24'
        }
      }, [
        h('path', {
          attrs: {
            d: 'M15.41 7.41L14 6l-6 6 6 6 1.41-1.41L10.83 12z'
          }
        })
      ]);
    },
    createNextIcon (h) {
      return h('svg', {
        staticClass: 'klk-datepicker-svg-icon',
        attrs: {
          viewBox: '0 0 24 24'
        }
      }, [
        h('path', {
          attrs: {
            d: 'M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z'
          }
        })
      ]);
    }
  },
  render (h) {
    const prevDisabled = !this.prevMonth;
    const nextDisabled = !this.nextMonth;
    return h('div', {
      staticClass: 'klk-datepicker-toolbar'
    }, [
      h('div', {
        staticClass: 'klk-datepicker-tool-btn',
        class: {
          [`klk-datepicker-tool-btn-disabled`]: prevDisabled,
        },
        on: {
          click: () => {
            if (prevDisabled) return;
            this.$emit('change', -1);
          }
        }
      }, [
        // this.createPrevIcon(h)
        h(Icon, {
          props: {
            type: 'icon_navigation_chevron_left_xs',
            size: 16,
          }
        })
      ]),
      h('div', {
        staticClass: 'klk-datepicker-toolbar-title-wrapper',
        // on: {
        //   click: () => this.$emit('changeView', 'month')
        // }
      }, [this.createTitleSlide(h)]),
      h('div', {
        staticClass: 'klk-datepicker-tool-btn',
        class: {
          [`klk-datepicker-tool-btn-disabled`]: nextDisabled,
        },
        on: {
          click: () => {
            if (nextDisabled) return;
            this.$emit('change', 1);
          }
        }
      }, [
        // this.createNextIcon(h)
        h(Icon, {
          props: {
            type: 'icon_navigation_chevron_right_xs',
            size: 16,
          }
        })
      ])
    ]);
  }
};
