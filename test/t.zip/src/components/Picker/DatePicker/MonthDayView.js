import DayButton from './DayButton';
import Toolbar from './Toolbar';
import * as dateUtils from './dateUtils';

export default {
  inject: [
    'range'
  ],
  props: {
    dateTimeFormat: Object,
    firstDayOfWeek: {
      type: Number,
      default: 1
    },
    maxDate: Date,
    minDate: Date,
    displayDates: Array,
    selectedDates: Array,
    shouldDisableDate: Function,
  },
  data () {
    // 当前视图的基准日期
    const viewDate = this.displayDates.length
      ? dateUtils.cloneDate(this.displayDates[0])
      : new Date();
    viewDate.setDate(1);
    return {
      weekTexts: this.dateTimeFormat.getWeekDayArray(this.firstDayOfWeek),
      viewDate,
      slideType: 'next',
      contentHeight: '100%',
    };
  },
  computed: {
    prevMonth () {
      return this.viewDate && dateUtils.monthDiff(this.viewDate, this.minDate) > 0;
    },
    nextMonth () {
      return this.viewDate && dateUtils.monthDiff(this.viewDate, this.maxDate) < 0;
    }
  },
  methods: {
    equalsDate (date) {
      return this.selectedDates.some(selectedDate => dateUtils.isEqualDate(date, selectedDate));
    },
    inRange (date) {
      if (this.range) {
        const [startDate, endDate] = this.selectedDates;
        return date && endDate && dateUtils.isBetweenDates(date, startDate, endDate)
      } else return false;
    },
    isStartDate (date) {
      return dateUtils.isEqualDate(date, this.selectedDates[0]);
    },
    isEndDate (date) {
      return dateUtils.isEqualDate(date, this.selectedDates[this.selectedDates.length-1]);
    },
    isDisableDate (day) {
      if (day === null) return false;
      let disabled = false;
      if (this.maxDate && this.minDate) disabled = !dateUtils.isBetweenDates(day, this.minDate, this.maxDate);
      if (!disabled && this.shouldDisableDate) disabled = this.shouldDisableDate(day);
      return disabled;
    },
    handleClick (date) {
      if (date) this.$emit('select', date);
    },
    handleChange (val) {
      const newViewDate = dateUtils.addMonths(this.viewDate, val);
      this.changeViewDate(newViewDate);
    },
    changeViewDate (date) {
      const oldDate = this.viewDate;
      if (date.getFullYear() === oldDate.getFullYear() && date.getMonth() === oldDate.getMonth()) return;
      this.slideType = date.getTime() > oldDate.getTime() ? 'next' : 'prev';
      const newViewDate = dateUtils.cloneDate(date);
      newViewDate.setDate(1);
      this.viewDate = newViewDate;
    },
    createWeek (h) {
      return h('div', {
        staticClass: 'klk-datepicker-week'
      }, this.weekTexts.map((weekText, index) => {
        return h('span', {
          staticClass: 'klk-datepicker-week-day',
          key: index
        }, weekText);
      }));
    },
    createMonthDay (h) {
      return h('div', {
        staticClass: 'klk-datepicker-monthday',
        style: {
          height: this.contentHeight,
        },
      }, [
        h('transition', {
          props: {
            // name: `klk-datepicker-slide-${this.slideType}`
            name: 'klk-datepicker-slide',
          },
        }, [
          h('div', {
            staticClass: 'klk-datepicker-monthday-slide',
            key: this.viewDate.getTime()
          }, [this.createContent(h, this.viewDate)])
        ])
      ]);
    },
    createContent (h, displayDate) {
      const weeksArray = dateUtils.getWeekArray(displayDate || new Date(), this.firstDayOfWeek);
      this.$nextTick(() => {
        if (this.$refs.content && window.getComputedStyle) {
          this.contentHeight = window.getComputedStyle(this.$refs.content)['height'] || '100%';
        }
      });
      return h('div', {
        staticClass: 'klk-datepicker-monthday-content',
        ref: 'content',
      }, weeksArray.map((week, i) => {
        return h('div', {
          staticClass: 'klk-datepicker-monthday-row',
          key: i
        }, week.map((date, j) => {
          const disabled = this.isDisableDate(date);
          const selected = this.equalsDate(date);
          const inRange = this.inRange(date);
          const isStart = this.isStartDate(date);
          const isEnd = this.isEndDate(date);
          return h(DayButton, {
            props: {
              disabled,
              selected,
              inRange,
              isStart,
              isEnd,
              date,
            },
            on: {
              click: () => this.handleClick(date)
            },
            key: `dayButton${i}${j}`
          });
        }));
      }));
    }
  },
  render (h) {
    return h('div', {
      staticClass: 'klk-datepicker-monthday-container'
    }, [
      h(Toolbar, {
        props: {
          slideType: this.slideType,
          nextMonth: this.nextMonth,
          prevMonth: this.prevMonth,
          viewDate: this.viewDate,
          dateTimeFormat: this.dateTimeFormat
        },
        on: {
          // click: () => this.$emit('changeView', 'month'),
          click: (type) => this.$emit('changeView', type),
          change: this.handleChange,
        }
      }),
      this.createWeek(h),
      this.createMonthDay(h)
    ]);
  },
  watch: {
    displayDates (val) {
      if (val && val.length) {
        this.changeViewDate(val[val.length-1]);
      }
    }
  }
};
