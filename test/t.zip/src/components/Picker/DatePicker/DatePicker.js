import color from '../../../mixins/color';
import pickerProps from '../mixins/props';
import DateDisplay from './DateDisplay';
import MonthDayView from './MonthDayView';
import YearView from './YearView';
import MonthView from './MonthView';
import * as dateUtils from './dateUtils';

export default {
  name: 'klk-date-picker',
  mixins: [color, pickerProps],
  provide () {
    return {
      getDayButtonSlots: this.getDayButtonSlots,
      getMonthButtonSlots: this.getMonthButtonSlots,
      getYearButtonSlots: this.getYearButtonSlots,
      range: this.range,
      viewSwitchable: this.viewSwitchable,
      hightlightToday: this.hightlightToday,
    };
  },
  props: {
    range: Boolean,
    // dateTimeFormat: {
    //   type: Object,
    //   default () {
    //     return dateUtils.dateTimeFormat;
    //   }
    // },
    firstDayOfWeek: {
      type: Number,
      default: 0,
      validator (val) {
        return [0, 1, 2, 3, 4, 5, 6].includes(val);
      }
    },
    type: {
      type: String,
      default: 'date', // date, year, month
      validator (type) {
        return ['date', 'year', 'month'].includes(type);
      },
    },
    date: {
      type: [Date, Array],
      /* default () {
        const current = new Date();
        if (this.range) {
          let next;
          if (this.type === 'date') {
            next = dateUtils.addDays(current, 1);
          } else if (this.type === 'month') {
            next = dateUtils.addMonths(current, 1);
          } else if (this.type === 'year') {
            next = dateUtils.addYears(current, 1);
          }
          return [current, next];
        } else return current;
      }, */
      validator (date) {
        if (Array.isArray(date)) {
          return date.every(d => d instanceof Date);
        } else return date instanceof Date;
      }
    },
    maxDate: {
      type: Date,
      default () {
        return dateUtils.addYears(new Date(), 100);
      }
    },
    minDate: {
      type: Date,
      default () {
        return dateUtils.addYears(new Date(), -100);
      }
    },
    shouldDisableDate: Function,
    // 视图是否可切换
    viewSwitchable: Boolean,
    // 是否高亮今天
    hightlightToday: Boolean,
  },
  data () {
    return {
      dateTimeFormat: dateUtils.dateTimeFormat,
      displayDates: this.date ? (this.range ? this.date : [this.date]) : [],
      view: this.type === 'date' ? 'monthDay' : this.type === 'year' ? 'year' : 'month'
    };
  },
  computed: {
    showDisplay () {
      // return !this.noDisplay && !this.range && this.displayDates.length;
      return !this.noDisplay && !this.range;
    }
  },
  methods: {
    getDayButtonSlots () {
      return this.$scopedSlots.day;
    },
    getMonthButtonSlots () {
      return this.$scopedSlots.month;
    },
    getYearButtonSlots () {
      return this.$scopedSlots.year;
    },
    handleYearChange (year) {
      const date = this.displayDates.length ? dateUtils.cloneAsDate(this.displayDates[0]) : new Date();
      date.setDate(1);
      date.setFullYear(year);
      this.changeDisplayDate(date);
      if (this.type === 'year') return this.changeDate(date);
      this.changeView(this.type === 'month' ? 'month' : 'monthDay');
    },
    handleMonthChange (date) {
      this.changeDisplayDate(date);
      if (this.type === 'month') return this.changeDate(date);
      this.changeView('monthDay');
    },
    handleSelect (date) {
      if (date.getTime() > this.maxDate.getTime()) date = new Date(this.maxDate.getTime());
      if (date.getTime() < this.minDate.getTime()) date = new Date(this.minDate.getTime());
      this.changeDisplayDate(date);
      this.changeDate(date);
    },
    changeDate (date) {
      if (this.range) {
        const oldDate = this.date || [];
        let dates, len = oldDate.length;
        if (len === 0) {
          dates = [date];
        } else if (len === 1) {
          dates = [...oldDate, date];
        } else if (len === 2) {
          dates = [date];
        }
        if (dates) {
          dates.sort((d1, d2) => d1 - d2);
          this.$emit('change', dates);
          this.$emit('update:date', dates);
        }
      } else {
        this.$emit('change', date);
        this.$emit('update:date', date);
      }
      /* this.$nextTick(() => {
        console.log('>>> DatePicker.changeDate', this.date);
      }); */
    },
    changeDisplayDate (date) {
      this.displayDates = [date];
    },
    changeView (view) {
      if (!this.viewSwitchable) return;
      this.view = view;
    }
  },
  render (h) {
    const colorClass = this.getNormalColorClass(this.color, true);
    const color = this.getColor(this.color);
    let view;
    const selectedDates = this.date
      ? this.range
        ? this.date ? this.date : []
        : this.date ? [this.date] : []
      : [];
    if (this.view === 'monthDay') {
      view = h(MonthDayView, {
        props: {
          dateTimeFormat: this.dateTimeFormat,
          firstDayOfWeek: this.firstDayOfWeek,
          maxDate: this.maxDate,
          minDate: this.minDate,
          displayDates: this.displayDates,
          selectedDates,
          shouldDisableDate: this.shouldDisableDate,
        },
        on: {
          changeView: this.changeView,
          select: this.handleSelect
        }
      });
    } else if (this.view === 'month') {
      view = h(MonthView, {
        props: {
          dateTimeFormat: this.dateTimeFormat,
          maxDate: this.maxDate,
          minDate: this.minDate,
          displayDates: this.displayDates,
          selectedDates,
        },
        on: {
          changeView: this.changeView,
          change: this.handleMonthChange
        }
      });
    } else {
      view = h(YearView, {
        props: {
          dateTimeFormat: this.dateTimeFormat,
          displayDates: this.displayDates,
          maxDate: this.maxDate,
          minDate: this.minDate,
          selectedDates,
        },
        on: {
          change: this.handleYearChange
        }
      });
    }
    return h(
      'div',
      {
        staticClass: `klk-picker klk-datepicker ${colorClass}`,
        class: {
          'klk-picker-landspace': this.landscape
        },
        style: {
          color
        }
      },
      [
        /* this.showDisplay ? h(DateDisplay, {
          props: {
            type: this.type,
            monthDaySelected: this.view !== 'year',
            color: this.displayColor,
            displayDates: this.displayDates,
            dateTimeFormat: this.dateTimeFormat
          },
          on: {
            changeView: this.changeView
          }
        }) : undefined, */
        h(
          'div',
          {
            staticClass: 'klk-picker-container'
          },
          [
            view,
            this.$slots.default
          ]
        )
      ]
    );
  },
  watch: {
    date (val) {
      if (val) {
        this.displayDates = Array.isArray(val) ? val : [val];
      }
    }
  }
};
