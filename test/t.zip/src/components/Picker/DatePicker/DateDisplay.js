import color from '../../../mixins/color';

export default {
  mixins: [color],
  props: {
    type: String,
    dateTimeFormat: Object,
    monthDaySelected: {
      type: Boolean,
      default: true
    },
    displayDates: Array
  },
  data () {
    const viewDate = this.displayDates.length ? this.displayDates[0] : new Date();
    return {
      viewDate,
      slideType: 'next'
    };
  },
  methods: {
    replaceSelected (date) {
      const oldDate = this.viewDate;
      this.slideType = date.getTime() > oldDate.getTime() ? 'next' : 'prev';
      this.viewDate = date;
    },
    createYearSlide (h) {
      const fullYear = this.viewDate.getFullYear();
      return h('transition', {
        props: {
          name: `klk-date-display-${this.slideType}`
        },
      }, [
        h('div', {
          staticClass: 'klk-date-display-slideIn-wrapper',
          key: fullYear
        }, [
          h('div', { staticClass: 'klk-date-display-year-title' }, fullYear)
        ])
      ]);
    },
    createMonthSlide (h) {
      const displayMonthDay = this.type === 'date'
        ? this.dateTimeFormat.formatDisplay(this.viewDate)
        : this.dateTimeFormat.getMonthList()[this.viewDate.getMonth()];
      return h('transition', {
        props: {
          name: `klk-date-display-${this.slideType}`
        },
      }, [
        h('div', {
          staticClass: 'klk-date-display-slideIn-wrapper',
          key: displayMonthDay
        }, [
          h('div', { staticClass: 'klk-date-display-monthday-title' }, displayMonthDay)
        ])
      ]);
    }
  },
  render (h) {
    const displayYear = h('div', {
      staticClass: 'klk-date-display-year',
      on: {
        click: () => this.$emit('changeView', 'year')
      }
    }, [this.createYearSlide(h)]);
    const displayMonthDay = this.type !== 'year' ? h('div', {
      staticClass: 'klk-date-display-monthday',
      on: {
        click: () => this.$emit('changeView', this.type === 'date' ? 'monthDay' : 'month')
      }
    }, [this.createMonthSlide(h)]) : undefined;

    return h('div', {
      staticClass: 'klk-picker-display klk-date-display ' + this.getColorClass(false),
      style: {
        'background-color': this.getColor(this.color)
      },
      class: {
        'selected-year': !this.monthDaySelected
      }
    }, [displayYear, displayMonthDay]);
  },
  watch: {
    displayDates (val) {
      if (val && val.length) {
        this.replaceSelected(val[0]);
      }
    }
  }
};
