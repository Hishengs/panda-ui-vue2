import Toolbar from './Toolbar';
import * as dateUtils from './dateUtils';
import YearButton from './YearButton';

const YEAR_RANGE = 12;

export default {
  inject: [
    'range'
  ],
  props: {
    dateTimeFormat: Object,
    maxDate: Date,
    minDate: Date,
    displayDates: Array,
    selectedDates: Array,
  },
  data () {
    const viewDate = this.displayDates.length
      ? dateUtils.cloneDate(this.displayDates[0])
      : new Date();
    viewDate.setDate(1);
    return {
      viewDate,
      slideType: 'next'
    };
  },
  computed: {
    years () {
      const minYear = this.viewDate.getFullYear() - 1;
      const maxYear = this.viewDate.getFullYear() + 10;
      const years = [];
      for (let year = minYear; year <= maxYear; year++) {
        years.push(year);
      }
      return years;
    }
  },
  methods: {
    isSelected (year) {
      return this.selectedDates.some(d => {
        return year === d.getFullYear();
      });
    },
    inRange (year) {
      if (this.range) {
        const [startDate, endDate] = this.displayDates;
        return year && endDate && (year >= startDate.getFullYear() && year <= endDate.getFullYear());
      } else return false;
    },
    changeViewDate (date) {
      const oldDate = this.viewDate;
      if (date.getFullYear() === oldDate.getFullYear() && date.getMonth() === oldDate.getMonth()) return;
      this.slideType = date.getTime() > oldDate.getTime() ? 'next' : 'prev';
      const newViewDate = dateUtils.cloneDate(date);
      newViewDate.setDate(1);
      this.viewDate = newViewDate;
    },
    handleChange (val) {
      const newViewDate = dateUtils.cloneDate(this.viewDate);
      const newFullYear = newViewDate.getFullYear() + val * YEAR_RANGE;
      if (newFullYear < (this.minDate.getFullYear() - YEAR_RANGE) || newFullYear > this.maxDate.getFullYear()) return;
      newViewDate.setFullYear(newFullYear);
      this.changeViewDate(newViewDate);
    },
    scrollToSelectedYear (yearButtonNode) {
      const container = this.$refs.container;
      const containerHeight = container.clientHeight;
      const yearButtonNodeHeight = yearButtonNode.clientHeight || 32;
      const scrollYOffset = (yearButtonNode.offsetTop + yearButtonNodeHeight / 2) - containerHeight / 2;
      setTimeout(() => (container.scrollTop = scrollYOffset), 0);
    },
    createYearButtons (h) {
      const yearRows = [];
      const years = this.years.slice(0);
      while (years.length > 0) {
        yearRows.push(years.splice(0, 3));
      }
      return yearRows.map((yearRow, i) => {
        return h('div', {
          staticClass: 'klk-datepicker-year-row',
          key: i,
        }, yearRow.map(year => {
          const disabled = year < this.minDate.getFullYear() || year > this.maxDate.getFullYear();
          return h(YearButton, {
            props: {
              year,
              selected: this.isSelected(year),
              inRange: this.inRange(year),
              disabled,
            },
            on: {
              click: (e) => {
                if (disabled) return;
                this.$emit('change', year);
              }
            }
          });
        }));
      });
    }
  },
  render (h) {
    const firstYear = this.years[0];
    // const prevMonth = firstYear >= (this.minDate.getFullYear() - YEAR_RANGE);
    // const nextMonth = firstYear <= this.maxDate.getFullYear();
    const prevMonth = firstYear > this.minDate.getFullYear();
    const nextMonth = (firstYear + YEAR_RANGE) < this.maxDate.getFullYear();
    return h('div', {
      staticClass: 'klk-datepicker-year-container'
    }, [
      h(Toolbar, {
        props: {
          slideType: this.slideType,
          type: 'year-range',
          viewDate: this.viewDate,
          dateTimeFormat: this.dateTimeFormat,
          prevMonth,
          nextMonth,
        },
        on: {
          // click: () => this.$emit('changeView', 'year'),
          change: this.handleChange
        }
      }),
      h('div', {
        staticClass: 'klk-datepicker-year',
        ref: 'container'
      }, [
        /* h('div', {
          staticClass: 'klk-datepicker-year-list'
        }, this.createYearButtons(h)) */
        this.createYearButtons(h)
      ])
    ]);
  }
};
