import Toolbar from './Toolbar';
import * as dateUtils from './dateUtils';

export default {
  inject: [
    'range'
  ],
  props: {
    dateTimeFormat: Object,
    maxDate: Date,
    minDate: Date,
    displayDates: Array,
    selectedDates: Array,
  },
  data () {
    const viewDate = this.displayDates.length
      ? dateUtils.cloneDate(this.displayDates[0])
      : new Date();
    viewDate.setDate(1);
    return {
      viewDate,
      slideType: 'next'
    };
  },
  methods: {
    isSelected (date) {
      return this.selectedDates.some(d => {
        return date.getFullYear() === d.getFullYear() &&
          date.getMonth() === d.getMonth();
      });
    },
    inRange (date) {
      if (this.range && date) {
        let [startDate, endDate] = this.displayDates;
        if (startDate && endDate) {
          startDate = dateUtils.cloneDate(startDate);
          startDate.setDate(1);
          endDate = dateUtils.cloneDate(endDate);
          endDate.setDate(1);
          return dateUtils.isBetweenDates(date, startDate, endDate);
        } else return false;
      } else return false;
    },  
    changeViewDate (date) {
      const oldDate = this.viewDate;
      if (date.getFullYear() === oldDate.getFullYear() && date.getMonth() === oldDate.getMonth()) return;
      this.slideType = date.getTime() > oldDate.getTime() ? 'next' : 'prev';
      const newViewDate = dateUtils.cloneDate(date);
      newViewDate.setDate(1);
      this.viewDate = newViewDate;
    },
    handleChange (val) {
      const newViewDate = dateUtils.cloneDate(this.viewDate);
      newViewDate.setFullYear(newViewDate.getFullYear() + val);
      this.changeViewDate(newViewDate);
    },
    createMonth (h) {
      return h('div', {
        staticClass: 'klk-datepicker-month'
      }, [
        h('transition', {
          props: {
            name: `klk-datepicker-slide-${this.slideType}`
          },
        }, [
          h('div', {
            staticClass: 'klk-datepicker-month-slide',
            key: this.viewDate.getTime()
          }, [this.createContent(h, this.viewDate)])
        ])
      ]);
    },
    createContent (h, displayDate) {
      const monthArray = dateUtils.getMonthArray(displayDate);
      return h('div', {
        staticClass: 'klk-datepicker-month-content'
      }, monthArray.map((month, i) => {
        return h('div', {
          staticClass: 'klk-datepicker-month-row',
          key: i
        }, month.map((date) => this.createMonthButton(h, date)));
      }));
    },
    createMonthButton (h, date) {
      const monthText = this.dateTimeFormat.getMonthList()[date.getMonth()];
      const maxDate = new Date(this.maxDate.getFullYear(), this.maxDate.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
      const minDate = new Date(this.minDate.getFullYear(), this.minDate.getMonth(), date.getDate(), date.getHours(), date.getMinutes(), date.getSeconds());
      const disabled = date.getTime() > maxDate.getTime() || date.getTime() < minDate.getTime();
      return h(
        'button',
        {
          staticClass: 'klk-month-button',
          attrs: {
            disabled
          },
          class: {
            selected: this.isSelected(date),
            'in-range': this.inRange(date),
          },
          on: {
            click: () => !disabled && this.$emit('change', date)
          }
        },
        [
          h('div', { staticClass: 'klk-month-button-bg' }),
          h('span', { staticClass: 'klk-month-button-text' }, monthText)
        ]
      );
    }
  },
  render (h) {
    return h(
      'div',
      {
        staticClass: 'klk-datepicker-month-container'
      },
      [
        h(Toolbar, {
          props: {
            slideType: this.slideType,
            type: 'year',
            viewDate: this.viewDate,
            dateTimeFormat: this.dateTimeFormat
          },
          on: {
            // click: () => this.$emit('changeView', 'year'),
            click: (type) => this.$emit('changeView', type),
            change: this.handleChange
          }
        }),
        this.createMonth(h)
      ]
    );
  }
};
