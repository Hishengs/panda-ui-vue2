import { fade } from '../../utils/colorManipulator';
export default (theme, type) => {
  return `
  .klk-picker {
    color: ${theme.primary};
    background-color: ${theme.background.paper};
  }
  .klk-picker-display {
    background-color: ${type === 'dark' ? '#555555' : 'currentColor'};
  }
  .klk-datepicker-week,
  .klk-datepicker-toolbar-title,
  .klk-datepicker-tool-btn,
  .klk-datepicker-svg-icon,
  .klk-day-button-text,
  .klk-month-button-text,
  .klk-year-button-text,
  .klk-timepicker-number {
    color: ${theme.text.primary};
  }

  .klk-day-button:hover:not(:disabled) .klk-day-button-text,
  .klk-day-button.selected .klk-day-button-text{
    color: ${theme.text.alternate};
  }

  .klk-month-button:hover .klk-month-button-text,
  .klk-month-button.selected .klk-month-button-text {
    color: ${theme.text.alternate};
  }
  .klk-month-button:disabled .klk-month-button-text {
    color: ${theme.text.disabled};
  }

  .klk-timepicker-number__selected {
    background-color: ${theme.primary};
    color: ${theme.text.alternate};
  }

  .klk-timepicker-pointer-mark {
     background-color: ${theme.text.alternate};
  }
  .klk-timepicker-list-hours {
    border-right-color: ${theme.divider};
  }
  .klk-timepicker-hour-button,
  .klk-timepicker-minute-button {
    color: ${theme.text.primary};
  }
  .klk-timepicker-hour-button:hover,
  .klk-timepicker-minute-button:hover,
  .klk-year-button:hover {
    background-color: ${fade(theme.text.primary, 0.1)};
  }
  .klk-datetime-picker .klk-tabs {
    background-color: ${type === 'dark' ? '#555555' : ''};
    color: ${type === 'dark' ? theme.text.secondary : ''}
  }
  .klk-datetime-picker .klk-tab-active {
    color: ${type === 'dark' ? theme.text.primary : ''}
  }
  `;
};
