import { fade, darken } from '../../utils/colorManipulator';

export default (theme) => {
  return `
  .klk-raised-button {
    background-color: ${theme.background.paper};
    color: ${theme.text.primary};
  }
  .klk-raised-button.disabled{
    color: ${fade(theme.text.primary, 0.3)};
    background-color: ${darken(theme.text.alternate, 0.1)};
  }
  .klk-flat-button {
    color: ${theme.text.primary};
  }
  .klk-flat-button.disabled {
    color: ${theme.text.disabled};
  }
  .klk-icon-button {
    color: ${theme.text.primary};
  }
  .klk-icon-button.disabled {
    color: ${theme.text.disabled};
  }
  .klk-fab-button {
    background-color: ${theme.primary};
    color: ${theme.text.alternate};
  }
  .klk-fab-button.disabled {
    color: ${fade(theme.text.primary, 0.3)};
    background-color: ${darken(theme.text.alternate, 0.1)};
  }
  `;
};
