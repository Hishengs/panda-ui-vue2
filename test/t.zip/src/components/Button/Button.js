import route from '../../mixins/route';
import Icon from '../Icon';

export default {
  name: 'klk-button',
  mixins: [route],
  props: {
    type: {
      type: String,
      default: 'primary',
      validator(val) {
        return ['primary', 'secondary', 'ghost', 'outlined'].includes(val);
      }
    },
    htmlType: {
      type: String,
      default: 'button'
    },
    size: {
      type: String,
      default: 'normal',
      validator(val) {
        return ['mini', 'small', 'normal', 'large'].includes(val);
      }
    },
    disabled: Boolean,
    round: Boolean,
    block: Boolean,
    icon: String,
    loading: Boolean,
  },
  data() {
    return {
      isIcon: false,
      iconOnly: false,
    }
  },
  computed: {
    buttonClass() {
      return {
        [`klk-button-${this.type}`]: true,
        [`klk-button-${this.size}`]: true,
        'klk-button-disabled': this.disabled,
        'klk-button-round': this.round,
        'klk-button-block': this.block,
        'klk-button-icon': this.isIcon,
        'klk-button-loading': this.loading
      };
    },
    iconSize() {
      return {
        normal: 24,
        large: 24,
        small: 16,
        mini: 14,
      }[this.size];
    },
  },
  mounted() {
    this.isIcon = !!this.icon || !!this.loading;
    this.iconOnly = !!this.isIcon && !this.$slots.default;
  },
  methods: {
    onClick() {
      if (this.disabled || this.loading) return;
      this.$emit('click');
    }
  },
  render(h) {
    return h('button', {
      staticClass: 'klk-button',
      class: this.buttonClass,
      props: {
        disabled: this.disabled,
        type: this.htmlType,
      },
      on: {
        click: this.onClick
      }
    }, [
      this.loading ? h(Icon, {
        staticClass: 'klk-button-loading-icon',
        class: {
          'icon-only': this.iconOnly
        },
        props: {
          type: 'icon_other_loading',
          size: this.iconSize
        }
      }) : null,
      this.icon ? h(Icon, {
        class: {
          'icon-only': this.iconOnly
        },
        props: {
          type: this.icon,
          size: this.iconSize
        },
      }) : null,
      this.$slots.default,
    ]);
  },
};
