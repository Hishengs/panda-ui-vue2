export default (theme) => {
  return `
  .klk-common-input {
    color: ${theme.text.secondary};
  }
  .klk-common-input__focus {
    color: ${theme.primary};
  }
  .klk-common-input__error {
    color: ${theme.error};
  }
  .klk-common-input.disabled .klk-common-input-content {
    color: ${theme.text.disabled};
  }
  .klk-common-input-help {
    color: ${theme.text.secondary};
  }
  .klk-common-input__error .klk-common-input-help {
    color: ${theme.error};
  }
  .klk-common-input.has-label .klk-common-input-label.float {
    color: ${theme.text.disabled};
  }
  .klk-common-input-line {
    background-color: ${theme.divider};
  }
  .klk-common-input-line.disabled{
    border-bottom-color: ${theme.text.disabled};
  }
  .klk-common-input-suffix-text,
  .klk-common-input-prefix-text {
    color: ${theme.text.secondary};
  }
  .klk-text-field-input {
    color: ${theme.text.primary};
  }
  .klk-text-field-suffix {
    color: ${theme.text.secondary};
  }
  `;
};
