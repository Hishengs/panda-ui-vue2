import '../../styles/components/input.scss';
import theme from '../../theme';
import InputTheme from './theme';
import Input from './Input';

Input.install = function (Vue) {
  Vue.component(Input.name, Input);
};

theme.addCreateTheme(InputTheme);
export default Input;
