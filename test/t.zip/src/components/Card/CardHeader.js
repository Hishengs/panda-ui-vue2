export default {
  name: 'klk-card-header',
  functional: true,
  props: {
    title: String,
    subTitle: String
  },
  render (h, { data, props, slots }) {
    slots = slots();
    const title = props.title || props.subTitle ? h('div', {
      staticClass: 'klk-card-header-title'
    }, [
      h('div', { staticClass: 'klk-card-title' }, props.title),
      h('div', { staticClass: 'klk-card-sub-title' }, props.subTitle)
    ]) : undefined;

    data.staticClass = `${data.staticClass || ''} klk-card-header`;
    return h('div', data, [slots.avatar, title, slots.default]);
  }
};
