export default {
  name: 'klk-card',
  props: {
    raised: Boolean
  },
  render (h) {
    return h('div', {
      staticClass: 'klk-card',
      class: {
        'klk-card__raised': this.raised
      },
      on: this.$listeners
    }, this.$slots.default);
  }
};
