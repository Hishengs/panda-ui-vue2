export default {
  name: 'klk-card-title',
  functional: true,
  props: {
    title: String,
    subTitle: String
  },
  render (h, { data, props }) {
    data.staticClass = `${data.staticClass || ''} klk-card-title-container`;
    return h('div', data, [
      h('div', { staticClass: 'klk-card-title' }, props.title),
      h('div', { staticClass: 'klk-card-sub-title' }, props.subTitle)
    ]);
  }
};
