import { fade } from '../../utils/colorManipulator';

export default (theme) => {
  return `
    .klk-card {
      background-color: ${theme.background.paper};
    }
    .klk-card-header-title .klk-card-title{
      color: ${fade(theme.text.primary, 0.87)};
    }
    .klk-card-header-title .klk-card-sub-title{
      color: ${fade(theme.text.primary, 0.57)};
    }
    .klk-card-text{
      color: ${theme.text.primary};
    }
    .klk-card-title-container .klk-card-title{
      color: ${theme.text.primary};
    }
    .klk-card-title-container .klk-card-sub-title {
      color: ${theme.text.secondary};
    }
  `;
};
