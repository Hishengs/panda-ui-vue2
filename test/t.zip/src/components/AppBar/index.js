import '../../styles/components/elevation.scss';
import '../../styles/components/appbar.scss';
import theme from '../../theme';
import AppBarTheme from './theme';
import AppBar from './AppBar';

AppBar.install = function (Vue) {
  Vue.component(AppBar.name, AppBar);
};

theme.addCreateTheme(AppBarTheme);
export default AppBar;
