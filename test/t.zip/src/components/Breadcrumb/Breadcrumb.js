import defaultDivider from './Divider.vue';

export default {
  name: 'klk-breadcrumb',
  props: {
    divider: String,
    overflowBehavior: {
      type: String,
      default: 'scroll',
      validator (val) {
        return ['scroll', 'ellipsis'].includes(val);
      },
    },
    color: {
      type: String,
      default: '#333333',
    },
  },
  data () {
    return {
      isOverflow: false,
    };
  },
  computed: {
    innerStyle () {
      if (this.overflowBehavior !== 'scroll') {
        return {
          overflow: 'hidden',
        };
      }
    },
    showEllipsis () {
      return this.overflowBehavior === 'ellipsis' && this.isOverflow;
    },
  },
  methods: {
    createChildren (h) {
      if (!this.$slots.default) return;
      const divider = this.$slots.divider
        ? this.$slots.divider
        : this.divider
          ? h('span', this.divider)
          : h(defaultDivider);
      const children = [];
      const length = this.$slots.default.length;
      const dividerData = {
        staticClass: 'klk-breadcrumb-divider',
        style: {
          color: this.color
        }
      };

      this.$slots.default.forEach((el, i) => {
        const isCurrent = i === length - 1;
        this.$nextTick(() => {
          if (el.componentInstance) {
            el.componentInstance.isCurrent = isCurrent;
          }
        });
        children.push(el);
        if (!el.componentOptions || el.componentOptions.tag !== 'klk-breadcrumb-item' || isCurrent) return;

        children.push(this.$createElement('span', dividerData, [divider]));
      });
      return children;
    }
  },
  render (h) {
    return h('div', {
      staticClass: 'klk-breadcrumb',
      class: {
        [`klk-breadcrumb-${this.overflowBehavior}`]: this.showEllipsis,
      },
      on: this.$listeners,
    }, [
      h('div', {
        staticClass: 'klk-breadcrumb-inner',
        style: this.innerStyle,
        ref: 'inner'
      }, this.createChildren(h)),
    ]);
  },
  mounted () {
    const el = this.$refs.inner;
    if (el) {
      this.isOverflow = el.clientWidth < el.scrollWidth;
    }
  },
};
