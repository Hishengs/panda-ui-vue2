export default (theme) => {
  return `
  .klk-breadcrumb-item {
    color: ${theme.primary};
  }
  .klk-breadcrumb-item.is-disabled {
    color: ${theme.text.disabled};
  }
  .klk-breadcrumb-divider {
    color: ${theme.text.disabled};
  }
  `;
};
