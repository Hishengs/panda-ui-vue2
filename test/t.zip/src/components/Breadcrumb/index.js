import '../../styles/components/breadcrumb.scss';
import theme from '../../theme';
import BreadcrumbTheme from './theme';
import Breadcrumb from './Breadcrumb';
import BreadcrumbItem from './BreadcrumbItem';

Breadcrumb.install = function (Vue) {
  Vue.component(Breadcrumb.name, Breadcrumb);
  Vue.component(BreadcrumbItem.name, BreadcrumbItem);
};

theme.addCreateTheme(BreadcrumbTheme);
export { Breadcrumb, BreadcrumbItem };
export default Breadcrumb;
