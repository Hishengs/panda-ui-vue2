import route from '../../mixins/route';
import Poptip from '../Poptip';

export default {
  name: 'klk-breadcrumb-item',
  mixins: [route],
  props: {
    disabled: Boolean,
    maxWidth: [String, Number],
  },
  data () {
    return {
      isCurrent: false,
      showPoptip: false,
      isTextOverflow: false,
    };
  },
  computed: {
    cStyle () {
      return {
        maxWidth: this.maxWidth
          ? typeof this.maxWidth === 'string'
            ? parseFloat(this.maxWidth) + 'px'
            : this.maxWidth + 'px'
          : '',
      };
    },
    cClass () {
      return {
        'is-current': this.isCurrent,
        'is-disabled': this.disabled,
      };
    },
  },
  render (h) {
    const props = this.to ? this.generateRouteProps() : {
      href: this.href
    };

    const link = h(this.to ? 'router-link' : 'a', {
      [this.to ? 'props' : 'domProps']: props,
      ref: 'link',
      style: {
        color: this.$parent.color,
      }
    }, this.$slots.default || 'Empty');

    return h('span', {
      staticClass: 'klk-breadcrumb-item',
      class: this.cClass,
      style: this.cStyle,
      ref: 'item',
      on: {
        mouseenter: (e) => {
          if (!!this.maxWidth && this.isTextOverflow) {
            this.showPoptip = true;
          }
        },
        mouseleave: (e) => {
          if (!!this.maxWidth && this.isTextOverflow) {
            this.showPoptip = false;
          }
        }
      }
    }, [
      !!this.maxWidth
        ? h(Poptip, {
          props: {
            trigger: 'none',
            value: this.showPoptip,
            offset: -4,
            maxWidth: 400,
          },
        }, [
          link,
          h('template', {
            slot: 'content'
          }, this.$slots.default)
        ])
        : link
    ]);
  },
  mounted () {
    const el = this.$refs.link;
    if (el) {
      this.isTextOverflow = el.clientWidth < el.scrollWidth;
    }
  }
};
