import Swiper from './Swiper.vue';
import Slide from './Slide.vue';

Swiper.install = function (Vue) {
    Vue.component('klk-swiper', Swiper);
    Vue.component('klk-slide', Slide);
}

export { Swiper, Slide };

export default Swiper;
