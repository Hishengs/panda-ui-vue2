export default (theme) => {
  return `
    .klk-avatar {
      background-color: ${theme.track};
      color: ${theme.text.alternate};
    }
  `;
};

