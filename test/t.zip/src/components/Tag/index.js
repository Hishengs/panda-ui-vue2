import '../../styles/components/tag.scss';
import Tag from './tag.vue';
import TagGroup from './tag-group.vue';

Tag.install = function (Vue) {
  Vue.component(Tag.name, Tag);
  Vue.component(TagGroup.name, TagGroup);
};

export {
  Tag,
  TagGroup
};

export default Tag;
