<template>
  <div class="klk-tag-group" :class="cClass">
    <slot></slot>
  </div>
</template>

<script>
  export default {
    name: 'klk-tag-group',
    props: {
      checkable: Boolean,
      multiple: Boolean,
      value: {
        type: [String, Number, Array],
        default () {
          return this.multiple ? [] : null;
        }
      },
    },
    data () {
      return {
        children: [],
      };
    },
    computed: {
      cClass () {
        return {
          'klk-tag-group-multiple': this.multiple,
          'klk-tag-group-checkable': this.checkable,
        };
      },
    },
    mounted () {
      this.init();
    },
    methods: {
      init () {
        this.children = (this.$slots.default || [])
          .filter(item => !!item.componentInstance)
          .map(item => item.componentInstance);
          
        this.children.forEach(child => {
          child.inGroup = true;
        });
      },
      onChildTagClick (value) {
        let newVal;
        if (this.multiple) {
          newVal = this.value.slice(0);
          const index = newVal.indexOf(value);
          if (index === -1) {
            newVal.push(value);
          } else newVal.splice(index, 1);
        } else {
          newVal = this.value;
          if (newVal === value) {
            newVal = null;
          } else newVal = value;
        }
        this.$emit('input', newVal);
      },
    },
  };
</script>