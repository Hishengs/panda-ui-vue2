<template>
  <div class="klk-tag" :class="cClass" @click="onClick">
    <div class="klk-tag-inner">
      <slot></slot>
    </div>
    <!-- <Icon v-if="closable" type="close" class="klk-tag-close-btn" @click="onClose"></Icon> -->
    <svg xmlns="http://www.w3.org/2000/svg" class="klk-tag-multiple-check-svg" viewBox="0 0 8 8">
      <path fill="currentColor" fill-rule="evenodd" d="M7.495 1.966c.293.293.293.767 0 1.06l-3.889 3.89c-.284.283-.739.292-1.033.025-.054-.032-.104-.07-.15-.117L.655 5.057c-.292-.293-.292-.768 0-1.061.293-.293.768-.293 1.061 0L3.06 5.339l3.375-3.373c.293-.293.768-.293 1.06 0z"/>
    </svg>
  </div>
</template>

<script>
  import Icon from '../Icon';
  import { findComponentsUpward } from '../../utils';

  export default {
    name: 'klk-tag',
    components: {
      Icon,
    },
    props: {
      value: [String, Number],
      checked: Boolean,
      disabled: Boolean,
      size: {
        type: String,
        validator (val) {
          return ['small', 'normal'].includes(val);
        }
      },
      closable: Boolean,
    },
    data () {
      return {
        inGroup: false,
        parent: null,
      };
    },
    computed: {
      cClass () {
        return {
          'klk-tag-checked': this.isChecked,
          'klk-tag-disabled': this.disabled,
          'klk-tag-closable': this.closable,
          [`klk-tag-${this.size}`]: !!this.size,
        };
      },
      isChecked () {
        if (this.inGroup) {
          if (this.parent) {
            const { value, multiple } = this.parent;
            return multiple
              ? value.includes(this.value)
              : value === this.value;
          } else return false;
        } else return this.checked;
      },
    },
    mounted () {
      const comps = findComponentsUpward(this, 'klk-tag-group');
      this.parent = comps[0];
    },
    methods: {
      onClose (e) {
        if (this.disabled) return;
        this.$emit('close', e);
      },
      onClick (e) {
        if (this.disabled) return;
        this.$emit('click', e);
        if (this.inGroup) {
          this.parent && this.parent.onChildTagClick(this.value);
        }
      },
    }
  };
</script>
