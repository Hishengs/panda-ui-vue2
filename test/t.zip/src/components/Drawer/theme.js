export default (theme) => {
  return `
  .klk-drawer {
    background-color: ${theme.background.paper};
  }
  `;
};
