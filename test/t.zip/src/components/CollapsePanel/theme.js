export default (theme) => {
  return `
  .klk-collapse-panel {
    color: ${theme.text.primary};
    border-top-color: ${theme.divider};
  }
  .klk-collapse-toggle-btn {
    color: ${theme.text.secondary};
  }
  .klk-collapse-panel-actions {
    border-top-color: ${theme.divider};
  }
  `;
};
