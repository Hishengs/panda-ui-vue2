import '../../styles/components/collapse.scss';
import theme from '../../theme';
import CollapseTheme from './theme';
import Collapse from './collapse';

Collapse.install = function (Vue) {
  Vue.component(Collapse.name, Collapse);
};

theme.addCreateTheme(CollapseTheme);
export default Collapse;
