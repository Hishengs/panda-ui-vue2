<template>
  <div :class="cClass">
    <!-- prev -->
    <div @click="prev()" v-show="showPrevBtn" :class="prevCls">
      <slot name="prev-btn">
        <Icon type="icon_navigation_chevron_left_xs" :size="20"></Icon>
      </slot>
    </div>
    <div class="klk-card-swiper-items-wrapper">
      <!-- items -->
      <div class="klk-card-swiper-items" ref="items" :style="{
        transform: `translateX(-${translateX}px)`,
      }" @transitionend="onTransitionEnd">
        <slot></slot>
      </div>
    </div>
    <!-- next -->
    <div @click="next()" v-show="showNextBtn" :class="nextCls">
      <slot name="next-btn">
        <Icon type="icon_navigation_chevron_right_xs" :size="20"></Icon>
      </slot>
    </div>
  </div>
</template>

<script>
import Icon from "../Icon/index";

const prefixCls = 'klk-card-swiper';

export default {
  name: "klk-card-swiper",
  components: {
    Icon
  },
  props: {
    itemWidth: {
      type: [Number, String],
      default: '100%',
    },
    itemGap: {
      type: Number,
      default: 20,
    },
    scrollMode: Boolean,
    disableBoundarySlide: Boolean,
  },
  data() {
    return {
      currentIndex: 0,
      items: [],
      translateX: 0,
      clientWidth: 0,
      scrollWidth: 0,
    };
  },
  computed: {
    isLeftBounary () {
      return this.translateX === 0;
    },
    isRightBounary () {
      return this.translateX + this.clientWidth === this.scrollWidth;
    },
    currentItem () {
      return this.items[this.currentIndex];
    },
    currentOffsetX () {
      return this.getCurrentItemOffsetX();
    },
    cClass () {
      return {
        'klk-card-swiper': true,
        'klk-card-swiper-scroll': this.scrollMode,
      };
    },
    prevCls() {
      return [
        `${prefixCls}-prev-btn`,
        {
          [`${prefixCls}-prev-btn-disabled`]: this.prevDisabled
        }
      ];
    },
    nextCls() {
      return [
        `${prefixCls}-next-btn`,
        {
          [`${prefixCls}-next-btn-disabled`]: this.nextDisabled
        }
      ];
    },
    showPrevBtn () {
      return !this.prevDisabled && !this.scrollMode;
    },
    showNextBtn () {
      return !this.nextDisabled && !this.scrollMode;
    },
    nextDisabled() {
      return this.currentIndex === this.items.length - 1 || this.isRightBounary;
    },
    prevDisabled() {
      return this.currentIndex === 0 || this.isLeftBounary;
    },
  },
  mounted () {
    this.updateWidth();
  },
  methods: {
    prev() {
      if (this.prevDisabled) {
        return;
      }
      const index = this.currentIndex - 1;
      if (index < 0) return;
      this.currentIndex = index;
      // 已经在视野内则继续下一个
      if (this.isItemInside(this.currentIndex) && this.isRightBounary) {
        this.prev();
      } else {
        this.slide();
      }
    },
    next() {
      if (this.nextDisabled) {
        return;
      }
      const index = this.currentIndex + 1;
      if (index >= this.items.length) return;
      this.currentIndex = index;
      this.slide();
    },
    slide () {
      const maxScrollOffsetX = this.scrollWidth - this.clientWidth;
      this.translateX = this.currentOffsetX > maxScrollOffsetX ? maxScrollOffsetX : this.currentOffsetX;
    },
    getCurrentItemOffsetX () {
      if (this.currentItem) {
        return this.currentItem.$el.offsetLeft;
      }
      return 0;
    },
    isItemOnLeftBoundary (index) {
      const item = this.items[index];
      if (!item) return false;
      const { offsetLeft: itemOffsetLeft, clientWidth: itemClientWidth } = item.$el;
      return (itemOffsetLeft - this.translateX) < 0 && (itemOffsetLeft + itemClientWidth - this.translateX) < this.clientWidth;
    },
    isItemOnRightBoundary (index) {
      const item = this.items[index];
      if (!item) return false;
      const { offsetLeft: itemOffsetLeft, clientWidth: itemClientWidth } = item.$el;
      return (itemOffsetLeft - this.translateX) > 0 && (itemOffsetLeft + itemClientWidth - this.translateX) > this.clientWidth;
    },
    isItemFullfill (index) {
      const item = this.items[index];
      if (!item) return false;
      const { offsetLeft: itemOffsetLeft, clientWidth: itemClientWidth } = item.$el;
      return (itemOffsetLeft - this.translateX) <= 0 && (itemOffsetLeft + itemClientWidth - this.translateX) >= this.clientWidth;
    },
    isItemInside (index) {
      const item = this.items[index];
      if (item) {
        const { offsetLeft: itemOffsetLeft, clientWidth: itemClientWidth } = item.$el;
        return (itemOffsetLeft - this.translateX) >= 0 && (itemOffsetLeft + itemClientWidth - this.translateX) <= this.clientWidth;
      } else return false;
    },
    onItemClick (e, index) {
      this.$emit('click', index);
      if (this.disableBoundarySlide || this.scrollMode) return;
      // console.log('>>> onItemClick', e, this.isItemOnLeftBoundary(index), this.isItemOnRightBoundary(index));
      if (this.isItemFullfill(index)) {
        // do nothing
        /* const item = this.items[index];
        if (item) {
          const { width, x, y } = item.$el.getBoundingClientRect();
          const clickOnLeft = e.x <= (x + width / 2);
          // console.log('>>> onItemClick.clickOnLeft', clickOnLeft);
          if (clickOnLeft) this.prev();
          else this.next();
        } */
      }
      // 边缘移动
      else if (this.isItemOnLeftBoundary(index)) {
        this.prev();
      } else if (this.isItemOnRightBoundary(index)) {
        this.next();
      }
    },
    slideTo (index) {
      if (typeof index !== 'number') return;
      if (!(index >= 0 && index < this.items.length)) return;
      if (this.currentIndex === index) return;
      this.currentIndex = index;
      this.slide();
    },
    addItem (itemIns) {
      itemIns.$on('click', (e) => {
        const index = this.items.indexOf(itemIns);
        this.onItemClick(e, index);
      });
      this.items.push(itemIns);
      this.$nextTick(this.updateWidth);
    },
    removeItem (itemIns) {
      const index = this.items.indexOf(itemIns);
      if (index >= 0) {
        this.items.splice(index, 1);
      }
      this.$nextTick(this.updateWidth);
    },
    updateWidth () {
      if (!this.$refs.items) return;
      const { clientWidth, scrollWidth } = this.$refs.items;
      this.clientWidth = clientWidth;
      this.scrollWidth = scrollWidth;
      // console.log('>>> updateWidth', { clientWidth, scrollWidth });
    },
    onTransitionEnd (e) {
      this.$emit('transitionend', -this.translateX);
    }
  }
};
</script>
