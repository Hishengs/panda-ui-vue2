import '../../styles/components/card-swiper.scss';
import CardSwiper from './CardSwiper.vue';
import CardSwiperItem from './CardSwiperItem.vue';

CardSwiper.install = function (Vue) {
  Vue.component(CardSwiper.name, CardSwiper);
  Vue.component(CardSwiperItem.name, CardSwiperItem);
}

export {
  CardSwiper,
  CardSwiperItem
};

export default CardSwiper;
