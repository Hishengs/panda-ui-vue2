<template>
  <div class="klk-card-swiper-item" :style="cStyle" @click="onClick">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'klk-card-swiper-item',
  computed:{
    cStyle(){
      return {
        width: typeof this.$parent.itemWidth === 'string'
          ? this.$parent.itemWidth
          : this.$parent.itemWidth + 'px',
        'margin-right' : this.$parent.itemGap + 'px',
      }
    }
  },
  mounted () {
    this.$parent.addItem(this);
  },
  beforeDestroy () {
    this.$parent.removeItem(this);
  },
  methods: {
    onClick (e) {
      this.$emit('click', e);
    },
  }
}
</script>

