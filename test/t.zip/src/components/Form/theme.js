export default (theme) => {
  return `
  .klk-form-item {
    color: ${theme.text.secondary};
  }

  .klk-form-item__focus {
    color: ${theme.primary};
  }

  .klk-form-item__error {
    color: ${theme.error};
  }
  .klk-form-item-help {
    color: ${theme.text.secondary};
  }
  .klk-form-item__error .klk-form-item-help {
    color: ${theme.error};
  }
  `;
};
