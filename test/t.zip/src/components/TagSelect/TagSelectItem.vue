<template>
  <div :class="cClass" @click="onClick">
    <Icon v-if="!!icon" :type="icon"></Icon>
    <span><slot></slot></span>
  </div>
</template>

<script>
import Icon from '../Icon';
import { findComponentUpward } from '../../utils';

export default {
  name: 'klk-tag-select-item',
  components: {
    Icon,
  },
  props: {
    name: [String, Number],
    icon: String,
  },
  data () {
    return {
      parent: findComponentUpward(this, 'klk-tag-select'),
    };
  },
  computed: {
    cClass () {
      return {
        'klk-tag-select-item': true,
        'klk-tag-select-item-active': this.active,
      };
    },
    active () {
      return this.name !== undefined && this.parent.current === this.name;
    },
  },
  mounted () {
    this.parent.onItemAdd(this);
  },
  beforeDestroy () {
    this.parent.onItemRemove(this);
  },
  methods: {
    onClick () {
      this.parent.onItemClick(this);
    },
  }
};
</script>
