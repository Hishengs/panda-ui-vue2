<template>
  <div :class="cClass">
    <div class="klk-tag-select-items" ref="items">
      <slot></slot>
    </div>
    <div class="klk-tag-select-right">
      <span class="klk-tag-select-mask" v-if="isOverflow"></span>
      <span class="klk-tag-select-toggle-btn" @click="toggleWrap" v-if="isOverflow && !hideToggle">
        <Icon :type="wrap ? 'icon_navigation_chevron_up' : 'icon_navigation_chevron_down'"></Icon>
      </span>
    </div>
  </div>
</template>

<script>
import Icon from '../Icon';

export default {
  name: 'klk-tag-select',
  components: {
    Icon,
  },
  props: {
    value: [Number, String],
    hideToggle: {
      type: Boolean,
      default: false,
    },
    nowrap: {
      type: Boolean,
      default: true,
    },
    size: {
      type: String,
      default: 'small',
      validator (size) {
        return ['small', 'normal', 'large'].includes(size);
      }
    }
  },
  data () {
    return {
      items: [],
      wrap: !this.nowrap,
      isOverflow: false,
      current: this.value,
    };
  },
  computed: {
    cClass () {
      return {
        'klk-tag-select': true,
        'klk-tag-select-no-wrap': !this.wrap,
        'klk-tag-select-is-overflow': this.isOverflow,
        'klk-tag-select-hide-toggle': this.hideToggle,
        [`klk-tag-select-${this.size}`]: !!this.size,
      };
    },
  },
  watch: {
    value (val) {
      this.current = val;
    },
    current (val) {
      this.$emit('input', val);
      this.$nextTick(() => {
        this.$emit('change', val);
      });
    },
    wrap (val) {
      if (!val) {
        const curItem = this.items.find(item => item.active);
        if (curItem && this.$refs.items) {
          this.$nextTick(() => {
            this.showItemInCenter(curItem);
          });
        }
      }
    }
  },
  updated () {
    this.updateIsOverflow();
  },
  mounted () {
    this.updateIsOverflow();
  },
  methods: {
    onItemAdd (item) {
      if (this.items.includes(item)) return;
      this.items.push(item);
    },
    onItemRemove (item) {
      const index = this.items.indexOf(item);
      if (index !== -1) this.items.splice(index, 1);
    },
    onItemClick (item) {
      if (this.current === item.name) return;
      this.current = item.name;
      this.adjustItemPosition(item);
    },
    adjustItemPosition (item) {
      const { offsetLeft, offsetWidth } = item.$el;
      const { offsetLeft: itemsOffsetLeft, offsetWidth: itemsOffsetWidth, scrollLeft } = this.$refs.items;
      const newOffsetLeft = (offsetLeft - itemsOffsetLeft - scrollLeft);
      const isLeftBoundary = newOffsetLeft < 0 && (newOffsetLeft + offsetWidth) > 0;
      const isRightBoundary = newOffsetLeft < itemsOffsetWidth && (newOffsetLeft + offsetWidth) > itemsOffsetWidth;
      /* console.log({
        isLeftBoundary, isRightBoundary
      }); */
      if (isLeftBoundary) {
        this.$refs.items.scrollTo({
          left: offsetLeft - itemsOffsetLeft,
          behavior: 'smooth',
        });
      } else if (isRightBoundary) {
        this.$refs.items.scrollTo({
          left: offsetLeft - itemsOffsetLeft + offsetWidth - itemsOffsetWidth,
          behavior: 'smooth',
        });
      }
    },
    toggleWrap () {
      this.wrap = !this.wrap;
    },
    // should be updated when item added or removed
    updateIsOverflow () {
      const { scrollWidth, clientWidth } = this.$refs.items;
      this.isOverflow = scrollWidth > clientWidth;
    },
    showItemInCenter (item) {
      if (!item) return;
      const { offsetLeft, offsetWidth } = item.$el;
      const { offsetLeft: itemsOffsetLeft, offsetWidth: itemsOffsetWidth } = this.$refs.items;
      const left = (offsetLeft - itemsOffsetLeft) - (itemsOffsetWidth - offsetWidth) / 2;
      /* console.log({
        offsetLeft, offsetWidth, itemsOffsetWidth, left
      }); */
      this.$refs.items.scrollTo({
        left,
        behavior: 'smooth'
      });
    },
  },
};
</script>
