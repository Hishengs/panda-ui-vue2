import '../../styles/components/tag-select.scss';
import TagSelect from './TagSelect.vue';
import TagSelectItem from './TagSelectItem.vue';

TagSelect.install = function (Vue) {
  Vue.component(TagSelect.name, TagSelect);
  Vue.component(TagSelectItem.name, TagSelectItem);
}

export {
  TagSelect,
  TagSelectItem,
};

export default TagSelect;
