export default {
  name: 'klk-step-connector',
  functional: true,
  render (h, { data, children }) {
    data.staticClass = `klk-step-connector ${data.staticClass || ''}`;
    return h('div', data, [h('span', { staticClass: 'klk-step-connector-line' })]);
  }
};
