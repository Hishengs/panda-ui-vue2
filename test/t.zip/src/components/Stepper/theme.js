export default (theme) => {
  return `
  .klk-step-label {
    color: ${theme.text.primary};
  }
  .klk-step-label.disabled {
    color: ${theme.text.disabled};
  }
  .klk-step-label.completed .klk-step-label-icon,
  .klk-step-label.active .klk-step-label-icon {
    color: ${theme.primary};
  }
  .klk-step-label-circle {
    color: ${theme.text.alternate};
  }
  .klk-step-label.completed .klk-step-label-circle,
  .klk-step-label.active .klk-step-label-circle {
    background-color: ${theme.primary};
  }
  `;
};
