export default (theme) => {
  return `
  .klk-linear-progress.klk-secondary-color .klk-linear-progress-background,
  .klk-linear-progress.klk-secondary-color .klk-linear-progress-indeterminate,
  .klk-linear-progress.klk-secondary-color .klk-linear-progress-determinate {
    background-color: ${theme.secondary};
  }
  .klk-linear-progress.klk-success-color .klk-linear-progress-background,
  .klk-linear-progress.klk-success-color .klk-linear-progress-indeterminate,
  .klk-linear-progress.klk-success-color .klk-linear-progress-determinate {
    background-color: ${theme.success};
  }
  .klk-linear-progress.klk-warning-color .klk-linear-progress-background,
  .klk-linear-progress.klk-warning-color .klk-linear-progress-indeterminate,
  .klk-linear-progress.klk-warning-color .klk-linear-progress-determinate {
    background-color: ${theme.warning};
  }
  .klk-linear-progress.klk-info-color .klk-linear-progress-background,
  .klk-linear-progress.klk-info-color .klk-linear-progress-indeterminate,
  .klk-linear-progress.klk-info-color .klk-linear-progress-determinate {
    background-color: ${theme.info};
  }
  .klk-linear-progress.klk-error-color .klk-linear-progress-background,
  .klk-linear-progress.klk-error-color .klk-linear-progress-indeterminate,
  .klk-linear-progress.klk-error-color .klk-linear-progress-determinate {
    background-color: ${theme.error};
  }
  .klk-linear-progress-background {
    background-color: ${theme.primary};
  }
  .klk-linear-progress-indeterminate{
    background-color: ${theme.primary};
  }
  .klk-linear-progress-determinate{
    background-color: ${theme.primary};
  }
  .klk-circle-spinner {
    border-color: ${theme.primary};
  }
  .klk-circle-spinner.klk-secondary-color {
    border-color: ${theme.secondary};
  }
  .klk-circular-progress.klk-secondary-color .klk-circular-progress-determinate-path {
    stroke: ${theme.secondary};
  }
  .klk-circle-spinner.klk-success-color {
    border-color: ${theme.success};
  }
  .klk-circular-progress.klk-success-color .klk-circular-progress-determinate-path {
    stroke: ${theme.success};
  }
  .klk-circle-spinner.klk-warning-color {
    border-color: ${theme.warning};
  }
  .klk-circular-progress.klk-warning-color .klk-circular-progress-determinate-path {
    stroke: ${theme.warning};
  }
  .klk-circle-spinner.klk-info-color {
    border-color: ${theme.info};
  }
  .klk-circular-progress.klk-info-color .klk-circular-progress-determinate-path {
    stroke: ${theme.info};
  }
  .klk-circle-spinner.klk-error-color {
    border-color: ${theme.error};
  }
  .klk-circular-progress.klk-error-color .klk-circular-progress-determinate-path {
    stroke: ${theme.error};
  }
  .klk-circular-progress-determinate-path{
    stroke: ${theme.primary};
  }
  `;
};
