import color from '../../mixins/color';

export default {
  name: 'klk-linear-progress',
  mixins: [color],
  props: {
    max: {
      type: Number,
      default: 100
    },
    min: {
      type: Number,
      default: 0
    },
    mode: {
      type: String,
      default: 'indeterminate',
      validator (val) {
        return ['indeterminate', 'determinate'].indexOf(val) !== -1;
      }
    },
    value: {
      type: Number,
      default: 0
    },
    size: {
      type: [Number, String],
      default: 2
    },
    backgroundColor: {
      type: String,
      default: '#eee'
    }
  },
  computed: {
    percent () {
      return (this.value - this.min) / (this.max - this.min) * 100;
    },
    linearStyle () {
      const { color, mode, percent } = this;
      return {
        // 'background-color': this.getColor(color),
        'background': this.getColor(color),
        width: mode === 'determinate' ? percent + '%' : ''
      };
    },
    linearClass () {
      return 'klk-linear-progress-' + this.mode;
    }
  },
  render (h) {
    return h('div', {
      staticClass: `klk-linear-progress ${this.getColorClass()}`,
      style: {
        height: this.size + 'px'
      }
    }, [
      h('div', {
        staticClass: 'klk-linear-progress-background',
        style: {
          // 'background-color': this.getColor(this.color)
          'background-color': this.getColor(this.backgroundColor)
        }
      }),
      h('div', {
        style: this.linearStyle,
        class: this.linearClass
      })
    ]);
  }
};
