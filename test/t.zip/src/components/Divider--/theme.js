export default (theme) => {
  return `
  .klk-divider {
    background-color: ${theme.divider};
  }
  `;
};
