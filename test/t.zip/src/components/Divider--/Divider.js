export default {
  name: 'klk-divider',
  functional: true,
  props: {
    inset: Boolean,
    shallowInset: Boolean
  },
  render (h, { data, props }) {
    data.staticClass = `${data.staticClass || ''} klk-divider ${props.inset ? 'inset' : ''} ${props.shallowInset ? 'shallow-inset' : ''}`;

    return h('hr', data);
  }
};
