export default (theme) => {
  return `
  .klk-popover{
    background: ${theme.background.paper};
  }
  `;
};
