<template>
  <div :class="cClass">
    <div class="klk-collapse-item-icon" v-if="icon || $slots.icon" @click="toggleCollapse">
      <slot name="icon">
        <Icon :type="icon"></Icon>
      </slot>
    </div>
    <div class="klk-collapse-item-main">
      <div class="klk-collapse-item-header" @click="toggleCollapse">
        <div class="klk-collapse-item-header-inner">
          <div class="klk-collapse-item-title">
            <slot name="title">
              <h2>{{ title }}</h2>
            </slot>
          </div>
          <div class="klk-collapse-item-subtitle" v-if="subTitle || $slots.subTitle">
            <slot name="sub-title">
              <h4>{{ subTitle }}</h4>
            </slot>
          </div>
        </div>
        <Icon
          class="klk-collapse-item-ctrl-btn"
          :type="collapsed ? 'icon_navigation_chevron_down' : 'icon_navigation_chevron_up'"
        ></Icon>
      </div>
      <klk-expand-transition>
        <div class="klk-collapse-item-content" v-show="!collapsed">
          <div class="klk-collapse-item-content-inner">
            <slot></slot>
          </div>
        </div>
      </klk-expand-transition>
    </div>
  </div>
</template>

<script>
import { findComponentUpward } from '../../utils';
import Icon from '../Icon';

export default {
  name: 'klk-collapse-item',
  components: {
    Icon,
  },
  props: {
    title: {
      type: String,
      required: true,
    },
    subTitle: String,
    icon: String,
    name: {
      type: String,
      default: '',
      // default () {
      //   return (new Date().getTime()).toString().slice(7) + '-' + Math.random().toString().slice(2, 8);
      // }
    },
  },
  data () {
    return {
      parent: findComponentUpward(this, 'klk-collapse'),
      collapsed: true,
    }
  },
  computed: {
    cClass () {
      return {
        'klk-collapse-item': true,
      }
    },
  },
  mounted () {
    this.parent && this.parent.addItem(this);
  },
  beforeDestroy () {
    this.parent && this.parent.removeItem(this);
  },
  methods: {
    toggleCollapse () {
      this.parent && this.parent.onChildToggle(this);
    }
  }
};
</script>
