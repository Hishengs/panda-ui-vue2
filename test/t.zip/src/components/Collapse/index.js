import '../../styles/components/collapse.scss';
import Collapse from './Collapse.vue';
import CollapseItem from './CollapseItem.vue';

Collapse.install = function (Vue) {
  Vue.component(Collapse.name, Collapse);
  Vue.component(CollapseItem.name, CollapseItem);
};

export {
  Collapse,
  CollapseItem,
};

export default Collapse;
