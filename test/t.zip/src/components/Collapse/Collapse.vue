<template>
  <div :class="cClass">
    <slot></slot>
  </div>
</template>

<script>
import Vue from 'vue';
import Helper from '../Helpers';

Vue.use(Helper);

export default {
  name: 'klk-collapse',
  props: {
    value: {
      type: [String, Array],
      default () {
        return [];
      }
    },
    split: Boolean,
    accordion: Boolean,
    size: {
      type: String,
      default: 'normal',
      validator (val) {
        return ['normal', 'small'].includes(val);
      }
    },
  },
  data () {
    return {
      children: [],
    };
  },
  computed: {
    cClass () {
      return {
        'klk-collapse': true,
        'klk-collapse-split': this.split,
        [`klk-collapse-${this.size}`]: !!this.size,
      };
    }
  },
  watch: {
    value () {
      this.updateChildCollapsed();
    }
  },
  mounted () {
    this.updateChildCollapsed();
  },
  methods: {
    updateChildCollapsed () {
      const isArray = !(typeof this.value === 'string');
      this.children.forEach(c => {
        if (isArray ? this.value.includes(c.name) : this.value === c.name) {
          c.collapsed = false;
        } else c.collapsed = true;
      });
    },
    addItem (item) {
      if (!this.children.includes(item)) {
        this.children.push(item);
        // console.log(item.name);
      }
    },
    removeItem (item) {
      const index = this.children.indexOf(item);
      this.children.splice(index, 1);
    },
    onChildToggle (item) {
      if (this.accordion) {
        if (!item.collapsed) {
          item.collapsed = true;
        } else {
          for (const child of this.children) {
            if (child === item) {
              child.collapsed = false;
            } else child.collapsed = true;
          }
        }
      } else {
        item.collapsed = !item.collapsed;
      }
      // calculate new value
      const isArray = !(typeof this.value === 'string');
      let newVal;
      if (isArray) {
        newVal = this.children.filter(c => !c.collapsed).map(c => c.name);
      } else {
        const notCollapsed = this.children.find(c => !c.collapsed);
        if (notCollapsed) {
          newVal = notCollapsed.name;
        }
      }
      if (newVal !== undefined) {
        this.$emit('input', newVal);
        this.$emit('change', newVal);
      }
    }
  }
};
</script>
