import DateInput from './DateInput';
import '../../styles/components/date-input.scss';

DateInput.install = function (Vue) {
  Vue.component(DateInput.name, DateInput);
};

export default DateInput;
