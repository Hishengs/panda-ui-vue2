import BottomSheet from '../BottomSheet';
import Modal from '../Modal';
import Popover from '../Popover';

export default {
  props: {
    container: {
      type: String,
      default: 'popover', // modal popover bottomSheet
      validator (val) {
        return val && ['modal', 'popover', 'bottomSheet'].indexOf(val) !== -1;
      }
    },
    trigger: {},
    open: Boolean
  },
  methods: {
    createWrap (h, children) {
      switch (this.container) {
        case 'popover':
          return h(Popover, {
            props: {
              open: this.open,
              cover: true,
              lazy: true,
              trigger: this.trigger
            },
            on: this.$listeners
          }, children);
        case 'modal':
          return h(Modal, {
            props: {
              open: this.open,
              dialogClass: 'klk-picker-modal',
              transition: 'slide-top'
            },
            on: this.$listeners
          }, children);
        case 'bottomSheet':
          return h(BottomSheet, {
            props: {
              open: this.open
            },
            on: this.$listeners
          }, children);
      }
    }
  },
  render (h) {
    return this.createWrap(h, this.$slots.default);
  }
};
