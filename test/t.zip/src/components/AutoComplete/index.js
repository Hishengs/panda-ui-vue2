import '../../styles/components/input.scss';
import '../../styles/components/select.scss';
import AutoComplete from './AutoComplete';

AutoComplete.install = function (Vue) {
  Vue.component(AutoComplete.name, AutoComplete);
};

export default AutoComplete;
