import Vue from 'vue';
import config from './config';
import DialogOpt from './dialog';
import { isServer } from '../../../utils';

const Modal = Vue.extend(DialogOpt);

const instances = [];
const Dialog = function (options) {
  if (isServer) return;
  return new Promise((resolve) => {
    let dialog = new Modal({
      el: document.createElement('div'),
      propsData: {
        ...config,
        icon: config[options.type + 'Icon'] || '',
        ...options
      }
    });
    document.body.appendChild(dialog.$el);
    dialog.open = true;
    if (dialog.mode === 'prompt') {
      setTimeout(() => {
        dialog.$el && dialog.$el.querySelector('input').focus();
      }, 200);
    }

    instances.push(dialog);
    dialog.$on('close', function (result, value) {
      setTimeout(() => {
        dialog.$el && dialog.$el.parentNode && dialog.$el.parentNode.removeChild(dialog.$el);
        dialog.$destroy();
        dialog = null;
      }, 500);

      const index = instances.indexOf(dialog);
      if (index !== -1) {
        instances.splice(index, 1);
      }
      return resolve({ result, value });
    });
  });
};

Dialog.config = function (options) {
  if (!options || Array.isArray(options) || typeof options !== 'object') return config;
  for (const key in options) {
    if (!options.hasOwnProperty(key)) continue;
    config[key] = options[key];
  }
  return config;
};

Dialog.close = function () {
  instances.forEach((dialog) => {
    dialog.close(false);
  });
};

['alert', 'confirm', 'prompt'].forEach((mode) => {
  Dialog[mode] = function (content, options) {
    if (!content && arguments.length < 2) return;
    let title = '';
    switch (arguments.length) {
      case 1:
        options = {};
        break;
      case 2:
        if (typeof options === 'string') {
          title = options;
          options = {};
        }
        break;
      default:
        title = arguments[1];
        options = arguments[2];
        break;
    }
    return Dialog({
      title,
      content,
      ...options,
      mode: mode
    });
  };
});

Dialog.install = function (Vue, options) {
  Dialog.config(options);
  Vue.prototype.$alert = Dialog.alert;
  Vue.prototype.$confirm = Dialog.confirm;
  Vue.prototype.$prompt = Dialog.prompt;
};

export default Dialog;
