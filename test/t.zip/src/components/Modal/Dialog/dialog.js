import '../../../styles/components/dialog.scss';
import Button from '../../Button';
import Input from '../../Input';
import Icon from '../../Icon';
import Modal from '../Modal';

export default {
  name: 'klk-dialog',
  props: {
    title: String,
    icon: String,
    iconSize: Number,
    mode: {
      type: String,
      default: 'alert',
      validator (val) {
        return ['alert', 'confirm', 'prompt'].indexOf(val) !== -1;
      }
    },
    // type: {
    //   type: String,
    //   default: '',
    //   validator: (val) => ['', 'success', 'info', 'warning', 'error'].indexOf(val) !== -1
    // },
    content: [String, Function],
    width: [Number, String],
    maxWidth: [Number, String],
    className: String,
    transition: String,
    beforeClose: Function,
    okLabel: String,
    cancelLabel: String,
    inputType: String,
    inputPlaceholder: String,
    inputValue: [String, Number],
    validator: Function
  },
  data () {
    return {
      open: false,
      value: this.inputValue,
      errorText: ''
    };
  },
  methods: {
    handleClose (result) {
      if (this.beforeClose) {
        return this.beforeClose(result, this, () => this.close(result));
      }
      return this.close(result);
    },
    close (isOk) {
      if (isOk && this.mode === 'prompt' && this.validator) {
        const result = this.validator(this.value);
        if (!result.valid) {
          this.errorText = result.message;
          return;
        }
        this.errorText = '';
      }
      this.open = false;
      this.$emit('close', isOk, this.value);
      return isOk;
    },
    createInput (h) {
      if (this.mode !== 'prompt') return;
      return h(Input, {
        attrs: {
          type: this.inputType,
          placeholder: this.inputPlaceholder
        },
        props: {
          value: this.value,
          errorText: this.errorText,
          fullWidth: true
        },
        on: {
          input: val => (this.value = val),
          keydown: (e) => {
            if (e.keyCode === 13) {
              this.handleClose(true);
            }
          }
        }
      });
    },
    createContent (h) {
      const content = typeof this.content === 'function' ? this.content(h) : this.content;
      return h('div', {
        // class: 'klk-dialog-content'
      }, [
        this.icon ? h(Icon, {
          staticClass: 'klk-modal-content-icon',
          props: {
            type: this.icon,
            color: this.type,
            size: this.iconSize
          }
        }) : undefined,
        h('div', {
          staticClass: 'klk-modal-content-inner'
        }, [
          content,
          this.createInput(h)
        ])
      ]);
    },
    createFooter (h) {
      const buttons = [];
      buttons.push(
        h(Button, {
          props: {
            color: 'primary',
            size:  'small'
          },
          staticClass: 'confirm-button',
          on: {
            click: () => this.handleClose(true)
          }
        }, this.okLabel)
      );
      if (this.mode !== 'alert') {
        buttons.unshift(h(Button, {
          props: {
            flat: true,
            size:  'small',
            type : "secondary",
          },
          staticClass: 'cancel-button',
          on: {
            click: () => this.handleClose(false)
          }
        }, this.cancelLabel));
      }
      return h('div',{
        staticClass: `klk-modal-footer-button-wrapper`,
        slot :'footer'
      },buttons);
    }
  },
  render (h) {
    return h(Modal, {
      props: {
        open: this.open,
        title: this.title,
        width: this.width,
        maxWidth: this.maxWidth,
        modalClass: this.className,
        transition: this.transition,
        overlayClosable: false,
        escPressClosable: false
      }
    }, [
      this.createContent(h),
      this.createFooter(h)
    ]);
  }
};
