import { t } from "../../../locale/index.js";
export default {
  // successIcon: 'check_circle',
  // infoIcon: 'info',
  // warningIcon: 'priority_high',
  // errorIcon: 'warning',
  // iconSize: 24,
  okLabel: t('messagebox.confirm'),
  cancelLabel:  t('messagebox.cancel'),
  transition: 'fade' // 'slide-top', 'slide-bottom', 'slide-left', 'slide-right', 'fade', 'scale'
};
