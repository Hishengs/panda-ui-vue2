import '../../styles/components/modal.scss';
import theme from '../../theme';
import ModalTheme from './theme';
import Modal from './Modal';
import Dialog from './Dialog';

Modal.install = function (Vue) {
  Vue.component(Modal.name, Modal);
  Vue.use(Dialog);
};

theme.addCreateTheme(ModalTheme);
export default Modal;
