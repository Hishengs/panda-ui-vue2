import { fade } from '../../utils/colorManipulator';

export default (theme) => {
  return `
  .klk-modal {
    background-color: ${theme.background.paper};
  }
  .klk-modal-scrollable .klk-modal-title {
    border-bottom-color: ${theme.divider};
  }
  .klk-modal-scrollable .klk-modal-actions {
    border-top-color: ${theme.divider};
  }
  .klk-modal-title {
    color: ${theme.text.primary};
  }
  .klk-modal-body {
    color: ${fade(theme.text.primary, 0.6)};
  }
  `;
};
