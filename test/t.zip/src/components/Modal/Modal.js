import popup from '../../mixins/popup';
import resize from '../../directives/resize';
import {convertClass, getWidth} from '../../utils';
import Icon from '../Icon';
import Button from '../Button';
import { t } from "../../locale/index.js";

export default {
    name: 'klk-modal',
    mixins: [popup],
    directives: {
        resize
    },
    props: {
        size: {
            type: String,
            default: 'normal',
            validator(val) {
                return ['normal', 'large'].includes(val);
            }
        },
        modalClass: [String, Array, Object],
        title: String,
        okLabel: {
          type: String,
          default: t('messagebox.confirm'),
        },
        cancelLabel: {
          type: String,
          default: t('messagebox.cancel'),
        },
        closable: Boolean,
        scrollable: Boolean,
        showDefaultFooter : {
            type: Boolean,
            default: true
        },
        padding: { // 设置scrollable 之后 modal 框距离顶部和底部的值
            type: Number,
            default: 60
        },
        fullscreen: Boolean,
        width: [String, Number],
        maxWidth: [String, Number],
        lockScroll: {
            type: Boolean,
            default: true
        },
        transition: {
            type: String,
            default: 'fade',
            validator(val) {
                return ['slide-top', 'slide-bottom', 'slide-left', 'slide-right', 'fade', 'scale'];
            }
        }
    },
    mounted() {
        this.setMaxModalContentHeight();
    },
    updated() {
        this.$nextTick(() => {
            this.setMaxModalContentHeight();
        });
    },
    methods: {
        onClose() {
          this.$emit('on-close');
          this.$emit('close', 'icon');
        },
        onConfirm(){
          this.$emit('on-confirm');
        },
        onCancel(){
          this.$emit('on-cancel');
        },
        handleWrapperClick(e) {
            if (this.$el !== e.target) return;
            this.overlayClick(e);
        },
        setMaxModalContentHeight() {
            const modalEl = this.$refs.modal;
            if (!modalEl) return;
            if (!this.scrollable) {
                modalEl.style.maxHeight = '';
                return;
            }
            const maxModalContentHeight = window.innerHeight - 2 * this.padding ;
            const {title, header, body , footer } = this.$refs;
            if (body) {
                let maxBodyHeight = maxModalContentHeight;
                if (title) maxBodyHeight -= title.offsetHeight;
                if (header) maxBodyHeight -= header.offsetHeight;
                if (footer) maxBodyHeight -= footer.offsetHeight;
                body.style.maxHeight = (maxBodyHeight - 2 * parseInt(getComputedStyle(modalEl).padding))+ 'px';
            }
            modalEl.style.maxHeight = maxModalContentHeight + 'px';
        }
    },
    watch: {
        open(newValue) {
            if (!newValue) return;
            this.$nextTick(() => {
                this.setMaxModalContentHeight();
                const modalEl = this.$refs.modal;
                if (!modalEl) return;
                modalEl.focus();
            });
        }
    },
    render(h) {
        // title
        const isShowTitle = this.title;
        const modalTitle = isShowTitle ? h('div', {
            staticClass: 'klk-modal-title',
            ref: 'title'
        },  this.title) : undefined;
        // header
       const isShowHeader = this.$slots.header && this.$slots.header.length > 0;
       const modalHeader = isShowHeader ? h('div',{
         staticClass: 'klk-modal-header',
         ref: 'header'
       },this.$slots.header) : undefined;
       // close icon
        const modalClose = this.closable ? h(Icon, {
            props: {
                type: 'icon_navigation_close',
                color: "#ffffff"
            },
            on: {
                click: this.onClose
            },
            staticClass: 'klk-modal-close'
        }) : undefined;
        // body
        const modalBody = h('div', {
            staticClass: 'klk-modal-body',
            ref: 'body'
        }, this.$slots.default);
        // footer
        const isShowFooter =  this.$slots.footer && this.$slots.footer.length > 0  || this.showDefaultFooter;
        const buttonSize = this.size === 'large' ? 'normal' :'small';
        const confirmButton = h(Button,{
            staticClass: 'confirm-button',
            props:{
              size:  buttonSize
            },
            on: {
                click: this.onConfirm
            },
        },this.okLabel);
        const cancelButton = h(Button,{
            staticClass: 'cancel-button',
            props:{
              type : "secondary" ,
              size:  buttonSize
            },
            on: {
                click: this.onCancel
            },
        },this.cancelLabel);

        const modalFooterDefault = h('div', {
          staticClass : 'klk-modal-footer-button-wrapper'
        }, [cancelButton,confirmButton]);

        const modalFooter = isShowFooter ? h('div', {
            staticClass: 'klk-modal-footer',
            ref: 'footer'
        }, this.$slots.footer && this.$slots.footer.length > 0 ? this.$slots.footer :  [modalFooterDefault]) : undefined;

        const data = {
            staticClass: 'klk-modal ' + convertClass(this.modalClass).join(' '),
            attrs: {
                tabindex: -1
            },
            class: {
                'klk-modal-fullscreen': this.fullscreen,
                'klk-modal-scrollable': this.scrollable,
                [`klk-${this.transition}`]: true,
                'klk-modal-large': this.size === 'large',
                'klk-modal-normal': this.size === 'normal',
            },
            ref: 'modal'
        };

        if (!this.fullscreen) {
            const width = this.size === 'normal' ? getWidth(420) : getWidth(960);
            data.style = {
                'width': this.width ? getWidth(this.width) : width
            };
        }
        const modal = h('div', data, [modalTitle,modalHeader, modalClose, modalBody, modalFooter]);

        return this.open ? h('transition', {
            props: {
                name: `klk-modal-transition`
            }
        }, [
            h('div', {
                staticClass: 'klk-modal-wrapper',
                directives: [{
                    name: 'resize',
                    value: () => this.setMaxModalContentHeight()
                }],
                style: {
                    'z-index': this.zIndex
                },
                on: {
                    click: this.handleWrapperClick
                }
            }, [modal])
        ]) : null;
    }
};
