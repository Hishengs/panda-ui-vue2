import { convertClass } from '../../utils';

export default {
  name: 'klk-paper',
  functional: true,
  props: {
    circle: Boolean,
    rounded: {
      type: Boolean,
      default: true
    },
    zDepth: {
      type: Number,
      default: 0,
      validator (val) {
        return val >= 0 && val < 25;
      }
    }
  },
  render (h, { data, props, children }) {
    const classObj = {
      'klk-paper-circle': props.circle,
      'klk-paper-round': props.rounded,
      ['klk-elevation-' + props.zDepth]: !!props.zDepth
    };
    data.staticClass = `klk-paper ${data.staticClass || ''} ${convertClass(classObj).join(' ')}`;
    return h('div', data, children);
  }
};
