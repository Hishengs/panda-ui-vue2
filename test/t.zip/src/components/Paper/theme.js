export default (theme) => {
  return `
  .klk-paper {
    color: ${theme.text.primary};
    background-color: ${theme.background.paper};
  }
  `;
};
