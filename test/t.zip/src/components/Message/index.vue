<template>
  <div class="klk-message" :class="cClass" v-if="show">
    <div class="icon">
      <Icon type="icon_tips_tips" size="16" color="#1890ff"></Icon>
    </div>
    <div class="klk-message-body">
      <slot>
        {{ content }}
      </slot>
    </div>
    <span class="close-btn" v-if="closable" @click="onClose">
      <Icon type="icon_navigation_close" size="16"></Icon>
    </span>
  </div>
</template>

<script>
  import Icon from '../Icon';

  export default {
    name: 'klk-message',
    components: {
      Icon,
    },
    props: {
      value: Boolean,
      closable: {
        type: Boolean,
        default: false,
      },
      content: {
        type: String,
        default: '',
      },
    },
    data (){
      return {
        show: this.value,
        showFooter: false,
      };
    },
    watch: {
      show (isShow) {
        this.$emit('input', isShow);
      },
      value (val) {
        this.show = val;
      }
    },
    computed: {
      cClass (){
        return [
          this.closable ? 'closable' : '',
        ].filter(cls => cls !== '').join(' ');
      },
    },
    mounted () {
      this.showFooter = !!this.$slots.footer;
    },
    methods: {
      onClose (e){
        this.$emit('close', e);
        this.show = false;
      },
    },
  };
</script>
