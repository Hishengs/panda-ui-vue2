import { fade } from '../../utils/colorManipulator';

export default (theme) => {
  return `
  .klk-item-wrapper.hover {
    background-color: ${fade(theme.text.primary, 0.1)};
  }
  .klk-item {
    color: ${theme.text.primary};
  }
  .klk-item-action {
    color: ${theme.text.secondary};
  }
  .klk-item.is-selected {
    color: ${theme.primary};
  }
  .klk-item-sub-title {
    color: ${theme.text.secondary};
  }
  .klk-item-after-text {
   color: ${theme.text.secondary};
  }
  `;
};
