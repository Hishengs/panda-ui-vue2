export default {
  name: 'klk-list-item-action',
  functional: true,
  render (h, { data, props, children }) {
    data.staticClass = `klk-item-action ${children && children.length > 1 ? 'is-more' : ''} ${data.staticClass || ''}`;
    return h('div', data, children);
  }
};
