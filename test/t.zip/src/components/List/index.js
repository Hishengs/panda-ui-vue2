import '../../styles/components/list.scss';
import theme from '../../theme';
import ListTheme from './theme';
import { createSimpleFunctional } from '../../utils';
import List from './List';
import ListItem from './ListItem';
import ListAction from './ListAction';

export { List, ListItem, ListAction };
export const ListItemContent = createSimpleFunctional('klk-item-content', 'div', 'klk-list-item-content');
export const ListItemTitle = createSimpleFunctional('klk-item-title', 'div', 'klk-list-item-title');
export const ListItemSubTitle = createSimpleFunctional('klk-item-sub-title', 'div', 'klk-list-item-sub-title');
export const ListItemAfterText = createSimpleFunctional('klk-item-after-text', 'span', 'klk-list-item-after-text');

List.install = function (Vue) {
  Vue.component(List.name, List);
  Vue.component(ListItem.name, ListItem);
  Vue.component(ListAction.name, ListAction);
  Vue.component(ListItemContent.name, ListItemContent);
  Vue.component(ListItemTitle.name, ListItemTitle);
  Vue.component(ListItemSubTitle.name, ListItemSubTitle);
  Vue.component(ListItemAfterText.name, ListItemAfterText);
};

theme.addCreateTheme(ListTheme);
export default List;
