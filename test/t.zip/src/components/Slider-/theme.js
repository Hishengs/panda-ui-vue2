export default (theme) => {
  return `
  .klk-slider {
    color: ${theme.primary};
  }
  .klk-slider-track{
    background-color: ${theme.track};
  }
  .klk-slider.disabled .klk-slider-fill{
    background-color: ${theme.track};
  }
  .klk-slider.zero .klk-slider-thumb,
  .klk-slider.disabled .klk-slider-thumb{
    border-color: ${theme.track};
    color: ${theme.track};
    background-color: ${theme.text.alternate};
  }
  `;
};
