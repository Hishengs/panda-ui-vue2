export default {
  zIndex: 2000,
  top: 0,
  speed: 300,
  color: 'primary',
  size: 2,
  className: ''
};
