import '../../styles/components/loading-bar.scss';
import config from './config';
import LoadingBar from './loading-bar';
import Progress from '../Progress';

LoadingBar.version = '__VERSION__';

LoadingBar.config = function (options) {
  if (!options || Array.isArray(options) || typeof options !== 'object') return config;
  for (const key in options) {
    if (!options.hasOwnProperty(key)) continue;
    config[key] = options[key];
  }
  return config;
};

LoadingBar.install = function (Vue, options) {
  Vue.use(Progress);
  LoadingBar.config(options);
  Vue.prototype.$loadingBar = LoadingBar;
};

export default LoadingBar;
