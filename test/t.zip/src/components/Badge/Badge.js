import { convertClass } from '../../utils';
import color from '../../mixins/color';

export default {
  name: 'klk-badge',
  mixins: [color],
  props: {
    content: {
      type: String,
      default: ''
    },
    circle: Boolean,
    badgeClass: [String, Object, Array]
  },
  render (h) {
    const slots = this.$slots;
    const isFloat = slots.default && slots.default.length > 0;
    const badge = h('em', {
      staticClass: `klk-badge ${convertClass(this.badgeClass).join(' ')} ${this.getColorClass()}`,
      style: {
        'background-color': this.getColor(this.color)
      },
      class: {
        'klk-badge-circle': this.circle,
        'klk-badge-float': isFloat
      }
    }, slots.content && slots.content.length > 0 ? slots.content : this.content);

    return h('div', {
      staticClass: 'klk-badge-container',
      on: this.$listeners
    }, [slots.default, badge]);
  }
};
