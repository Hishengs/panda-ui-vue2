import '../../styles/components/badge.scss';
import Badge from './Badge.vue';

Badge.install = function (Vue) {
  Vue.component(Badge.name, Badge);
};

export {
  Badge,
};

export default Badge;
