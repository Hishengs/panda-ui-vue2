<template>
  <div :class="cClass">
    <slot></slot>
    <sup
      v-show="!hidden && (content || content === 0 || isDot || !!$slots.value)"
      class="klk-badge-content"
      :style="cStyle"
    >
      <slot name="value">{{ content }}</slot>
    </sup>
  </div>
</template>

<script>
export default {
  name: 'klk-badge',
  props: {
    value: [String, Number],
    min: {
      type: Number,
      default: 1,
    },
    max: {
      type: Number,
      default: 99,
    },
    isDot: Boolean,
    hidden: Boolean,
    color: String,
    offset: {
      type: Array,
      validator (val) {
        return val.length === 2;
      }
    },
  },
  computed: {
    cClass () {
      return {
        'klk-badge': true,
        'klk-badge-fixed': !!this.$slots.default,
        'klk-badge-dot': this.isDot,
      };
    },
    cStyle () {
      let sty = {
        backgroundColor: !!this.color ? this.color : '',
      };
      if (this.offset) {
        const [x, y] = this.offset;
        sty = {
          marginTop: `${y}px`,
          marginRight: `${-x}px`,
          ...sty,
        };
      }
      return sty;
    },
    content() {
      if (this.isDot) return;
      let { value, min, max } =  this;
      if (typeof value === 'number') {
        if (min !== undefined) {
          value = value < min ? min : value;
        }
        if (max !== undefined) {
          value = value > max ? `${max}+` : value;
        }
      }
      return value;
    }
  }
};
</script>
