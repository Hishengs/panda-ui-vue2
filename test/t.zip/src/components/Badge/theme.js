export default (theme) => {
  return `
    .klk-badge{
      background-color: ${theme.track};
      color: ${theme.text.alternate};
    }
  `;
};
