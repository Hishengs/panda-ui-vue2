import '../../styles/components/menu.scss';
import Menu from './Menu';

Menu.install = function (Vue) {
  Vue.component(Menu.name, Menu);
};

export default Menu;
