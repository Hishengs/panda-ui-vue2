import { fade, emphasize } from '../../utils/colorManipulator';
export default (theme) => {
  return `
  .klk-chip {
    background-color: ${theme.background.chip};
    color: ${theme.text.primary};
  }
  .klk-chip:hover .klk-chip-delete-icon{
    color: ${fade(fade(theme.text.primary, 0.26), 0.4)};
  }
  .klk-chip-delete-icon{
    color: ${fade(theme.text.primary, 0.26)};
  }
  .klk-chip:active,
  .klk-chip:focus,
  .klk-chip.is-deletable {
    background-color: ${emphasize(theme.background.chip, 0.08)};
  }
  .klk-chip:hover{
    background-color: ${emphasize(theme.background.chip, 0.08)};
  }
  .klk-chip.klk-primary-color {
    background-color: ${theme.primary};
  }
  .klk-chip.klk-secondary-color {
    background-color: ${theme.secondary};
  }
  .klk-chip.klk-success-color {
    background-color: ${theme.success};
  }
  .klk-chip.klk-warning-color {
    background-color: ${theme.warning};
  }
  .klk-chip.klk-info-color {
    background-color: ${theme.info};
  }
  .klk-chip.klk-error-color {
    background-color: ${theme.error};
  }
  `;
};
