import '../../styles/components/counter.scss';
import Counter from './Counter.vue';

Counter.install = function (Vue) {
  Vue.component(Counter.name, Counter);
};

export {
  Counter
};

export default Counter;
