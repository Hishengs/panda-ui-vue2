<template>
  <div :class="cClass">
    <div :class="decreaseClass" @click="decrease">
      <Icon type="icon_other_minus_xs"></Icon>
    </div>
    <div class="klk-counter-input">
      <input
        ref="input"
        type="text"
        :value="displayValue"
        @change="onChange"
        @focus="onFocus"
        @blur="onBlur"
        @keydown.up.prevent="increase"
        @keydown.down.prevent="decrease"
        :disabled="disabled"
        :autofocus="autofocus"
      >
    </div>
    <div :class="increaseClass" @click="increase">
      <Icon type="icon_other_plus_xs"></Icon>
    </div>
  </div>
</template>

<script>
import Icon from '../Icon';

export default {
  name: 'klk-counter',
  components: {
    Icon,
  },
  props: {
    value: {
      type: Number,
      default: 0,
    },
    min: {
      type: Number,
      default: 0,
    },
    max: {
      type: Number,
      default: Infinity,
    },
    step: {
      type: Number,
      default: 1,
    },
    precision: {
      type: Number,
      validator(val) {
        return val >= 0 && val === parseInt(val, 10);
      }
    },
    size: {
      type: String,
      validator (val) {
        return ['small'].includes(val);
      }
    },
    disabled: Boolean,
    autofocus: Boolean,
  },
  data () {
    return {
      currentValue: this.value,
    };
  },
  computed: {
    decreaseDisabled () {
      return this.disabled || this.countValue(this.currentValue, -this.step) < this.min;
    },
    increaseDisabled () {
      return this.disabled || this.countValue(this.currentValue, +this.step) > this.max;
    },
    decreaseClass () {
      return {
        'klk-counter-decrease': true,
        'klk-counter-decrease-disabled': this.decreaseDisabled
      }
    },
    increaseClass () {
      return {
        'klk-counter-increase': true,
        'klk-counter-increase-disabled': this.increaseDisabled
      }
    },
    cClass () {
      return {
        'klk-counter': true,
        'klk-counter-disabled': this.disabled,
        [`klk-counter-${this.size}`]: !!this.size,
      }
    },
    // calc the actual precision should be used
    cPrecision () {
      const { precision, step } = this;
      const stepPrecision = this.getPrecision(step);
      if (precision !== undefined) {
        if (precision < stepPrecision) {
          console.warn('[Counter]: precision should be large than step\'precision.');
        }
        return precision;
      } else {
        const valPrecision = this.getPrecision(this.currentValue);
        return Math.max(valPrecision, stepPrecision);
      }
    },
    displayValue () {
      if (this.precision) {
        return this.currentValue.toFixed(this.precision);
      } else return this.currentValue;
    },
    // TODO: auto detect and set width of input
    /* inputWidth () {
      const widthPerLetter = 12;
      const minWidth = 32;
      const sVal = this.displayValue.toString();
      const hasDot = sVal.includes('.');
      let width = (hasDot ? sVal.length - 1 : sVal.length) * widthPerLetter;
      width = width > minWidth ? width : minWidth;
      return `${width}px`;
    }, */
  },
  watch: {
    currentValue (val) {
      this.$emit('input', val);
      this.$emit('change', val);
    },
    value (val) {
      if (this.isValid(val)) {
        this.currentValue = val;
      }
    }
  },
  methods: {
    onChange (e) {
      let { value } = e.target;
      value = Number(value);
      if (Number.isNaN(value))  {
        e.target.value = this.currentValue;
        return false;
      }
      this.setValue(this.countValue(value));
    },
    isValid (val) {
      if (typeof val === 'string') val = Number(val);
      if (typeof val !== 'number') return false;
      if (Number.isNaN(val)) return false;
      return true;
    },
    countValue (val, step = 0) {
      if (!this.isValid(val)) return;
      const factor = Math.pow(10, this.cPrecision);
      val = (val * factor + step * factor) / factor;
      val = this.toPrecision(val, this.cPrecision);
      return val;
    },
    setValue (val) {
      if (!this.isValid(val)) return;
      let newVal = val;
      if (newVal > this.max) newVal = this.max;
      if (newVal < this.min) newVal = this.min;
      if (newVal === this.currentValue) return;
      this.currentValue = newVal;
    },
    toPrecision (val, precision) {
      if (!precision) return val;
      return parseFloat(Math.round(val * Math.pow(10, precision)) / Math.pow(10, precision));
    },
    /**
     * get precision with a given value
     */
    getPrecision (val) {
      let precision = 0;
      const sVal = val.toString();
      const index = sVal.indexOf('.');
      if (index !== -1) {
        precision = sVal.slice(index + 1).length;
      }
      return precision;
    },
    decrease () {
      if (this.decreaseDisabled) return;
      this.setValue(this.countValue(this.currentValue, -this.step));
    },
    increase () {
      if (this.increaseDisabled) return;
      this.setValue(this.countValue(this.currentValue, +this.step));
    },
    onFocus (e) {
      this.$emit('focus', e);
    },
    onBlur (e) {
      this.$emit('blur', e);
    },
  }
};
</script>
