export default {
  props: {
    year: [String, Number],
    selected: Boolean,
    disabled: Boolean,
  },
  mounted () {
    if (this.selected) this.$parent.scrollToSelectedYear(this.$el);
  },
  render (h) {
    return h('button', {
      staticClass: `klk-year-button ${this.disabled ? 'disabled' : ''}`,
      class: {
        selected: this.selected
      },
      on: this.$listeners
    }, [
      h('span', {
        staticClass: 'klk-year-button-text'
      }, this.year)
    ]);
  },
  watch: {
    selected (val) {
      if (val) this.$parent.scrollToSelectedYear(this.$el);
    }
  }

};
