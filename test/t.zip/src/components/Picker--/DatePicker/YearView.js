import Toolbar from './Toolbar';
import * as dateUtils from './dateUtils';
import YearButton from './YearButton';

const YEAR_RANGE = 12;

export default {
  props: {
    dateTimeFormat: Object,
    maxDate: Date,
    minDate: Date,
    displayDate: Date
  },
  data () {
    const displayDate = dateUtils.cloneDate(this.displayDate);
    displayDate.setDate(1);
    return {
      displayDates: [displayDate],
      slideType: 'next'
    };
  },
  computed: {
    years () {
      const date = this.displayDates[0];
      // const minYear = this.minDate.getFullYear();
      // const maxYear = this.maxDate.getFullYear();
      const minYear = date.getFullYear() - 1;
      const maxYear = date.getFullYear() + 10;
      const years = [];
      for (let year = minYear; year <= maxYear; year++) {
        years.push(year);
      }
      return years;
    }
  },
  methods: {
    changeDisplayDate (date) {
      const oldDate = this.displayDates[0];
      if (date.getFullYear() === oldDate.getFullYear() && date.getMonth() === oldDate.getMonth()) return;
      this.slideType = date.getTime() > oldDate.getTime() ? 'next' : 'prev';
      const displayDate = dateUtils.cloneDate(date);
      displayDate.setDate(1);
      this.displayDates.push(displayDate);
      this.displayDates.splice(0, 1);
    },
    handleChange (val) {
      const displayDate = dateUtils.cloneDate(this.displayDates[0]);
      const newFullYear = displayDate.getFullYear() + val * YEAR_RANGE;
      if (newFullYear < (this.minDate.getFullYear() - YEAR_RANGE) || newFullYear > this.maxDate.getFullYear()) return;
      displayDate.setFullYear(newFullYear);
      this.changeDisplayDate(displayDate);
    },
    scrollToSelectedYear (yearButtonNode) {
      const container = this.$refs.container;
      const containerHeight = container.clientHeight;
      const yearButtonNodeHeight = yearButtonNode.clientHeight || 32;
      const scrollYOffset = (yearButtonNode.offsetTop + yearButtonNodeHeight / 2) - containerHeight / 2;
      setTimeout(() => (container.scrollTop = scrollYOffset), 0);
    },
    createYearButtons (h) {
      return this.years.map((year) => {
        const disabled = year < this.minDate.getFullYear() || year > this.maxDate.getFullYear();
        return h(YearButton, {
          props: {
            year,
            selected: year === this.displayDate.getFullYear(),
            disabled,
          },
          on: {
            click: (e) => {
              if (disabled) return;
              this.$emit('change', year);
            }
          }
        });
      });
    }
  },
  render (h) {
    const firstYear = this.years[0];
    const prevMonth = firstYear >= (this.minDate.getFullYear() - YEAR_RANGE);
    const nextMonth = firstYear <= this.maxDate.getFullYear();
    return h('div', {
      staticClass: 'klk-datepicker-year-container'
    }, [
      h(Toolbar, {
        props: {
          slideType: this.slideType,
          type: 'year-range',
          displayDates: this.displayDates,
          dateTimeFormat: this.dateTimeFormat,
          prevMonth,
          nextMonth,
        },
        on: {
          // click: () => this.$emit('changeView', 'year'),
          change: this.handleChange
        }
      }),
      h('div', {
        staticClass: 'klk-datepicker-year',
        ref: 'container'
      }, [
        /* h('div', {
          staticClass: 'klk-datepicker-year-list'
        }, this.createYearButtons(h)) */
        this.createYearButtons(h)
      ])
    ]);
  }
};
