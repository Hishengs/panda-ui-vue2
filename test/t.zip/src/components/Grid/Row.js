import { props, generatePropsClass } from './utils';

export default {
  name: 'klk-row',
  functional: true,
  props: {
    ...props,
    tag: String,
    gutter: [Number, String],
  },
  render (h, { data, props, children }) {
    const flex = generatePropsClass(props);

    if (props.gutter !== undefined) {
      const gutter = typeof props.gutter === 'number' ? props.gutter / 2 : parseFloat(props.gutter) / 2;

      data.style = Object.assign(data.style || {}, {
        marginLeft: `-${gutter}px`,
        marginRight: `-${gutter}px`,
      });
      // set padding of cols
      setTimeout(() => {
        for (const child of children) {
          if (child.data && child.data.staticClass.split(' ').includes('col')) {
            child.elm.style.paddingLeft = `${gutter}px`;
            child.elm.style.paddingRight = `${gutter}px`;
          }
        }
      }, 0);
    }

    data.staticClass = ['row', flex, data.staticClass || ''].join(' ');
    return h(props.tag || 'div', data, children);
  }
};
