import AbstractButton from '../../internal/AbstractButton';
import Icon from '../Icon';
import route from '../../mixins/route';
import ripple from '../../mixins/ripple';
import { isNotNull } from '../../utils';
export default {
  name: 'klk-bottom-nav-item',
  mixins: [route, ripple],
  inject: [
    'getBottomNavValue',
    'getBottomNavShift',
    'getDefaultVal',
    'bottomNavItemClick',
    'getActiveColor'
  ],
  props: {
    icon: String,
    title: String,
    value: {}
  },
  data () {
    return {
      itemVal: null
    };
  },
  created () {
    this.itemVal = isNotNull(this.value) ? this.value : this.getDefaultVal();
  },
  computed: {
    active () {
      return this.getBottomNavValue() === this.itemVal;
    },
    activeClassName () {
      return this.getActiveColor().className;
    },
    activeColor () {
      return this.getActiveColor().color;
    },
    shift () {
      return this.getBottomNavShift();
    }
  },
  methods: {
    handleClick () {
      this.bottomNavItemClick(this.itemVal);
    }
  },
  watch: {
    value (val) {
      this.itemVal = val;
    }
  },
  render (h) {
    const icon = this.icon ? h(Icon, { class: 'klk-bottom-item-icon', props: { type: this.icon }}) : undefined;
    const title = this.title ? h('span', { staticClass: 'klk-bottom-item-text' }, this.title) : undefined;
    return h(AbstractButton, {
      staticClass: 'klk-bottom-item',
      class: {
        'klk-bottom-item-active': this.active,
        'is-shift': this.active && this.shift,
        [this.activeClassName]: !this.shift && this.active
      },
      style: {
        color: !this.shift && this.active ? this.activeColor : ''
      },
      props: {
        ripple: !this.shift && this.ripple,
        containerElement: 'div',
        wrapperClass: 'klk-bottom-item-wrapper',
        ...this.generateRouteProps()
      },
      on: {
        click: this.handleClick
      }
    }, [icon, title]);
  }
};
