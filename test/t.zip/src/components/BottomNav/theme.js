import { fade } from '../../utils/colorManipulator';

export default (theme) => {
  return `
  .klk-bottom-nav{
    background-color: ${theme.background.paper};
  }

  .klk-bottom-nav-shift{
    background-color: ${theme.primary};
  }
  .klk-bottom-item {
    color: ${theme.text.secondary};
  }
  .klk-bottom-nav-shift .klk-bottom-item {
    color: ${fade(theme.text.alternate, 0.7)};
  }
  .klk-bottom-item-active .klk-bottom-item-icon,
  .klk-bottom-item-active .klk-bottom-item-text {
    color: ${theme.primary};
  }
  .klk-bottom-nav-shift .klk-bottom-item-active .klk-bottom-item-icon,
  .klk-bottom-nav-shift .klk-bottom-item-active .klk-bottom-item-text {
    color: ${theme.text.alternate};
  }
  `;
};
