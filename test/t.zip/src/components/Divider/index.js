import '../../styles/components/divider.scss';
import Divider from './Divider.vue';

Divider.install = function (Vue) {
  Vue.component(Divider.name, Divider);
}

export default Divider;
