<template>
  <div class="klk-divider" :class="cClass">
    <div class="klk-divider-before" :style="dashedStyle"></div>
    <!-- TODO: 勿删，此处已实现可放置文字，对齐等，目前设计暂无此需求，因此先保留 -->
    <div class="klk-divider-content" v-if="showContent">
      <slot></slot>
    </div>
    <div class="klk-divider-after" :style="dashedStyle"></div>
  </div>
</template>

<script>
  export default {
    name: 'klk-divider',
    props: {
      align: {
        type: String,
        validator (val) {
          return ['left', 'center', 'right'].includes(val);
        },
        default: 'center'
      },
      dashed: Boolean,
      dashedWidth: {
        type: Number,
        default: 5,
      },
      dashedGap: {
        type: Number,
        default: 3,
      },
      size: {
        type: Number,
        default: 1,
      },
    },
    data () {
      return {
        showContent: true,
      };
    },
    computed: {
      cClass () {
        return {
          [`klk-divider-${this.align}`]: true,
          'klk-divider-dashed': this.dashed
        };
      },
      dashedStyle () {
        const p = (this.dashedWidth / (this.dashedWidth + this.dashedGap)) * 100;
        return this.dashed ? {
          height: `${this.size}px`,
          backgroundImage: `linear-gradient(to right, currentColor 0%, currentColor ${p}%, transparent ${p}%)`,
          backgroundSize: `${this.dashedWidth + this.dashedGap}px ${this.size}px`,
        } : {
          borderWidth: `${this.size}px`,
        };
      },
    },
    mounted () {
      this.showContent = this.$slots.default !== undefined;
    }
  };
</script>
