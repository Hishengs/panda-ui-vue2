import Vue from 'vue';
import DatePicker from './DatePicker.vue';
import '../../styles/components/datepicker.scss';

DatePicker.install = function () {
  Vue.component(DatePicker.name, DatePicker);
}

export {
  DatePicker,
};

export default DatePicker;
