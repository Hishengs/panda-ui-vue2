<template>
  <div :class="cls('date-container')" ref="container">
    <div :class="cls('date-row')" v-for="(weekDates, j) in weekArray" :key="j">
      <span
        :class="getDateClass(date)"
        v-for="(date, k) in weekDates"
        :key="k"
        @click="$emit('date-click', date)"
        @mouseenter="onDateHover(date)"
        ref="date"
      >
        <template v-if="!!date">
          <DaySlot
            :slot-render="parent.$scopedSlots.day"
            :args="{
              date,
              disabled: parent.isDateDisabled(date),
              selected: isDateSelected(date),
              now: isToday(date),
            }"
          >
            <span :class="cls('date-inner')">
              {{ date.getDate() }}
            </span>
          </DaySlot>
        </template>
        <template v-else>
          <span :class="cls('date-inner')"></span>
        </template>
      </span>
    </div>
  </div>
</template>

<script>
import * as dateUtils from './dateUtils';
import { findComponentUpward } from '../../utils';

const prefix = 'klk-date-picker';
function cls (name) {
  return name ? `${prefix}-${name}` : prefix;
}

const DaySlot = {
  functional: true,
  props: {
    slotRender: Function,
    args: Object,
  },
  render (h, ctx) {
    return ctx.props.slotRender ? ctx.props.slotRender(ctx.props.args) : ctx.children;
  },
};

export default {
  props: {
    weekArray: Array,
  },
  components: {
    DaySlot,
  },
  data () {
    return {
      parent: findComponentUpward(this, prefix),
    };
  },
  methods: {
    cls,
    isToday (date) {
      if (!date) return false;
      return dateUtils.isEqualDate(date, new Date());
    },
    isDateSelected (date) {
      const { range, curDate } = this.parent;
      if (!curDate) return false;
      return (range ? curDate : [curDate]).some(d => {
        return dateUtils.isEqualDate(d, date);
      });
    },
    isDateInRange (date) {
      const { range, curDate, hoveringDate } = this.parent;
      if (!range || !curDate) return false;
      let leftDate, rightDate;
      let inRange = false;
      const len = curDate.length;
      if (len === 1 && hoveringDate && dateUtils.isAfterDate(hoveringDate, curDate[0])) {
        leftDate = curDate[0];
        rightDate = hoveringDate;
      } else if (len >= 2) {
        leftDate = curDate[0];
        rightDate = curDate[1];
      }
      if (leftDate && rightDate) {
        inRange = dateUtils.isEqualDate(leftDate, rightDate)
          ? false
          : dateUtils.isBetweenDates(date, leftDate, rightDate);
      } else if (leftDate) {
        inRange = dateUtils.isEqualDate(date, leftDate);
      } else if (rightDate) {
        inRange = dateUtils.isEqualDate(date, rightDate);
      }
      return inRange;
    },
    isStartDate (date) {
      const { range, curDate, hoveringDate } = this.parent;
      if (!range || !curDate) return false;
      const len = curDate.length;
      if (len <= 0) return false;
      let isStart = false;
      const isEqual = dateUtils.isEqualDate(date, curDate[0]);
      if (len === 1) {
        if (hoveringDate) {
          isStart = isEqual && dateUtils.isAfterDate(hoveringDate, date);
        } else isStart = isEqual;
      } isStart = isEqual;
      return isStart;
    },
    isEndDate (date) {
      const { range, curDate } = this.parent;
      if (!range || !curDate) return false;
      const len = curDate.length;
      if (len <= 1) return false;
      return dateUtils.isEqualDate(date, curDate[1]);
    },
    // range select and select the same day
    isDoubleSelected (date) {
      const { range, curDate } = this.parent;
      if (!range || !curDate) return false;
      if (curDate && curDate.length >= 2) {
        const [startDate, endDate] = curDate;
        return dateUtils.isEqualDate(startDate, endDate) && dateUtils.isEqualDate(startDate, date);
      } else return false;
    },
    isHovering (date) {
      return dateUtils.isEqualDate(date, this.parent.hoveringDate);
    },
    getDateClass (date) {
      if (date) {
        const { isSoldOut, isDateDisabled, hightlightToday, curDate } = this.parent;
        const soldOut = isSoldOut && isSoldOut(date);
        const disabled = soldOut || isDateDisabled(date);
        const isToday = this.isToday(date, new Date());
        const isStart = this.isStartDate(date);
        const isHoveringEnd = curDate && curDate.length === 1 && !isStart
          && this.isHovering(date) && dateUtils.isAfterDate(date, curDate[0]);
        return {
          [cls('date')]: true,
          [cls('date-end')]: this.isEndDate(date),
          [cls('date-selected')]: this.isDateSelected(date),
          [cls('date-start')]: isStart,
          [cls('date-double-selected')]: this.isDoubleSelected(date),
          [cls('date-in-range')]: this.isDateInRange(date),
          [cls('date-hovering-end')]: isHoveringEnd,
          [cls('date-disabled')]: disabled,
          [cls('date-sold-out')]: soldOut,
          [cls('date-today')]: hightlightToday && isToday,
        };
      } else return {
        [cls('date')]: true,
        [cls('date-empty')]: true,
      };
    },
    onDateHover (date) {
      this.$emit('date-hover', date);
    },
  }
};
</script>
