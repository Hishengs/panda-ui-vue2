<template>
  <div :class="cClass" :style="cStyle">
    <!-- panels -->
    <div :class="cls('panel-container')" :style="{
      bottom: `${tipHeight}px`
    }" :data-tip-height="tipHeight">
      <!-- panel -->
      <div :class="cls('panel')" v-for="(panel, i) in panels" :key="i">
        <div :class="cls('panel-header')" v-show="!verticalScroll">
          <span :class="prevCls" @click="prev" :style="{
            visibility: (doublePanel && i === 1) ? 'hidden' : ''
          }">
            <Icon type="icon_navigation_chevron_left_xs"></Icon>
          </span>
          <div :class="cls('display-title')">
            {{ panel.title }}
          </div>
          <span :class="nextCls" @click="next" :style="{
            visibility: (doublePanel && i === 0) ? 'hidden' : ''
          }">
            <Icon type="icon_navigation_chevron_right_xs"></Icon>
          </span>
        </div>
        <div :class="cls('panel-body')">
          <div :class="cls('week-container')">
            <span :class="cls('week')" v-for="(week, i) in weeks" :key="i">
              {{ week }}
            </span>
          </div>
          <div :class="cls('date-container-wrapper')">
            <template v-if="verticalScroll">
              <div v-for="(c, i) in verticalDateContainers" :key="i" :class="cls('date-container-item')" ref="dateContainerItem">
                <div :class="cls('vertical-display-title')">
                  {{ getDisplayTitle(c[0][c[0].length-1]) }}
                </div>
                <DateContainer
                  :week-array="c"
                  @date-click="onDateClick"
                  @date-hover="onDateHover"
                  @mouseleave.native="hoveringDate = null"
                ></DateContainer>
              </div>
            </template>
            <DateContainer
              :week-array="panel.weekArray"
              @date-click="onDateClick"
              @date-hover="onDateHover"
              @mouseleave.native="hoveringDate = null"
              v-else
            >
            </DateContainer>
          </div>
        </div>
        <div :class="cls('panel-footer')">
          <!--  -->
        </div>
      </div>
    </div>
    <!-- tip -->
    <div :class="cls('tip')" v-if="!!tip || $slots.tip" ref="tip">
      <slot name="tip">
        <Icon type="icon_tips_tips"></Icon>
        <div>{{ tip }}</div>
      </slot>
    </div>
  </div>
</template>

<script>
import Icon from '../Icon';
import * as dateUtils from './dateUtils';
import { t } from '../../locale';
import DateContainer from './DateContainer.vue';

const prefix = 'klk-date-picker';
function cls (name) {
  return name ? `${prefix}-${name}` : prefix;
}

export default {
  name: 'klk-date-picker',
  components: {
    Icon,
    DateContainer,
  },
  props: {
    // type: date, daterange, datetime, datetimerange, month, monthrange?, year, yearrange?
    type: {
      type: String,
      default: 'date',
      validator (val) {
        return ['date', 'date-range'].includes(val);
      }
    },
    date: {
      type: [Date, Array],
      validator (date) {
        if (Array.isArray(date)) {
          return date.length > 0 ? date.every(d => d instanceof Date) : true;
        } else return date instanceof Date;
      }
    },
    // 双面板
    doublePanel: Boolean,
    tip: String,
    firstDayOfWeek: {
      type: Number,
      default: 0,
      validator (val) {
        return [0, 1, 2, 3, 4, 5, 6].includes(val);
      }
    },
    width: {
      type: [Number, String],
      default: 340,
    },
    maxDate: Date,
    minDate: {
      type: Date,
      default: () => new Date()
    },
    shouldDisableDate: Function,
    isSoldOut: Function,
    hightlightToday: Boolean,
    verticalScroll: Boolean,
    verticalMonthOffset: {
      type: Array,
      default: () => [0, 12],
    },
    minRangeGap: {
      type: Number,
      default: 86400 * 1,
    },
  },
  data () {
    return {
      curDate: this.date,
      // viewDate is the first date of every monthday view
      viewDate: null,
      hoveringDate: null,
      tipHeight: 0,
    };
  },
  computed: {
    range () {
      return /range$/.test(this.type);
    },
    cClass () {
      return {
        [cls()]: true,
        [cls('vertical-scroll')]: this.verticalScroll,
      };
    },
    // if it's double panel
    isDoublePanel () {
      return this.doublePanel && !this.verticalScroll;
    },
    weeks () {
      return dateUtils.dateTimeFormat.getWeekDayArray(this.firstDayOfWeek);
    },
    panels () {
      let len = this.isDoublePanel ? 2 : 1;
      const panels = [];
      let viewDate = this.viewDate;
      while (len > 0) {
        // title
        const title = this.getDisplayTitle(viewDate);
        // dates week
        const weekArray = dateUtils.getWeekArray(viewDate, this.firstDayOfWeek);
        panels.push({
          title,
          weekArray,
        });
        // set next panel view date
        viewDate = dateUtils.addMonths(viewDate, 1);
        len--;
      }
      return panels;
    },
    verticalDateContainers () {
      if (!this.verticalScroll) return [];
      const viewDate = this.viewDate;
      let [top, bottom] = this.verticalMonthOffset;
      const topArr = [];
      while (top <= 0) {
        const date = dateUtils.addMonths(viewDate, top);
        const weekArray = dateUtils.getWeekArray(date, this.firstDayOfWeek);
        topArr.push(weekArray);
        top++;
      }
      const bottomArr = [];
      while (bottom > 0) {
        const date = dateUtils.addMonths(viewDate, bottom);
        const weekArray = dateUtils.getWeekArray(date, this.firstDayOfWeek);
        bottomArr.push(weekArray);
        bottom--;
      }
      return [...topArr, ...bottomArr.reverse()];
    },
    cStyle () {
      let width = this.width;
      const factor = this.isDoublePanel ? 2 : 1;
      // if it's digital string
      if (typeof width === 'string' && !Number.isNaN(parseFloat(width))) {
        width = parseFloat(width);
      }
      width = typeof width === 'number' ? `${width * factor}px` : width;
      return {
        width,
      };
    },
    prevDisabled () {
      const lastDateOfPrevMon = dateUtils.addDays(this.viewDate, -1);
      return this.minDate && dateUtils.isBeforeDate(lastDateOfPrevMon, this.minDate);
    },
    nextDisabled () {
      const firstDateOfNextMon = dateUtils.addMonths(this.viewDate, +1);
      return this.maxDate && dateUtils.isAfterDate(firstDateOfNextMon, this.maxDate);
    },
    prevCls () {
      return {
        [cls('prev-btn')]: true,
        [cls('prev-btn-disabled')]: this.prevDisabled,
      };
    },
    nextCls () {
      return {
        [cls('next-btn')]: true,
        [cls('next-btn-disabled')]: this.nextDisabled,
      };
    },
  },
  watch: {
    curDate (val) {
      if (this.range && (!val || val.length < 2)) return;
      this.$nextTick(() => {
        this.$emit('change', val);
      });
      this.$emit('update:date', val);
    },
    date (val) {
      if (val) {
        this.curDate = val;
      }
    }
  },
  created () {
    const curDate = this.curDate;
    let viewDate;
    if (this.range) {
      viewDate = curDate && curDate.length
        ? curDate[0]
        : new Date();
    } else {
      viewDate = curDate || new Date();
    }
    // get a copy
    viewDate = dateUtils.cloneDate(viewDate);
    viewDate.setDate(1);
    this.viewDate = viewDate;
  },
  mounted () {
    if (this.verticalScroll) {
      this.scrollToCurrentMonth();
    }
    if (this.$refs.tip && this.verticalScroll) {
      setTimeout(() => {
        this.tipHeight = this.$refs.tip.offsetHeight;
      }, 100);
    }
  },
  methods: {
    cls,
    getDisplayTitle (date) {
      const mon = t('datePicker.monthsShort')[date.getMonth()];
      const year = date.getFullYear();
      return `${mon} ${year}`;
    },
    prev () {
      if (this.prevDisabled) return;
      this.viewDate = dateUtils.addMonths(this.viewDate, -1);
    },
    next () {
      if (this.nextDisabled) return;
      this.viewDate = dateUtils.addMonths(this.viewDate, +1);
    },
    isDateDisabled (date) {
      if (this.shouldDisableDate) {
        const disbaled = this.shouldDisableDate(date);
        if (disbaled) return true;
      }
      if (
        this.minDate && dateUtils.isBeforeDate(date, this.minDate)
        || this.maxDate && dateUtils.isAfterDate(date, this.maxDate)
      ) {
        return true;
      }
      return false;
    },
    onDateClick (date) {
      if (!date || this.isDateDisabled(date) || (this.isSoldOut && this.isSoldOut(date))) return;
      let curDate = this.curDate;
      if (this.range) {
        // TODO: 需检测区间内是否存在禁用日期
        if (curDate) {
          let num = curDate.length;
          if (num === 1) {
            if (date.getTime() < curDate[0].getTime()) {
              curDate = [date];
            } else {
              if (date.getTime() - curDate[0].getTime() < this.minRangeGap * 1000) {
                return;
              }
              curDate = [...curDate, date];
            }
            // curDate = [...curDate, date].sort((d1, d2) => d1 - d2);
          } else curDate = [date];
        } else {
          curDate = [date];
        }
      } else curDate = date;
      this.curDate = curDate;
      this.$emit('select', date);
    },
    scrollToCurrentMonth () {
      if (!this.$refs.dateContainerItem) return;
      const [top] = this.verticalMonthOffset;
      const target = this.$refs.dateContainerItem[-top];
      if (target) {
        target.parentNode.scrollTop = target.offsetTop;
      }
    },
    onDateHover (date) {
      if (!this.range) return;
      if (date) {
        this.hoveringDate = date;
      } else this.hoveringDate = null;
    },
  }
}
</script>
