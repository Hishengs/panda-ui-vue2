export default (theme) => {
  return `
  .klk-switch.disabled input[type="checkbox"]:checked+.klk-switch-wrapper .klk-switch-track{
    background-color: ${theme.track};
  }
  .klk-switch-checked {
    color: ${theme.primary};
  }
  .klk-switch.disabled .klk-switch-label {
    color: ${theme.text.disabled};
  }
  .klk-switch-label {
    color: ${theme.text.primary};
  }
  .klk-switch.disabled .klk-switch-track {
    background-color: ${theme.track};
  }
  .klk-switch-track {
    background-color: ${theme.track};
  }
  .klk-switch-thumb {
    background-color: ${theme.background.paper};
  }
  `;
};
