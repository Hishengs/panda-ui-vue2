<template>
  <span
    :class="cClass"
    :tabIndex="tabIndex"
    role="switch"
    aria-label="switch"
    :aria-checked="checked"
    :aria-disabled="disabled"
  >
    <span class="klk-switch-base">
      <input
        type="checkbox"
        :name="name"
        :value="checked"
        :checked="checked"
        :disabled="disabled"
        @change="onCheck"
        @focus="onFocus"
        @blur="onBlur"
        ref="input"
        aria-hidden="true"
        tabIndex="-1"
      />
      <span class="klk-switch-track"></span>
      <span class="klk-switch-thumb"></span>
    </span>
    <!-- 设计尚未确定是否需要 label 暂时先隐藏 -->
    <!-- <span class="klk-switch-label" @click="onClick">
      <slot></slot>
    </span> -->
  </span>
</template>

<script>
export default {
  name: 'klk-switch',
  props: {
    name: String,
    value: {
      type: [String, Number, Boolean],
      default: false
    },
    trueValue: {
      type: [String, Number, Boolean],
      default: true
    },
    falseValue: {
      type: [String, Number, Boolean],
      default: false
    },
    disabled: Boolean,
    size: {
      type: String,
      default: 'normal',
      validator (val) {
        return ['normal', 'small'].includes(val);
      }
    },
  },
  data () {
    return {
      checked: this.value,
    };
  },
  computed: {
    cClass () {
      return {
        'klk-switch': true,
        'klk-switch-checked': !!this.checked,
        'klk-switch-disabled': this.disabled,
        [`klk-switch-${this.size}`]: !!this.size,
      };
    },
    tabIndex () {
      return this.disabled ? -1 : 0;
    },
  },
  watch: {
    value (val) {
      if (val === this.trueValue || val === this.falseValue) {
        this.updateChecked();
      } else {
        throw 'value should be true-value or false-value.';
      }
    }
  },
  mounted () {
    this.updateChecked();
  },
  methods: {
    updateChecked () {
      this.checked = this.value === this.trueValue;
    },
    onCheck (e) {
      // console.log('>>> onCheck', e);
      if (this.disabled) return;
      const { checked } = e.target;
      this.checked = checked;
      const value = checked ? this.trueValue : this.falseValue;
      this.$emit('input', value);
      this.$emit('change', value);
    },
    onClick () {
      this.$refs.input.click();
    },
    focus () {
      if (this.disabled) return;
      this.$refs.input.focus();
    },
    blur () {
      if (this.disabled) return;
      this.$refs.input.blur();
    },
    onFocus (e) {
      this.$emit('focus', e);
    },
    onBlur (e) {
      this.$emit('blur', e);
    },
  },
};
</script>
