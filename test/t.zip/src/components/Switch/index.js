import '../../styles/components/switch.scss';
import Switch from './Switch.vue';

Switch.install = function (Vue) {
  Vue.component(Switch.name, Switch);
};

export default Switch;

