import popup from '../../mixins/popup';
import { BottomSheetTransition } from '../../internal/transitions';

export default {
  name: 'klk-bottom-sheet',
  mixins: [popup],
  props: {
    lockScroll: {
      type: Boolean,
      default: true
    }
  },
  render (h) {
    return h(BottomSheetTransition, [
      this.open ? h('div', {
        staticClass: 'klk-bottom-sheet',
        style: {
          'z-index': this.zIndex
        }
      }, this.$slots.default) : undefined
    ]);
  }
};
