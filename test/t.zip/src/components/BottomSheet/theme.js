export default (theme) => {
  return `
    .klk-bottom-sheet {
      background-color: ${theme.background.paper};
    }
  `;
};
