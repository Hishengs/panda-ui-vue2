<template>
  <div
    ref="poptip"
    :class="cClass"
    :data-placement="placement"
    v-click-outside="onClickOutside"
  >
    <div
      class="klk-poptip-reference"
      ref="reference"
      @click="onClick"
      @mouseenter="onMouseenter"
      @mouseleave="onMouseleave"
      @mousedown="onFocus(false)"
      @mouseup="onBlur(false)"
    >
      <slot></slot>
    </div>
    <klk-fade-transition>
      <div
        class="klk-poptip-popper"
        ref="popper"
        v-show="showPopper && (!!title || $slots.title || !!content || $slots.content)"
        @mouseenter="onMouseenter"
        @mouseleave="onMouseleave"
        :style="{
          zIndex: this.popperZIndex,
        }"
      >
        <div class="klk-poptip-popper-inner">
          <div class="klk-poptip-popper-arrow" v-show="arrow"></div>
          <Icon class="klk-poptip-popper-close-btn" type="icon_navigation_close" v-if="closable" @click="onClose"></Icon>
          <div class="klk-poptip-popper-main" :style="mainStyle">
            <div class="klk-poptip-popper-title" v-if="title || $slots.title">
              <slot name="title">{{ title }}</slot>
            </div>
            <div class="klk-poptip-popper-content">
              <slot name="content">{{ content }}</slot>
            </div>
          </div>
        </div>
      </div>
    </klk-fade-transition>
  </div>
</template>

<script>
  import Vue from 'vue';
  import { createPopper } from '@popperjs/core';
  import { isServer } from '../../utils';
  import clickOutside from '../../directives/click-outside.js';
  import { on, off } from '../../utils/dom.js';
  import Icon from '../Icon';
  import Helpers from '../Helpers';

  Vue.use(Helpers);

  let index = 1024;

  function getIndex () {
    return ++index;
  }

  export default {
    name: 'klk-poptip',
    components: {
      Icon,
    },
    props: {
      value: {
        type: Boolean,
        default: false,
      },
      title: {
        type: String,
        default: ''
      },
      content: {
        type: String,
        default: ''
      },
      placement: {
        type: String,
        default: 'top',
        validator (val) {
          return [
            'top-start', 'top', 'top-end',
            'left-start', 'left', 'left-end',
            'right-start', 'right', 'right-end',
            'bottom-start', 'bottom', 'bottom-end'
          ].includes(val);
        },
      },
      trigger: {
        type: String,
        validator (val) {
          return ['hover', 'click', 'focus', 'none'].includes(val);
        },
        default: 'hover'
      },
      offset: {
        type: Number,
        default: 10,
      },
      popperEl: Object,
      referenceEl: Object,
      disabled: Boolean,
      arrow: {
        type: Boolean,
        default: true
      },
      closable: Boolean,
      width: Number,
      maxWidth: {
        type: Number,
        default: 360,
      },
      height: Number,
      maxHeight: {
        type: Number,
        default: 152,
      },
      zIndex: Number,
      dark: Boolean,
    },
    directives: { clickOutside },
    data () {
      return {
        showPopper: this.value,
        popperIns: null,
        // for focus trigger
        inputEl: null,
        popperZIndex: this.zIndex == null ? getIndex() : this.zIndex,
      };
    },
    computed: {
      cClass () {
        return {
          'klk-poptip': true,
          'klk-poptip-dark': this.dark,
          'klk-poptip-closable': this.closable,
        };
      },
      mainStyle () {
        return {
          width: `${this.width}px`,
          maxWidth: `${this.maxWidth}px`,
          height: `${this.height - 24}px`,
          maxHeight: `${this.maxHeight - 24}px`,
        };
      },
    },
    watch: {
      value: {
        immediate: true,
        handler(val) {
          this.showPopper = val;
          this.$emit('input', val);
        }
      },
      showPopper (show) {
        if (show) {
          this.updatePopper();
          this.$emit('show');
        } else {
          this.$emit('hide');
        }
        this.$emit('input', show);
      }
    },
    mounted () {
      this.initFocus();
    },
    updated (){
      this.$nextTick(() => this.updatePopper());
    },
    beforeDestroy () {
      if (this.inputEl) {
        off(this.inputEl, 'focus', this.onFocus);
        off(this.inputEl, 'blur', this.onBlur);
      }
      if (!isServer && this.popperIns) {
        this.popperIns.destroy();
        this.popperIns = null;
      }
    },
    methods: {
      updatePopper () {
        if (isServer) return;
        if (!this.popperIns) {
          this.createPopper();
        } else this.popperIns.update();
      },
      createPopper () {
        if (isServer) return;
        if (this.popperIns) return;
        const reference = this.referenceEl || this.$refs.reference;
        const popper = this.popperEl || this.$refs.popper;
        if (!reference || !popper) return;
        const options = {
          placement: this.placement,
          modifiers: [
            {
              name: 'offset',
              options: {
                offset: (/* { placement, reference, popper } */) => {
                  // 添加偏移
                  return [0, this.offset];
                },
              }
            },
            {
              name: 'flip',
              enabled: false,
            },
            {
              name: 'preventOverflow',
              enabled: false,
            }
          ],
        };
        this.popperIns = createPopper(reference, popper, options);
      },
      initFocus () {
        if (this.shouldResponse('focus')) {
          this.$nextTick(() => {
            const input = this.$refs.reference.querySelectorAll('input');
            const textarea = this.$refs.reference.querySelectorAll('textarea');
            this.inputEl = input ? input[0] : textarea ? textarea[0] : null;
            if (this.inputEl) {
              on(this.inputEl, 'focus', this.onFocus);
              on(this.inputEl, 'blur', this.onBlur);
            }
          });
        }
      },
      shouldResponse (trigger = '') {
        return !(isServer || this.disabled || this.trigger !== trigger);
      },
      onClick () {
        if (this.shouldResponse('click')) {
          this.showPopper = !this.showPopper;
        }
      },
      onClickOutside () {
        if (this.shouldResponse('click')) {
          this.showPopper = false;
        }
      },
      onMouseenter () {
        if (this.shouldResponse('hover')) {
          this.showPopper = true;
        }
      },
      onMouseleave () {
        if (this.shouldResponse('hover')) {
          this.showPopper = false;
        }
      },
      onFocus (fromInput = true) {
        if (this.inputEl && !fromInput) return;
        if (this.shouldResponse('focus')) {
          this.showPopper = true;
        }
      },
      onBlur (fromInput = true) {
        if (this.inputEl && !fromInput) return;
        if (this.shouldResponse('focus')) {
          this.showPopper = false;
        }
      },
      onClose () {
        this.showPopper = false;
      }
    },
  };
</script>
