import '../../styles/components/poptip.scss';
import Poptip from './Poptip.vue';

Poptip.install = function (Vue) {
  Vue.component(Poptip.name, Poptip);
};

export default Poptip;
