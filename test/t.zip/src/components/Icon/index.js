import '../../styles/components/icon.scss';
import Icon from './icon.vue';
import { isServer } from '../../utils/index.js';

let script;
function injectFont () {
  if (script) return;
  script = document.createElement('script');
  script.src = 'https://cdn.klook.com/s/dist_web/klook-storybook/packages/klook-ui/dist/font_1602031_pqpxb3pa00d.js';
  script.type = 'text/javascript';
  const head = document.getElementsByTagName("head")[0];
  head && head.appendChild(script);
}

!isServer && injectFont();

Icon.install = function (Vue) {
  Vue.component('klk-icon', Icon);
};

export default Icon;
