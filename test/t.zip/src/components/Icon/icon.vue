<template>
  <svg :class="classes" :style="styles" @click="handleClick">
    <use :xlink:href="linkType"></use>
  </svg>
</template>

<script lang="ts">
// 实现方式参见：https://www.iconfont.cn/help/detail?spm=a313x.7781069.1998910419.d8cf4382a&helptype=code
import { Vue, Component, Prop } from 'vue-property-decorator';

@Component({
  name: 'klk-icon'
})
export default class KlkIcon extends Vue {
  @Prop({
    default: '',
  })
  readonly type!: string;

  @Prop()
  readonly size!: number | string;

  @Prop(String)
  readonly color!: string;

  get linkType() {
    return `#klk-icon-${this.type}`;
  }

  get classes() {
    return `klk-icon klk-icon-${this.type}`;
  }

  get styles() {
    const style: {
      fontSize?: string,
      color?: string,
    } = {};

    if (this.size) {
      style.fontSize = `${parseFloat(this.size.toString()).toString()}px`;
    }

    if (this.color) {
      style.color = this.color;
    }

    return style;
  }

  handleClick(evt: Event) {
    this.$emit('click', evt);
  }
}
</script>
