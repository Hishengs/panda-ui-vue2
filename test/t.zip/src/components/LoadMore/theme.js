export default theme => {
  return `
  .klk-refresh-control{
    color: ${theme.primary};
  }
  `;
};
