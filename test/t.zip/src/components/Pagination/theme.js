export default (theme) => {
  return `
  .klk-pagination {
    color: ${theme.text.primary};
    font-size: 14px;
  }
  .klk-pagination__raised .klk-pagination-item.klk-button,
  .klk-pagination__raised .klk-pagination-btn.klk-button{
    background-color: ${theme.text.alternate};
  }
  .klk-pagination-item.klk-button.is-current {
    background-color: ${theme.primary};
  }
  `;
};
