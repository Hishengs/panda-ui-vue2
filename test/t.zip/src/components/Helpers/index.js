import TouchRipple from '../../internal/TouchRipple';
import {
  ExpandTransition,
  FadeTransition,
  SlideTopTransition,
  SlideBottomTransition,
  SlideLeftTransition,
  SlideRightTransition,
  ScaleTransition
} from '../../internal/transitions';
import clickOutside from '../../directives/click-outside';
import resize from '../../directives/resize';
import scroll from '../../directives/scroll';
import elevation from '../../directives/elevation';

export default {
  install (Vue) {
    Vue.component('klk-ripple', TouchRipple);
    [
      ExpandTransition,
      FadeTransition,
      SlideTopTransition,
      SlideBottomTransition,
      SlideLeftTransition,
      SlideRightTransition,
      ScaleTransition
    ].forEach(transition => Vue.component(transition.name, transition));
    Vue.directive(clickOutside.name, clickOutside);
    Vue.directive(resize.name, resize);
    Vue.directive(scroll.name, scroll);
    Vue.directive(elevation.name, elevation);
  }
};
