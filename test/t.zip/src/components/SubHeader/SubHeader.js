export default {
  name: 'klk-sub-header',
  functional: true,
  props: {
    inset: Boolean
  },
  render (h, { data, props, children }) {
    data.staticClass = `${data.staticClass || ''} klk-sub-header ${props.inset ? 'inset' : ''}`;
    return h('div', data, children);
  }
};
