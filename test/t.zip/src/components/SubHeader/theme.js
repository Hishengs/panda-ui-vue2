export default (theme) => {
  return `
  .klk-sub-header {
    color: ${theme.text.secondary};
  }
  `;
};
