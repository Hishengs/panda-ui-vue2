<template>
  <div :class="cClass">
    <div class="klk-tab-pane-content">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import { findComponentUpward } from '../../utils';

export default {
  name: 'klk-tab-pane',
  props: {
    label: String,
    disabled: Boolean,
    name: String,
    icon: String,
    width: [String, Number],
    maxWidth: [String, Number]
  },
  data () {
    return {
      index: undefined,
      parent: findComponentUpward(this, 'klk-tabs'),
    };
  },
  computed: {
    active () {
      const { curValue } = this.parent;
      return (this.name && this.name === curValue) || curValue === this.index;
    },
    cClass () {
      return {
        'klk-tab-pane': true,
        'klk-tab-pane-active': this.active,
        'klk-tab-pane-disabled': this.disabled,
      };
    },
  },
  mounted () {
    this.$parent.onPaneAdd(this);
  },
  beforeDestroy () {
    this.$parent.onPaneRemove(this);
  },
};
</script>
