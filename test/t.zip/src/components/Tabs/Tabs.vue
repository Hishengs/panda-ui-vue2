<template>
  <div class="klk-tabs">
    <div :class="headerClass" :style="headerStyle">
      <div class="klk-tabs-items" ref="items" :style="itemsStyle">
        <div
          v-for="(pane, i) in panes"
          :key="i"
          :class="getItemClass(pane)"
          :style="getItemStyle(pane)"
          @click="onTabClick(pane)"
        >
          <LabelRender :pane="pane"></LabelRender>
        </div>
      </div>
      <div class="klk-tabs-control">
        <div :class="prevClass" @click="showPrev">
          <Icon type="icon_navigation_chevron_left_xs"></Icon>
        </div>
        <div :class="nextClass" @click="showNext">
          <Icon type="icon_navigation_chevron_right_xs"></Icon>
        </div>
      </div>
    </div>
    <div class="klk-tabs-body">
      <div class="klk-tabs-body-inner" :style="{ transform: `translateX(${-transformX}px)` }">
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
import Icon from '../Icon';
import { parseWidth } from '../../utils';

const LabelRender = {
  functional: true,
  props: {
    pane: Object,
  },
  render (h, ctx) {
    const { pane } = ctx.props;
    return pane.$slots.label
      ? pane.$slots.label
      : [
        pane.icon
          ? h(Icon, {
              props: {
                type: pane.icon
              }
            })
          : null,
        h('span', pane.label || null)
      ];
  }
};

export default {
  name: 'klk-tabs',
  components: {
    Icon,
    LabelRender,
  },
  props: {
    value: String,
    backgroundColor: String,
    underline: Boolean,
  },
  data () {
    return {
      panes: [],
      curValue: this.value || 0,
      isOverflow: false,
      itemsTransformX: 0,
      itemsClientWidth: 0,
      itemsScrollWidth: 0,
    };
  },
  computed: {
    headerClass () {
      return {
        'klk-tabs-header': true,
        'klk-tabs-header-overflow': this.isOverflow,
      };
    },
    headerStyle () {
      return {
        backgroundColor: this.backgroundColor,
        borderBottom: this.underline ? '1px solid #eee' : '',
      };
    },
    itemsStyle () {
      return {
        transform: `translateX(${-this.itemsTransformX}px)`
      };
    },
    prevDisabled () {
      return this.itemsTransformX <= 0;
    },
    nextDisabled () {
      const { itemsScrollWidth, itemsClientWidth } = this;
      return this.itemsTransformX >= itemsScrollWidth - itemsClientWidth;
    },
    prevClass () {
      return {
        'klk-tabs-prev-btn': true,
        'klk-tabs-prev-btn-disabled': this.prevDisabled,
      };
    },
    nextClass () {
      return {
        'klk-tabs-next-btn': true,
        'klk-tabs-next-btn-disabled': this.nextDisabled,
      };
    },
    transformX () {
      const curPane = this.panes.find(p => p.active);
      if (!curPane) return 0;
      else return curPane.$el.offsetLeft;
    },
  },
  watch: {
    value (val) {
      this.curValue = val;
    },
    curValue (val) {
      this.$emit('input', val);
      this.$nextTick(() => {
        this.$emit('change', val);
      });
    },
  },
  mounted () {
    this.onUpdate();
    window.addEventListener('resize', this.onUpdate);
  },
  updated () {
    this.onUpdate();
  },
  beforeDestroy () {
    window.removeEventListener('resize', this.onUpdate);
  },
  methods: {
    onUpdate () {
      const { clientWidth, scrollWidth } = this.$refs.items;
      this.isOverflow = scrollWidth > clientWidth;
      this.itemsClientWidth = clientWidth;
      this.itemsScrollWidth = scrollWidth;
      this.updateItemIndex();
    },
    updateItemIndex () {
      for (let i=0, len=this.panes.length; i<len; i++) {
        this.panes[i].index = i;
      }
    },
    onPaneAdd (pane) {
      if (this.panes.includes(pane)) return;
      this.panes.push(pane);
    },
    onPaneRemove (pane) {
      const index = this.panes.indexOf(pane);
      if (index !== -1) this.panes.splice(index, 1);
    },
    onTabClick (pane) {
      if (pane.disabled || this.curValue === pane.name) return;
      this.curValue = pane.name || pane.index;
      this.adjustItemPosition(pane);
    },
    adjustItemPosition (pane) {
      const item = this.$refs.items.children[pane.index];
      // console.log('>>> adjustItemPosition', item);
      const { offsetLeft, offsetWidth } = item;
      const { offsetWidth: itemsOffsetWidth } = this.$refs.items;
      const { itemsTransformX } = this;
      const newOffsetLeft = (offsetLeft - itemsTransformX);
      const isLeftBoundary = newOffsetLeft < 0 && (newOffsetLeft + offsetWidth) > 0;
      const isRightBoundary = newOffsetLeft < itemsOffsetWidth && (newOffsetLeft + offsetWidth) > itemsOffsetWidth;
      /* console.log({
        isLeftBoundary, isRightBoundary
      }); */
      if (isLeftBoundary) {
        this.itemsTransformX = offsetLeft;
      } else if (isRightBoundary) {
        const newItemsTransformX = offsetLeft + offsetWidth - itemsOffsetWidth;
        this.itemsTransformX = newItemsTransformX > 0 ? newItemsTransformX : 0;
      }
    },
    getItemClass (pane) {
      return {
        'klk-tabs-item': true,
        'klk-tabs-item-active': pane.active,
        'klk-tabs-item-disabled': pane.disabled,
        'klk-tabs-item-width-specified': pane.width && pane.width !== 'auto',
      };
    },
    getItemStyle (pane) {
      const { width, maxWidth } = pane;
      return {
        width: parseWidth(width),
        maxWidth: parseWidth(maxWidth),
      }
    },
    showPrev () {
      if (this.prevDisabled) return;
      let { itemsClientWidth, itemsTransformX } = this;
      itemsTransformX = itemsTransformX - itemsClientWidth;
      this.itemsTransformX = itemsTransformX >= 0 ? itemsTransformX : 0;
    },
    showNext () {
      if (this.nextDisabled) return;
      let { itemsClientWidth, itemsScrollWidth, itemsTransformX } = this;
      itemsTransformX = itemsTransformX + itemsClientWidth;
      const max = itemsScrollWidth - itemsClientWidth;
      this.itemsTransformX = itemsTransformX > max ? max : itemsTransformX;
      // console.log({ itemsClientWidth, itemsScrollWidth, itemsTransformX });
    },
  }
};
</script>
