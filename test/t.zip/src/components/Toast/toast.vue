<template>
    <div class="klk-toast">
        {{ info }}
    </div>
</template>
<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class Toast extends Vue {
    info: string = '';
}
</script>
<style scoped>
.klk-toast {
    z-index: 9999999999;
    position: fixed;
    left: 50%;
    top: 50%;
    background: rgba(0, 0, 0, 0.6);
    padding: 10px;
    border-radius: 5px;
    transform: translate(-50%, -50%);
    color: #fff;
}
</style>
