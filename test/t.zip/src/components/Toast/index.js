import showToast from './toast';

export default {
  install (Vue) {
    Vue.prototype.$toast = showToast;
  }
};
