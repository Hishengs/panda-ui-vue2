import '../../styles/components/tooltip.scss';
import Tooltip from './Tooltip';

Tooltip.install = function (Vue) {
  Vue.component(Tooltip.name, Tooltip);
};

export default Tooltip;
